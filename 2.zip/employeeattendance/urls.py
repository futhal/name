from django.urls import path

from . import views

urlpatterns = [
    
    path(
        'json_balance_vacation/',
        views.json_balance_vacation.as_view(),
        name='json_balance_vacation',
    ),
    path(
        'balance_vacation/',
        views.balance_vacation.as_view(),
        name='balance_vacation',
    ),
  
    path(
        'TypeOfVacationsView/',
        views.TypeOfVacationsView.as_view(),
        name="TypeOfVacationsView",
    ),
    path(
        'get_vacation_day/',
        views.get_vacation_day,
        name="get_vacation_day",
    ),
    path(
        'TypeOfVacationsJson',
        views.TypeOfVacationsJson.as_view(),
        name="TypeOfVacationsJson",
    ),

    path(
        'ManualAttendeeView/',
        views.ManualAttendeeView.as_view(),
        name='ManualAttendeeView',
    ),
    path(
        'ManualAttendeeJson/',
        views.ManualAttendeeJson.as_view(),
        name='ManualAttendeeJson',
    ),
    path(
        'load_manual_attendee_details/',
        views.load_manual_attendee_details,
        name="load_manual_attendee_details",
    ),




    path(
        'calculate_attendance_for_period/',
        views.calculate_attendance_for_period,
        name="calculate_attendance_for_period",
    ),
    path(
        'get_form_work_policy_details/',
        views.get_form_work_policy_details,
        name="get_form_work_policy_details",
    ),
    path(
        'WorkingPolicyView/',
        views.WorkingPolicyView.as_view(),
        name="WorkingPolicyView",
    ),
    path(
        'WorkingPolicyJson',
        views.WorkingPolicyJson.as_view(),
        name="WorkingPolicyJson",
    ),

    path(
        'request_vacation/<int:pk>/',
        views.request_vacation,
        name="request_vacation",
    ),
    path(
        'display_vacation/',
        views.display_vacation,
        name="display_vacation",
    ),
    path(
        'edit_vacation/<int:vacation_id>/',
        views.edit_vacation,
        name='edit_vacation',
    ),
    path(
        'select_month_v_off/',
        views.select_month_offi,
        name="select_month_v_off",
    ),
    path(
        'cancel_vacation/<int:pk>/',
        views.cancel_vacation,
        name='cancel_vacation',
    ),

    path(
        'stop_vacation/<int:pk>/',
        views.stop_vacation,
        name='stop_vacation',
    ),

    path(
        'update_offi_vacation/<int:month>/<str:type_vacation>',
        views.update_offi_vacation,
        name='update_offi_vacation',
    ),
    # path('delet_balance/<int:balance_id>/',views.delet_balance,name='delet_balance'),
    path('type_vacation_init/',
         views.type_vacations_init,
         name='type_vacation_init',
         ),
    path(
        'chick_balance/',
        views.chick_balance,
        name='chick_balance',
    ),
    # path('chick_vacation/',views.chick_vacation,name='chick_vacation'),
    path(
        'stop_vacation/<int:pk>/',
        views.stop_vacation,
        name='stop_vacation',
    ),
    # path('offi_vacation',views.offi_vacation,name='offi_vacation'),
    path(
        'disblay_offi/',
        views.disblay_offi,
        name="disblay_offi",
    ),
    path(
        'delete_offi_vacation/<int:pk>',
        views.delete_offi_vacation,
        name='delete_offi_vacation',
    ),


    # path('get_count_organization/',views.get_count_organization,name='get_count_organization'),

    path(
        'CalculateAttendanceAndLeave/',
        views.CalculateAttendanceAndLeave,
        name='CalculateAttendanceAndLeave',
    ),
    path(
        'get_adminstration_period_months/',
        views.get_adminstration_period_months,
        name='get_adminstration_period_months',
    ),
    path(
        'get_organizational_chart_employees/',
        views.get_organizational_chart_employees,
        name='get_organizational_chart_employees',
    ),
    path(
        'get_period_details_date/',
        views.get_period_details_date,
        name='get_period_details_date',
    ),
    path(
        'view_attendee_and_leave/<int:id>',
        views.view_attendee_and_leave,
        name='view_attendee_and_leave',
    ),

    path(
        'weekend_vacation/',
        views.weekend_vacation,
        name='weekend_vacation',
    ),
    path(
        'month_vacation_offi/<int:month>',
        views.month_vacation_offi,
        name='month_vacation_offi',
    ),

    path(
        'employee_vacation_request_report/',
        views.employee_vacation_request_report,
        name='employee_vacation_request_report',
    ),
    path(
        'get_employee_organization_vacation_request/',
        views.get_employee_organization_vacation_request,
        name='get_employee_organization_vacation_request',
    ),
    path(
        'all_vacation_request/',
        views.all_vacation_request,
        name='all_vacation_request',
    ),
    path(
        'get_employees_vacation_request_organization/',
        views.get_employees_vacation_request_organization,
        name='get_employees_vacation_request_organization',
    ),

    path(
        'view_sumition/',
        views.view_sumition_calculate_attendee_and_leave,
        name='view_sumition_calculate_attendee_and_leave',
    ),

]
