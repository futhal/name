from django.apps import AppConfig


class EmployeeattendanceConfig(AppConfig):
    name = 'employeeattendance'
