import datetime

from django import forms
from django.contrib import messages
from django.utils.translation import ugettext_lazy as _
from salary.models import WorkPeriod
from employeesmanagement.models import Emp_data
from employeesmanagement.models import OrganizationalChart
from salary.models import AdministrativePeriods
from .models import ManualAttendeeDetails, BalanceVacations, ManualAttendee
from .models import TypeOfVacations, WorkingPolicy, WorkingPolicyDetails, Vacation_request, \
    OfficialVacations


class NewTypeOfVacations(forms.ModelForm):
    """
    فورم انواع الاجازات
    """
    def __init__(self, *arges, **kwargs):
        super(NewTypeOfVacations, self).__init__(*arges, **kwargs)
        self.fields['VacationDayes'].widget.attrs.update({
            'class': 'form-control select'
        })
        self.fields['name'].widget.attrs.update({
            'class': 'form-control select'
        })
        self.fields['active'].widget.attrs.update({
            'class': 'custom-control-input'
        })

    class Meta:
        model = TypeOfVacations
        fields = ['name', 'VacationDayes', 'active']
        widgets = {
            'name': forms.TextInput(attrs={
                'class': 'form-control select'
            }),

        }



class BalanceVacationsform(forms.ModelForm):
    """
    فورم أرصدة الاجازات
    """
    class Meta:
        model = BalanceVacations
        fields = ['employee']

    def __init__(self, *args, **kwargs):
        super(BalanceVacationsform, self).__init__(*args, **kwargs)
        self.fields['employee'].queryset = Emp_data.objects.filter(emp_status=True)       
        labels = {'employee': _('Employee Name')}
        widgets = {
            'employee': forms.Select(attrs={
                'id': 'employee',
                'class': 'form-control select',
            }),
        }

class Balanceform(forms.ModelForm):
    """
    فورم الارصدة
    """
    class Meta:
        model = BalanceVacations
        fields = ['employee', 'v_type', 'total_balance_day', 'current_balance_day', 'balance_year']

    def __init__(self, *arges, **kwargs):
        super(Balanceform, self).__init__(*arges, **kwargs)
        for field in self.fields:
            self.fields[field].widget.attrs.update({
                'class': 'form-control select',
            })
        self.fields['total_balance_day'].widget.attrs.update({
            'Readonly': True

        })

        self.fields['balance_year'].widget.attrs.update({
            'Readonly': True
        })

class WorkingPolicyForm(forms.ModelForm):
    """
    فورم سياسة العمل
    """
    class Meta:
        model = WorkingPolicy
        fields = ['name', 'type_finger', 'number_of_finger', 'm_before_present', 'm_after_leave']
        widgets = {
            'name': forms.TextInput(attrs={
                'class': 'select form-control'
            }),
            'type_finger': forms.Select(attrs={
                'class': ' select form-control'
            }),
            'number_of_finger': forms.TextInput(attrs={
                # 'placeholder': _('Item name'),
                'readonly': False,
                'class': 'select form-control'
            }),
            'm_before_present': forms.TextInput(attrs={
                'class': 'select form-control'
            }),
            'm_after_leave': forms.TextInput(attrs={
                'class': 'select form-control'
            }),
        }

    def isrepeate(self, request):
        name = self.cleaned_data.get('name')
        name1 = WorkingPolicy.objects.filter(name=name)
        if name1.exists():
            messages.error(request, 'sorry this name exist before now ,you can choice anthore name')
            return False
        return True


class WorkingPolicyDetailsForm(forms.ModelForm):
    """
    فورم تفاصيل سياسة العمل 
    """
    class Meta:
        model = WorkingPolicyDetails
        fields = ['working_policy', 'voilation_name', 'convert_to',
                  'calc_violation_after', 'minute_equal']

        # 'calc_violation_after','minute_equal', 'working_policy', 'absent_or_delay']
        labels = {'voilation_name': '', 'convert_to': '', 'calc_violation_after': '',
                  'minute_equal': ''}
        widgets = {
            #  'working_policy': forms.Select(attrs={
            #     'class': 'form-control'
            # }),

            'voilation_name': forms.TextInput(attrs={
                'class': 'form-control  val_name',
                'readonly': 'true',
            }),
            'convert_to': forms.Select(attrs={
                'class': 'form-control select convert_to'
            }),
            'calc_violation_after': forms.TextInput(attrs={
                'class': 'form-control  calc_violation_after'
            }),
            'minute_equal': forms.TextInput(attrs={
                'class': 'form-control  minute_equal'
            }),

        }


class Vacation_dataForm(forms.ModelForm):
    """
    فورم الاجازات
    """
    dateprocess = forms.DateField(label=_("Date"),
                                  widget=forms.DateInput(attrs={"type": 'date', 'value': datetime.date.today()}))
    fromdate = forms.DateField(label=_("From Date"),
                               widget=forms.DateInput(attrs={"type": 'date', 'value': datetime.date.today()}))
    todate = forms.DateField(label=_("To Date"), widget=forms.DateInput(
        attrs={"type": 'date', 'value': (datetime.date.today() + datetime.timedelta(days=1))}))
    employee = forms.ModelChoiceField(label=_("Employee"), queryset=Emp_data.objects.filter(emp_status=True))

    def __init__(self, *args, **kwargs):
        super(Vacation_dataForm, self).__init__(*args, **kwargs)
        self.fields['employee'].widget.attrs.update({

            'class': 'formset-field items_val select form-control ',
            'id': 'employee'
        })
        self.fields['type_vacation'].widget.attrs.update({

            'class': 'formset-field items_val select form-control ',
            'id': 'type_vacation'
        })
        self.fields['dateprocess'].widget.attrs.update({
            'Readonly': True,
            'class': 'formset-field items_val select form-control dateprocess',
        })
        self.fields['fromdate'].widget.attrs.update({
            'Readonly': True,
            'class': 'formset-field items_val select form-control fromdate',
            'id': 'fromdate',
        })
        self.fields['todate'].widget.attrs.update({
            'class': 'formset-field items_val select form-control todate',
            'id': 'todate',
            'oninput': 'calc_periods_number()'
        })
        self.fields['betweendate'].widget.attrs.update({
            'Readonly': True,
            'class': 'formset-field items_val select form-control betweendate',
        })
        self.fields['reason'].widget.attrs.update({
            'class': 'formset-field items_val select form-control reason',
        })
        self.fields['reason'].required = False

    class Meta:
        model = Vacation_request
        fields = ['employee', 'type_vacation', 'dateprocess', 'fromdate', 'todate', 'betweendate', 'reason']


DAY_NAME_CHOICES = [
    ('Saturday', _('Saturday')),
    ('Sunday', _('Sunday')),
    ('Monday', _('Monday')),
    ('Tuesday', _('Tuesday')),
    ('Wednesday', _('Wednesday')),
    ('Thursday', _('Thursday')),
    ('Friday', _('Friday')),
]
type_officialvacations = [
    ('Weekend', _('Weekend')),
    ('Feast', _('Feast')),
    ('National', _('National')),
    ('Other', _('Other')),
]


class OfficialVacationsForm(forms.ModelForm):
    """
    فورم الاجازات الرسمية
    """
    def __init__(self, *arges, **kwargs):
        super(OfficialVacationsForm, self).__init__(*arges, **kwargs)
        for field in self.fields:
            self.fields[field].widget.attrs.update({
                'class': 'form-control select',
            })

    day_name = forms.MultipleChoiceField(
        required=True,
        widget=forms.CheckboxSelectMultiple(attrs={'class': 'checkbox'}),
        choices=DAY_NAME_CHOICES,
        label=_('Day Name'),

    )
    type_offi_v = forms.ChoiceField(choices=type_officialvacations, label=_('Official Vacations'))
    from_date = forms.DateField(widget=forms.DateInput(attrs={"type": 'date', 'value': datetime.date.today()}),
                                label=_('From Date'))
    to_date = forms.DateField(
        widget=forms.DateInput(attrs={"type": 'date', 'value': (datetime.date.today() + datetime.timedelta(days=1))}),
        label=_('To Date'))
    descript_offi_v = forms.CharField(label=_('Description'))

    class Meta:
        model = OfficialVacations
        exclude = ['month_number', 'date_offi_v', 'day_name']


class OfficialVacationsFormUpdate(forms.ModelForm):
    """
    فورم تعديل الاجازات الرسمية
    """
    def __init__(self, *arges, **kwargs):
        super(OfficialVacationsFormUpdate, self).__init__(*arges, **kwargs)
        for field in self.fields:
            self.fields[field].widget.attrs.update({
                'class': 'form-control select',
            })

    class Meta:
        model = OfficialVacations
        fields = '__all__'
        labels = {'day_name': _('Day Name'),
                  'type_offi_v': _('Official Vacations'),
                  'date_offi_v': _('Date'),
                  }

        widgets = {
            'day_name': forms.Select(attrs={
                'requird': True,
                'id': 'id_day_name',

            }),
            'type_offi_v': forms.Select(attrs={
                'requird': True,
                'id': 'id_type_offi_v',

            }),
            'date_offi_v': forms.DateInput(attrs={
                'type': 'date',

            })

        }


class ManualAttendeeDetailsForm(forms.ModelForm):
    """
    فورم تفاصيل التحضير اليدوي
    """
    def __init__(self, *args, **kwargs):
        try:
            list_item = next(kwargs.pop('item_iterator'))
        except:
            pass
        super(ManualAttendeeDetailsForm, self).__init__(*args, **kwargs)
        try:
            self.fields['employee_name'].initial = list_item[0]
            self.fields['time_attendee'].initial = list_item[1]
            self.fields['time_leave'].initial = list_item[2]
        except:
            pass
        self.fields['chek_attendee'].initial = False
        self.fields['employee'].required = False
        self.fields['employee_name'].required = False
        self.fields['time_leave'].required = True
        self.fields['time_attendee'].required = True
        self.fields['employee_name'].widget.attrs.update(
            {'class': 'form-control select',
             'readonly': True,
             }
        )
        self.fields['time_attendee'].widget.attrs.update(
            {'class': 'form-control select',

             }
        )
        self.fields['time_leave'].widget.attrs.update(
            {'class': 'form-control select',

             }
        )
        self.fields['chek_attendee'].widget.attrs.update(
            {'class': 'select',
             'id': 'chek_attendee',
             'label': _('Present')
             }
        )
        self.fields['employee'].widget.attrs.update(
            {

                'class': 'form-control select',
                'id': 'employee1'
            }
        )
        # for name in self.fields.keys():
        #     self.fields['employee_name'].widget.attrs.update(
        #     {
        #         'class': 'formset-field items_val select form-control'
        #        }
        #     )

    employee_name = forms.CharField(max_length=100)
    chek_attendee = forms.BooleanField(required=False)
    time_attendee = forms.TimeField(widget=forms.TimeInput(attrs={'type': 'time'}))
    time_leave = forms.TimeField(widget=forms.TimeInput(attrs={'type': 'time'}))

    class Meta:
        model = ManualAttendeeDetails
        fields = ['employee', 'employee_name', 'time_attendee', 'time_leave', 'chek_attendee']
        # labels = {'employee ':_('From Employee')}


class ManualAttendeeForm(forms.ModelForm):
    """
    فورم التحضير اليدوي
    """
    def __init__(self, *args, **kwargs):
        super(ManualAttendeeForm, self).__init__(*args, **kwargs)
        try:
            employee = [(mot['arname'], mot['arname']) for mot in
                        Emp_data.objects.values('arname').filter(emp_status=True).order_by('id')]
            organizational = [(mot['name_ar'], mot['name_ar']) for mot in
                            OrganizationalChart.objects.values('name_ar').order_by('id')]
        except:
            employee = []
            organizational = []
        self.fields['from_employee'] = forms.ChoiceField(choices=employee, label=_('From Employee'))
        self.fields['to_employee'] = forms.ChoiceField(choices=employee, label=_('To Employee'))
        self.fields['organizational_chart'] = forms.ChoiceField(choices=organizational, required=False, label=_('Organizational Chart'))

        self.fields['time_attendee'] = forms.TimeField(widget=forms.TimeInput(attrs={'type': 'time', 'required': False}),
                                        label=_('Attendance Time'))
        self.fields['time_leave'] = forms.TimeField(widget=forms.TimeInput(attrs={'type': 'time', 'required': False}),
                                    label=_('Leave Time'))
        self.fields['date_attendee'] = forms.DateField(widget=forms.DateInput(attrs={'type': 'date', 'value': datetime.date.today()}),
                                        label=_('Attendeence Date'))
        self.fields['date_opration'] = forms.DateField(widget=forms.DateInput(attrs={'type': 'date', 'value': datetime.date.today()}),
                                        label=_('Opration Date'))
        self.fields['select_all_employee'] = forms.BooleanField(required=False, label=_('Select All Employee'))
        self.fields['check_organization_chart'] = forms.BooleanField(required=False, label=_('Check Organization Chart'))

        for name in self.fields.keys():
            self.fields[name].widget.attrs.update(
                {
                    'class': 'formset-field items_val select form-control',
                }
            )
        self.fields['from_employee'].widget.attrs.update(
            {
                'id': 'from_employee',
                'required': False,

            }
        )
        self.fields['to_employee'].widget.attrs.update(
            {'null': True,
             'id': 'to_employee',
             'required': False,
             }
        )
        self.fields['select_all_employee'].widget.attrs.update(
            {
                'id': 'select_all_employee',
                'required': False,
                'class': '',
            }
        )
        self.fields['check_organization_chart'].widget.attrs.update(
            {
                'id': 'check_organization_chart',
                'required': False,
                'class': '',
            }
        )
        self.fields['date_opration'].widget.attrs.update(
            {

                'min': datetime.date.today(),
                'max': datetime.date.today(),
                'readonly': True,

            }
        )
        self.fields['date_attendee'].widget.attrs.update(
            {

                'max': datetime.date.today(),

            }
        )

        self.fields['to_employee'].required = False
        self.fields['from_employee'].required = False
        self.fields['time_leave'].required = False
        self.fields['time_attendee'].required = False
        self.fields['select_all_employee'].initial = False
        self.fields['check_organization_chart'].initial = False

    
    class Meta:
        model = ManualAttendee
        # fields = ['date_opration','date_attendee','time_attendee','time_leave','select_all_employee','check_organization_chart']
        fields = ['date_opration', 'date_attendee']


class CalculateAttendanceAndLeaveForm(forms.Form):
    """
    فورم احتساب الحضور والانصراف
    """
    def __init__(self, *args, **kwargs):
        super(CalculateAttendanceAndLeaveForm, self).__init__(*args, **kwargs)
        try:

            organizational = [(mot['id'], mot['name_ar']) for mot in
                              OrganizationalChart.objects.values('name_ar', 'id').order_by('id')]
            periods = AdministrativePeriods.objects.values('id', 'from_month', 'to_month', 'from_year', 'to_year').all()
            arry_all_periods = []

            for obj in periods:
                value_period = str(obj['from_month']) + '/' + str(obj['from_year']) + '-' + str(
                    obj['to_month']) + '/' + str(obj['to_year'])

                arry_all_periods.append((obj['id'], value_period))

            print(arry_all_periods)
        except:
            organizational = []
            arry_all_periods = []

        self.fields['administrative_period_year'] = forms.ChoiceField(choices=arry_all_periods,
                                                                      label=_('Administrative Period Year'))
        self.fields['administrative_period_month'] = forms.CharField(widget=forms.Select,
                                                                     label=_('Administrative Period Month'))
        self.fields['all_employee'] = forms.BooleanField(label=_('All Employee'))
        self.fields['organizational_chart'] = forms.ChoiceField(choices=organizational,
                                                                label=_('Organizationaln Chart'))
        self.fields['from_employee'] = forms.CharField(max_length=100, label=_('To Employee'))
        self.fields['to_employee'] = forms.CharField(max_length=100, label=_('To Employee'))
        self.fields['from_date'] = forms.DateField(label=_('From Date'))
        self.fields['to_date'] = forms.DateField(label=_('To Date'))
        for name in self.fields.keys():
            self.fields[name].widget.attrs.update(
                {
                    'class': 'formset-field items_val select form-control',
                }
            )
        self.fields['all_employee'].widget.attrs.update({
            'class': 'custom-control-input'
        })
        self.fields['organizational_chart'].required = False
        self.fields['all_employee'].required = False
        self.fields['from_employee'].required = False
        self.fields['to_employee'].required = False
        self.fields['administrative_period_month'].required = False
        
        self.fields['from_employee'].widget.attrs.update({
            'readonly': True
        })
        self.fields['to_employee'].widget.attrs.update({
            'readonly': True
        })
       

