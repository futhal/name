import datetime
import functools
import re
from django.contrib.auth.mixins import LoginRequiredMixin
from datetime import  time
from django.contrib import messages
from django.contrib.auth.decorators import login_required, permission_required
from django.core import serializers
from django.db import transaction
from django.db.models import Q
from django.db.models import Sum,Max
from django.forms import formset_factory, modelformset_factory
from django.http import (
    QueryDict,
    JsonResponse,
)
from django.shortcuts import render, redirect, get_object_or_404
from django.template.loader import render_to_string
from django.urls import reverse
from django.utils.dateparse import parse_time, parse_date
from django.utils.translation import ugettext_lazy as _
from django.views.generic.edit import CreateView
from django_datatables_view.base_datatable_view import BaseDatatableView

from employeesmanagement.models import OrganizationalChart, EmployeeFunctionalData, Emp_data
from fingerprintdevices.models import Attendance
from ittech.ittech_message import message
from salary.models import (
    AdministrativePeriods,
    AdministrativePeriodsDetiles,
    JoinEmployeeWithWorkPeriod,
    WorkPeriodDetail,
    WorkPeriod,
)
from salary.views import error_formset
from .forms import (
    BalanceVacationsform,
    Balanceform,
    CalculateAttendanceAndLeaveForm,
    ManualAttendeeForm,
    ManualAttendeeDetailsForm,
    NewTypeOfVacations,
    WorkingPolicyForm,
    WorkingPolicyDetailsForm,
    Vacation_dataForm,
)
from .models import (
    TypeOfVacations,
    WorkingPolicy,
    WorkingPolicyDetails,
    Vacation_request,
    CalculateAtendanceAndLeaveDetails,
    CalculateAtendanceAndLeave,
    OfficialVacations,
    BalanceVacations,
    ManualAttendeeDetails,
    ManualAttendee,
)
import django_excel as excel

date_now = datetime.date.today()

type_officialvacations = {
    'Feast': _('Feast'),
    'National': _('National'),
    'Other': _('Other'),
}

week = {
    'Saturday': _('Saturday'),
    'Sunday': _('Sunday'),
    'Monday': _('Monday'),
    'Tuesday': _('Tuesday'),
    'Wednesday': _('Wednesday'),
    'Thursday': _('Thursday'),
    'Friday': _('Friday'),
}
class json_balance_vacation(BaseDatatableView):
    '''
    يعمل هذا الكلاس على عرض الموظفين وارصدة الاجازات
    '''
    """List TypeOfVacations  To Show in Table
    Returns:
        [json] -- List From Balances To Show
    """

    model = BalanceVacations
    columns = [
        'employee',
        'v_type',
        'total_balance_day',
        'current_balance_day',
        'action',
        'request'

    ]
    order_columns = [
        'employee',
        'v_type',
        'total_balance_day',
        'current_balance_day',
        'action',
        'request'
    ]

    def get_initial_queryset(self):

        return self.model.objects.filter(balance_year=date_now.year, v_type__active=True)

    count = 0

    def render_column(self, row, column):
        """Render Column For Datatable
        """
        if column == "id":
            self.count += 1
            return self.count
        elif column == "action":
            action = ""
            action_edit = '<a class="edit_row" data-url="{2}" data-id="{0}" ' \
                          'style="DISPLAY: -webkit-inline-box;"  data-toggle="tooltip"' \
                          ' title="{1}"><i class="fa fa-edit"></i></a>'.format(row.pk, _("Edit"),
                                                                               reverse("balance_vacation"))
            action_delete = '<a class="delete_row" data-url="{2}" data-id="{0}" ' \
                            'style="DISPLAY: -webkit-inline-box;"  data-toggle="tooltip"' \
                            ' title="{1}"><i class="fa fa-trash"></i></a>'.format(row.pk, _("Delete"),
                                                                                  reverse("balance_vacation"))
            if self.request.user.has_perm('employeeattendance.change_balance_vacation'):
                action += action_edit
            if self.request.user.has_perm('employeeattendance.delete_balance_vacation'):
                action += action_delete
            return action

        elif column == "request":
            action = ""
            if self.request.user.has_perm('employeeattendance.add_vacation_request'):
                if row.current_balance_day > 0:
                    action = '<a href="/employeeattendance/request_vacation/' + str(
                        row.pk) + '"><i class="fa fa-plus" aria-hidden="true"></i></a>'
                else:
                    action = "0"

            return action

        else:
            return super(json_balance_vacation, self).render_column(row, column)

    def filter_queryset(self, qs):
        """To Filter data in table using in search
        """
        sSearch = self.request.GET.get("sSearch", None)
        if sSearch:
            qs = qs.filter(
                Q(employee__arname__icontains=sSearch)
                | Q(employee__enname__icontains=sSearch)
                | Q(v_type__name__icontains=sSearch)
                | Q(total_balance_day__icontains=sSearch)
                | Q(current_balance_day__icontains=sSearch)

            )
        return qs
class balance_vacation(CreateView):
    '''
    يعمل هذا الكلاس اظافة ارصدة اجازات للموظفين وحذفها وتعديلها
    '''
    def post(self, request, *args, **kwargs):
        if request.POST.get('id'):
            pk = int(request.POST.get('id'))
            data = get_object_or_404(BalanceVacations, pk=pk)
            form_edite = Balanceform(request.POST, instance=data)
            chk = Vacation_request.objects.filter(employee=data.employee,type_vacation=data.v_type,dateprocess__year=data.balance_year,todate__gte=date_now)
            if chk or data.current_balance_day > 0 :
                msg = message.edit_error()
            else:
                if form_edite.is_valid():
                    form_edite.save()
                    msg = message.update_successfully()
        else:

            balance_form = BalanceVacationsform(request.POST)
            if balance_form.is_valid():
                list_of_pk = (request.POST.get('key')).split(',')
                print(list_of_pk)
                if list_of_pk:
                    queryset = TypeOfVacations.objects.filter(pk__in=list_of_pk)
                    emp = balance_form.cleaned_data['employee']

                    msg = message.add_successfully()
                    for vacation in queryset:
                        # //{
                        new_balance = BalanceVacations.objects.create(employee=emp,
                                                                      v_type=vacation,
                                                                      total_balance_day=vacation.VacationDayes,
                                                                      current_balance_day=vacation.VacationDayes,
                                                                      balance_year=int(date_now.year))

        result = {'status': 0, 'message': msg}
        return JsonResponse(result)

    def get(self, request, *args, **kwargs):
       
        if 'id' in request.GET.keys():

            pk =int(request.GET.get('id'))

            queryset = BalanceVacations.objects.filter(pk=pk)
            if queryset:
                data = serializers.serialize('json', queryset)
            result = {'status': 1, 'data': data}
            return JsonResponse(result)
        context = {
            'balance_form': BalanceVacationsform(),
            'form': Balanceform(),
            'url': reverse('balance_vacation'),
            'urljson': reverse('json_balance_vacation'),
            'permission': request.user.has_perm('employeeattendance.add_balancevacations')
        }
        if request.user.has_perm('employeeattendance.view_balancevacations'):
            return render(request, 'employeeattendance/balance_vacation.html', context)
        else:
            return render(request, 'error/403.html', {})

    def delete(self, request, *args, **kwargs):

        msg = message.delete_error()
        result = {'status': 0, 'message': msg}
        pk = int(QueryDict(request.body).get('id'))

        date_now = datetime.date.today()
        balance = get_object_or_404(BalanceVacations, pk=pk)
        if balance:
            vacation = Vacation_request.objects.filter(employee=balance.employee,
                                                       type_vacation=balance.v_type, todate__gte=date_now)

            if vacation:
                msg = _("You cannot delete this balance because it is on vacation")
                msg = message.delete_error(msg)
                result = {'status': 0, 'message': msg}

            else:
                balance.delete()
                msg = message.delete_successfully()
                result = {'status': 1, 'message': msg}
        else:
            msg = _("You cannot delete this balance because it is on vacation")
            msg = message.delete_error(msg)
            result = {'status': 0, 'message': msg}

        return JsonResponse(result)

@login_required(login_url='login')
def chick_balance(request):
    """
    تستدعى هذه الدالة من واجهة اظافة ارصدة اجازات للموظفين 
    تاخذ الموظف و ترجع بالارصدة التي لم يتم منحها للموظف
    """
    """
    Examination of leave balances that may be 
    granted to the employee or not
    """
    # request.session["open_menu"] = {"Employees_attendaces": "menu-open"}
    # request.session["top_menu"] = {"Employees_attendaces": "active"}
    # request.session["sub_menu"] = {"balanc_vataion": "active"}
    response_data = {}
    qu = TypeOfVacations.objects.filter(active=True)
    if qu:
        emp = request.GET.get('emp')
        list_of_pk = [k.v_type.id for k in
                      BalanceVacations.objects.filter(employee=emp,
                                                      balance_year=date_now.year, v_type__active=True)]

        queryset = TypeOfVacations.objects.exclude(pk__in=list_of_pk).values_list()
        queryset = queryset.filter(active=True)
        response_data['data'] = list(queryset)
    else:

        response_data['data'] = ["No Vacation"]

    return JsonResponse(response_data, safe=False)

@login_required(login_url='login')
@permission_required('employeeattendance.view_typeofvacations', raise_exception=True)
def type_vacations_init(request):
    """
    تعمل هذه الدالة على تهيئة انواع الاجازات 
    تفعيل او ايقاف نوع من انواع الاجازات 
    """
    """
    Initialization types of vacations that are approved for a specific year
    """
    # request.session["open_menu"] = {"Employees_attendaces": "menu-open"}
    # request.session["top_menu"] = {"Employees_attendaces": "active"}
    # request.session["sub_menu"] = {"type_vacation_init": "active"}
    vacations = TypeOfVacations.objects.all()
    permission = True if request.user.has_perm('employeeattendance.change_typeofvacations') else False

    if request.method == 'POST':
        list_of_pk = request.POST.getlist('ch')
        if list_of_pk:
            queryset = TypeOfVacations.objects.filter(pk__in=list_of_pk)
            if queryset:
                for vacation in queryset:
                    vacation.active = True
                    vacation.save()
                    messages.success(request, _("Initialization Successfulyy"))

            queryset = TypeOfVacations.objects.exclude(pk__in=list_of_pk)
            if queryset:
                for vacation in queryset:
                    vacation.active = False
                    vacation.save()
                    messages.success(request, _("Initialization Successfulyy"))

    return render(request, 'employeeattendance/type_vacation_init.html',
                  {'vacations': vacations, 'permission': permission})

@login_required(login_url='login')
@permission_required('employeeattendance.view_vacation_request', raise_exception=True)
def display_vacation(request):
    """
     تعمل هذه الدال ة على عرض الاجازات المأخوذه من قبل الموظفين
     للسنة الحالية سواء مازال الموظف في اجازاة او انقضى وقتها
    """
    permission = {
        'add': request.user.has_perm('employeeattendance.add_vacation_request'),
        'delete': request.user.has_perm('employeeattendance.delete_vacation_request'),
        'change': request.user.has_perm('employeeattendance.change_vacation_request'),
    }
    # request.session["open_menu"] = {"Employees_attendaces": "menu-open"}
    # request.session["top_menu"] = {"Employees_attendaces": "active"}
    # request.session["sub_menu"] = {"vacation": "active"}
    vacation_data = Vacation_request.objects.all().exclude(fromdate__year__lt=(date_now).year, todate__lt=date_now)
    vacation_id = Vacation_request.objects.values_list("id", flat=True).filter(todate__gte=date_now)

    return render(request, 'employeeattendance/display_vacation_request.html',
                  {'vacation_data': vacation_data, 'vacation_id': vacation_id, 'permission': permission})

@login_required(login_url='login')
def cancel_vacation(request, pk):
    '''
    تعمل هذه الدالة على الغاء اجازة الموظف 
     و استعادة ارصدة الاجازة الملغية
    '''
    # request.session["open_menu"] = {"Employees_attendaces": "menu-open"}
    # request.session["top_menu"] = {"Employees_attendaces": "active"}
    # request.session["sub_menu"] = {"vacation": "active"}
    vaca_obj = get_object_or_404(Vacation_request, id=pk)

    queryset = BalanceVacations.objects.get(employee=vaca_obj.employee, v_type=vaca_obj.type_vacation,
                                            balance_year=(vaca_obj.dateprocess).year)
    queryset.current_balance_day = queryset.current_balance_day + vaca_obj.betweendate

    off_vaction_day = OfficialVacations.objects.filter(date_offi_v__gt=vaca_obj.fromdate,
                                                       date_offi_v__lte=vaca_obj.todate,
                                                       date_offi_v__year=datetime.date.today().year).count()
    if off_vaction_day:
        queryset.current_balance_day -= off_vaction_day
    vaca_obj.delete()
    queryset.save()
    messages.success(request, _("Cancelation Successfully "))

    return redirect('display_vacation')

@login_required(login_url='login')
def edit_vacation(request, vacation_id):
   
    '''
    تعمل هذه الدالة على تعديل اجازة الموظف
    '''
    # request.session["open_menu"] = {"Employees_attendaces": "menu-open"}
    # request.session["top_menu"] = {"Employees_attendaces": "active"}
    # request.session["sub_menu"] = {"vacation": "active"}

    new_vaca_obj = get_object_or_404(Vacation_request, id=vacation_id)

    if request.method == 'POST':

        first_balance = new_vaca_obj.betweendate
        off_vaction_day = OfficialVacations.objects.filter(date_offi_v__gt=new_vaca_obj.fromdate,
                                                           date_offi_v__lte=new_vaca_obj.todate,
                                                           date_offi_v__year=datetime.date.today().year).count()
        if off_vaction_day:
            first_balance -= off_vaction_day

        vacation_data_form = Vacation_dataForm(request.POST, instance=new_vaca_obj)

        if vacation_data_form.is_valid():
            fromdate = vacation_data_form.cleaned_data['fromdate']
            todate = vacation_data_form.cleaned_data['todate']

            type_vacation = vacation_data_form.cleaned_data['type_vacation']
            employee = vacation_data_form.cleaned_data['employee']
            betweendate = vacation_data_form.cleaned_data['betweendate']
            dateprocess = vacation_data_form.cleaned_data['dateprocess']
            off_vaction_day = OfficialVacations.objects.filter(date_offi_v__gt=fromdate, date_offi_v__lte=todate,
                                                               date_offi_v__year=datetime.date.today().year).count()

            sql = BalanceVacations.objects.get(employee=employee, v_type=type_vacation, balance_year=dateprocess.year)
            sql.current_balance_day = sql.current_balance_day - betweendate + first_balance
            if off_vaction_day:
                sql.current_balance_day += off_vaction_day
            sql.save()
            vacation_data_form.save()
            messages.success(request, _("Update Successfully "))
            return redirect('display_vacation')

        else:
            vacation_data_form = Vacation_dataForm(request.POST)

            context = {
            # 'c_b': current_balance,
            'vacation_data_form': vacation_data_form,

            }
    else:

        y = (new_vaca_obj.fromdate).year
        queryset = BalanceVacations.objects.get(employee=new_vaca_obj.employee,
                                                v_type=new_vaca_obj.type_vacation, balance_year=y)

        current_balance = queryset.current_balance_day + new_vaca_obj.betweendate

        form = Vacation_dataForm(instance=new_vaca_obj)

        context = {
            'msg': _("This Employee Is On Vacation Now:You Can Edit It"),
            'c_b': current_balance,
            'vacation_data_form': form,
            'v_id': vacation_id,

        }

    return render(request, 'employeeattendance/vacation_request.html', context)

@login_required(login_url='login')
def get_vacation_day(request):
    '''
    تستدعى هذه الدالة بالأجاكس من واجهة طلب اجازة 
    تعمل على فحص المدة المدخلة من قبل المستخدم 
    وترجع برسالة خطأ اذا كانت الفترة خارج الرصيد المسموح
    '''
    print('W'*44)   

    fromdate = parse_date(request.GET.get('from_date'))
    todate = parse_date(request.GET.get('to_date'))
    emp = request.GET.get('emp')
    type_v = request.GET.get('type_v')
    v_id = request.GET.get('v_id')
    bet = (todate - fromdate).days
    

    if fromdate < todate:
        

        off_vaction_day = OfficialVacations.objects.filter(date_offi_v__gt=fromdate, date_offi_v__lte=todate,
                                                           date_offi_v__year=datetime.date.today().year).count()
        print(off_vaction_day)
        first_balance = 0
        if v_id:
            chk = Vacation_request.objects.get(pk=int(v_id))
            print(chk.betweendate)
            first_balance = chk.betweendate
            off_v = OfficialVacations.objects.filter(date_offi_v__gt=chk.fromdate, date_offi_v__lte=chk.todate,
                                                     date_offi_v__year=datetime.date.today().year).count()
            if off_v:
                first_balance =first_balance - off_v
        between = (todate - fromdate).days

        if off_vaction_day:
            between -= off_vaction_day

        sql = BalanceVacations.objects.get(employee=emp, v_type=type_v, balance_year=datetime.date.today().year)

        if sql.current_balance_day + first_balance < between:
            count=sql.current_balance_day + first_balance
            time=fromdate
            while count > 0:
                time=time + datetime.timedelta(days=1)
                v=OfficialVacations.objects.filter(date_offi_v=time)
                if not v:
                    count=count-1
            
            resulte = {'state': 0, 'ms':(todate - fromdate).days,'date':time}
        else:
            if fromdate.year == todate.year:
                resulte = {'state': 1, 'ms': bet}
            else:
                resulte = {'state': 0, 'ms':(todate - fromdate).days,'date':(datetime.datetime(fromdate.year, 12, 31)).date()}
    else:
        print('r'*44)   
        time = fromdate + datetime.timedelta(days=1)

        resulte = {'state': -1, 'ms': bet,'date':time}
    return JsonResponse(resulte)

@login_required(login_url='login')
def request_vacation(request, pk):  
    '''
     تعمل هذه الدالة منح اجازات للموظفين 
    '''
    # request.session["open_menu"] = {"Employees_attendaces": "menu-open"}
    # request.session["top_menu"] = {"Employees_attendaces": "active"}
    # request.session["sub_menu"] = {"vacation": "active"}
    
    date_now = datetime.date.today()
    context = {}
    if request.method == "POST":
        vacation_data_form = Vacation_dataForm(request.POST or None)
        print('#'*66)
        if vacation_data_form.is_valid():
            print('*'*77)
            fromdate = vacation_data_form.cleaned_data['fromdate']
            todate = vacation_data_form.cleaned_data['todate']
            type_vacation = vacation_data_form.cleaned_data['type_vacation']
            employee = vacation_data_form.cleaned_data['employee']
            betweendate = vacation_data_form.cleaned_data['betweendate']
            dateprocess = vacation_data_form.cleaned_data['dateprocess']

            off_vaction_day = OfficialVacations.objects.filter(date_offi_v__gt=fromdate, date_offi_v__lte=todate,
                                                               date_offi_v__year=datetime.date.today().year).count()

            sql = BalanceVacations.objects.get(employee=employee, v_type=type_vacation, balance_year=dateprocess.year)
            sql.current_balance_day = sql.current_balance_day - betweendate
            if off_vaction_day:
                sql.current_balance_day += off_vaction_day

            sql.save()
            vacation_data_form.save()
            messages.success(request, _("Add Successfully "))

            return redirect('display_vacation')
        else:
            vacation_data_form = Vacation_dataForm(request.POST)

            context = {
            # 'msg': _('ADD NEW VACTION'),
            # 'c_b': current_balance,
            'vacation_data_form': vacation_data_form,

            }
    else:
        print('@'*77)

        queryset = get_object_or_404(BalanceVacations, pk=pk)
        new_vaca_obj = Vacation_request()
        new_vaca_obj.employee = queryset.employee
        new_vaca_obj.type_vacation = queryset.v_type
        current_balance = queryset.current_balance_day

        try:
            chk = Vacation_request.objects.get(employee=queryset.employee,
                                               todate__gte=date_now)
            return redirect('edit_vacation', chk.pk)

        except Vacation_request.DoesNotExist:
            print('^'*33,)
            new_vaca_obj.fromdate = date_now
            vacation_data_form = Vacation_dataForm(instance=new_vaca_obj)

        context = {
            'msg': _('ADD NEW VACTION'),
            'c_b': current_balance,
            'vacation_data_form': vacation_data_form,

        }
        print('End'*5)

    return render(request, 'employeeattendance/vacation_request.html', context)

@login_required(login_url='login')
def stop_vacation(request, pk):
    '''
    تعمل هذه الدالة على ايقاف الاجازة الحالية للموظف
    واستقطاع الايام المنقضية من تاريخ بدائية الاجازة 
    حتى تاريخ اليوم من ارصدة اجازات الموظف واستعادة المتبقي
    '''
    # request.session["open_menu"] = {"Employees_attendaces": "menu-open"}
    # request.session["top_menu"] = {"Employees_attendaces": "active"}
    # request.session["sub_menu"] = {"vacation": "active"}
    vacation_obj = get_object_or_404(Vacation_request, id=pk)

    if vacation_obj.todate > date_now:

        off_vaction_day = OfficialVacations.objects.filter(date_offi_v__gt=date_now,
                                                           date_offi_v__lte=vacation_obj.todate,
                                                           date_offi_v__year=datetime.date.today().year).count()

        time_pass = (date_now - vacation_obj.fromdate).days
        time_remain = vacation_obj.betweendate - time_pass
        vacation_obj.betweendate = time_pass
        vacation_obj.todate = date_now

        queryset = BalanceVacations.objects.get(employee=vacation_obj.employee,
                                                v_type=vacation_obj.type_vacation,
                                                balance_year=(vacation_obj.dateprocess).year)

        queryset.current_balance_day = queryset.current_balance_day + int(time_remain)
        if off_vaction_day:
            queryset.current_balance_day -= off_vaction_day

        queryset.save()
        if time_pass == 0:
            vacation_obj.delete()
        else:

            vacation_obj.save()

        queryset.save()
        messages.success(request, _("Stop Successfully "))
    elif vacation_obj.todate == date_now:
        messages.success(request, _("Can Not Stop This Vacations It Fineshed "))

    return redirect('display_vacation')

@login_required(login_url='login')
@permission_required('employeeattendance.add_officialvacations', raise_exception=True)
def weekend_vacation(request):
    """
    تعمل هذه الدالة على تهيئة عطلات نهاية الاسبوع للعام الحالي
    """
    # request.session["top-menu"] = {"Employees_attendaces": "active"}
    # request.session["sub_menu"] = {"weekend_vacation": "active"}

    if request.method == 'POST':
        queryset = OfficialVacations.objects.filter(type_offi_v='Weekend', date_offi_v__year=datetime.date.today().year)
        if not check_emp_vacation():
            if queryset:
                queryset.delete()
            weekend = request.POST.getlist('week_list')
            this_year = datetime.date.today().year
            count = 0
            startdate = datetime.datetime(this_year, 1, 1)
            while 1:
                time = startdate + datetime.timedelta(days=count)
                if time.date().year > startdate.date().year:
                    break
                day = time.date().strftime("%A")
                m = time.date().month
                date = time.date()
                if day in weekend:

                    new_vac = OfficialVacations.objects.create(day_name=day,
                                                                type_offi_v='Weekend', month_number=m, date_offi_v=date,
                                                                descript_offi_v='', created_date=datetime.date.today())
                    old_vac = OfficialVacations.objects.filter(date_offi_v=date).exclude(type_offi_v='Weekend')
                    if old_vac:
                        old_vac.delete()
                count = count + 1
            messages.success(request, _("Add Successfully "))
            return redirect('select_month_v_off')
        else:
            messages.error(request,_('Sorry, The Current Record Cannot be (update) Because it is Related to Other Processes '))
            return redirect('weekend_vacation')


    weekendlist = []
    msg = ''
    queryset = OfficialVacations.objects.filter(type_offi_v='Weekend', date_offi_v__year=datetime.date.today().year)
    if queryset:
        weekend = {}
        for x in queryset:
            weekend[x.day_name] = x.day_name
        weekendlist = list(weekend.keys())
        msg = _('Weekly vacations have been created for this year and can be re-created here')

    year = datetime.date.today().year
    context = {'week': week, 'msg': msg, 'weekendlist': weekendlist, 'year': year}

    return render(request, 'employeeattendance/weekend_vacation.html', context)

    year = datetime.date.today().year
    context = {'week': week, 'msg': msg, 'weekendlist': weekendlist, 'year': year}

    return render(request, 'employeeattendance/weekend_vacation.html', context)

def check_emp_vacation():
    '''
     تعمل هذه الدالة على فحص هل يوجد اجازة للموظف ما لم تنتهي بعد 
     
    '''
    if Vacation_request.objects.filter(todate__gte=datetime.date.today()):
        return True
    else:
        return False
        
@permission_required('employeeattendance.add_officialvacations', raise_exception=True)
@login_required(login_url='login')
def month_vacation_offi(request, month):
    '''
    تعمل هذه الدالة على تهيئة العطلات الرسمية 
    تاخذ رقم الشهر وترجع بقايمة بتواريخ الشهر والايام 
    يمكن للمستخدم من اختيار التاريخ الذي يعتبر اجازة رسمية 
    '''
    year = datetime.date.today().year

    if request.method == 'POST':

        if not check_emp_vacation():
            date_list = request.POST.getlist('date_list')
            if date_list:
                for value_form in date_list:
                    selectname = 'type' + value_form
                    txtname = 'dsc' + value_form
                    get_type_v = request.POST.get(selectname)
                    get_descrpt = request.POST.get(txtname)
                    new_date = datetime.datetime.strptime(value_form, '%Y-%m-%d')
                    date = new_date.date()
                    day = new_date.date().strftime("%A")
                    m = new_date.date().month
                    new_vac = OfficialVacations.objects.create(day_name=day,
                                                            type_offi_v=get_type_v, month_number=m, date_offi_v=date,
                                                            descript_offi_v=get_descrpt,
                                                            created_date=datetime.date.today())
            messages.success(request, _("Add Successfully "))
            return redirect('select_month_v_off')
        else:
            # messages.success(request, _("Add Error"))
            messages.error(request,_('Sorry, The Current Record Cannot be (update) Because it is Related to Other Processes'))
            return redirect('month_vacation_offi', month)

    else:  # init date of this month and display it in bag  to select vacations days
        queryset = OfficialVacations.objects.filter(type_offi_v='Weekend', date_offi_v__year=datetime.date.today().year)
        if not queryset:
            return redirect('weekend_vacation')
        queryset = OfficialVacations.objects.filter(date_offi_v__year=datetime.date.today().year,
                                                    date_offi_v__month=month).exclude(type_offi_v='Weekend')
        if queryset:
            return redirect('update_offi_vacation', month, ' ')

        queryset = OfficialVacations.objects.filter(type_offi_v='Weekend', date_offi_v__year=datetime.date.today().year)
        weekend = {}
        for x in queryset:
            weekend[x.day_name] = x.day_name

        weekendlist = list(weekend.keys())

        this_year = datetime.date.today().year
        count = 0
        startdate = datetime.datetime(this_year, month, 1)
        dc = {}
        datelist = []
        while 1:
            time = startdate + datetime.timedelta(days=count)
            if time.date().month > month or time.date().year > this_year:
                break
            if time.date().strftime("%A") not in weekendlist:
                dc = {}
                for k, v in week.items():
                    if k == time.date().strftime("%A"):
                        dc['day'] = v
                dc['m'] = time.date().month
                dc['dat'] = datetime.datetime.strftime(time.date(), '%Y-%m-%d')
                datelist.append(dc)
                dc.clear
            count = count + 1

    return render(request, 'employeeattendance/month_vacation_offi.html',
                  {'type_vaca': type_officialvacations, 'datelist': datelist, 'month': month, 'year': year})

@permission_required('employeeattendance.add_officialvacations', raise_exception=True)
@login_required(login_url='login')
def select_month_offi(request):
    '''
    تستخدم هذه الدالة في تهيئة العطلات الرسمية 
    حيث ترض قايمة بالاشهر حيث يمكن للمستخدم اختيار 
    الشهر الذي يريد تهئية العطلات الرسمية له 
    '''
    # request.session["open_menu"] = {"Employees_attendaces": "menu-open"}
    # request.session["top_menu"] = {"Employees_attendaces": "active"}
    # request.session["sub_menu"] = {"select_month_offi": "active"}
    queryset = OfficialVacations.objects.filter(type_offi_v='Weekend', date_offi_v__year=datetime.date.today().year)
    if not queryset:
        return redirect('weekend_vacation')
    year = datetime.date.today().year
    if request.method == 'POST':
        month = request.POST.get('month')

        return redirect('month_vacation_offi', month)
    queryset = OfficialVacations.objects.values_list('month_number', flat=True).filter(
        date_offi_v__year=datetime.date.today().year).exclude(type_offi_v='Weekend').distinct()

    month_number = list(queryset)

    return render(request, 'employeeattendance/select_month_v_off.html', {'year': year, 'month': queryset})

@permission_required('employeeattendance.view_officialvacations', raise_exception=True)
@login_required(login_url='login')
def disblay_offi(request):
    '''
    تعمل هذه الدالة على عرض العطلات الرسمية  الحالية 
    '''
    # request.session["open_menu"] = {"Employees_attendaces": "menu-open"}
    # request.session["top_menu"] = {"Employees_attendaces": "active"}
    # request.session["sub_menu"] = {"disblay_offi": "active"}
    type12 = {
        'Feast': _('Feast'),
        'National': _('National'),
        'Other': _('Other'),
        'Weekend': _('Weekend'),
    }
    permission = {
        'delete': request.user.has_perm('employeeattendance.delete_officialvacations'),
        'change': request.user.has_perm('employeeattendance.change_officialvacations'),
    }

    year = datetime.date.today().year
    vacation_data = OfficialVacations.objects.filter(date_offi_v__year=datetime.date.today().year,
                                                     type_offi_v='Weekend')
    m = 0
    if request.method == 'POST':
        month = request.POST.get('month')
        if month == '0':
            vacation_data = OfficialVacations.objects.filter(date_offi_v__year=datetime.date.today().year,
                                                             type_offi_v='Weekend')
        else:
            vacation_data = OfficialVacations.objects.filter(month_number=month,
                                                             date_offi_v__year=datetime.date.today().year).exclude(
                type_offi_v='Weekend')
            m = month

    return render(request, 'employeeattendance/disblay_offi_vacation.html',
                  {'vacation_data': vacation_data, 'year': year, 'week': week, 'type': type12, 'm': m,
                   'permission': permission})

@login_required(login_url='login')
@permission_required('employeeattendance.change_officialvacations', raise_exception=True)
def update_offi_vacation(request, month, type_vacation):
    '''
    تعمل هذ الدالة على تعديل العطلات الرسمية  تستقبل 
    الشهر ونوع العطلة وترجع بقائيمة بتواريخ الشهر المرسل 
    '''
    if type_vacation == 'Weekend':
        return redirect('weekend_vacation')

    queryset = OfficialVacations.objects.filter(month_number=month, date_offi_v__year=datetime.date.today().year)
    this_year = datetime.date.today().year

    # week=['Saturday','Sunday','Monday','Tuesday','Wednesday','Thursday','Friday']
    
    if request.method == 'POST':  # get vacations selected and save it to db
        date_list_hide = request.POST.getlist('date_list_hide')
        date_list = request.POST.getlist('date_list')
        if not check_emp_vacation() or (set(date_list) == set(date_list_hide)):

            queryset = OfficialVacations.objects.filter(date_offi_v__in=date_list_hide).exclude(date_offi_v__in=date_list)
            if queryset:
                queryset.delete()

            if date_list:
                for value_form in date_list:
                    selectname = 'type' + value_form
                    txtname = 'dsc' + value_form
                    get_type_v = request.POST.get(selectname)
                    get_descrpt = request.POST.get(txtname)
                    new_date = datetime.datetime.strptime(value_form, '%Y-%m-%d')
                    date = new_date.date()
                    day = new_date.date().strftime("%A")
                    m = new_date.date().month
                    if value_form in date_list_hide:
                        new_vac = OfficialVacations.objects.get(date_offi_v=date,
                                                                date_offi_v__year=datetime.date.today().year)
                        new_vac.descript_offi_v = get_descrpt
                        new_vac.type_offi_v = get_type_v
                        new_vac.save()
                    else:

                        new_vac = OfficialVacations.objects.create(day_name=day,
                                                                type_offi_v=get_type_v, month_number=m, date_offi_v=date,
                                                                descript_offi_v=get_descrpt,
                                                                created_date=datetime.date.today())

            messages.success(request, _("Update Successfully "))
            return redirect('disblay_offi')
        else:
            messages.error(request,_('Sorry, The Current Record Cannot be (update) Because it is Related to Other Processes '))
            return redirect('update_offi_vacation', month, ' ')

    else:  # init date of this month and display it in pag  to select vacations days
        activ_date = []
        dc_val = {}
        queryset = OfficialVacations.objects.filter(date_offi_v__year=datetime.date.today().year,
                                                    date_offi_v__month=month).exclude(type_offi_v='Weekend')
        for d in queryset:
            activ_date.append(d.date_offi_v)
            p = datetime.datetime.strftime(d.date_offi_v, '%Y-%m-%d')
            dc_val[p] = {'ty': d.type_offi_v, 'dec': d.descript_offi_v}

        queryset = OfficialVacations.objects.filter(type_offi_v='Weekend', date_offi_v__year=this_year)
        weekend = {}
        for x in queryset:
            weekend[x.day_name] = x.day_name

        weekendlist = list(weekend.keys())
        count = 0
        startdate = datetime.datetime(this_year, month, 1)

        dc = {}
        datelist = []
        while 1:
            time = startdate + datetime.timedelta(days=count)
            if time.date().month > month or time.date().year > this_year:
                break
            if time.date().strftime("%A") not in weekendlist:

                dc = {}
                for k, v in week.items():
                    if k == time.date().strftime("%A"):
                        dc['day'] = v
                dc['m'] = time.date().month
                dc['dat'] = datetime.datetime.strftime(time.date(), '%Y-%m-%d')
                if time.date() in activ_date:
                    dc['active'] = True
                    p = datetime.datetime.strftime(time.date(), '%Y-%m-%d')
                    dc['ty'] = dc_val[p]['ty']
                    dc['dec'] = dc_val[p]['dec']

                else:
                    dc['active'] = False
                    dc['ty'] = ''
                    dc['dec'] = ''
                datelist.append(dc)
                dc.clear
            count = count + 1

    return render(request, 'employeeattendance/month_vacation_offi_update.html',
                  {'type_vaca': type_officialvacations, 'datelist': datelist, 'week': week})

@login_required(login_url='login')
def delete_offi_vacation(request, pk):
    '''
    تعمل هذه الدالة على حذف العطلات الرسمية 
    '''
    if not check_emp_vacation():
        queryset = get_object_or_404(OfficialVacations, pk=pk)
        if queryset.type_offi_v == 'Weekend':
            queryset = OfficialVacations.objects.filter(type_offi_v='Weekend', day_name=queryset.day_name)

        queryset.delete()
        messages.success(request, _("Delete Successfully "))
        return redirect('disblay_offi')
    else:
        messages.error(request,_('Sorry, The Current Record Cannot be (delete) Because it is Related to Other Processes'))
        return redirect('disblay_offi')

def get_adminstration_period_months(request):
    """
   ترجع هذه الدالة بأشهر الفترات الادارية 
    """
    if request.is_ajax and request.method == "GET":
        period_id = request.GET.get('period_id')
        period_date_text = request.GET.get('period_date_text')

        period_type = AdministrativePeriods.objects.values('period_type').filter(pk=period_id)

        list_month = set()
        if period_type:
            if period_type[0]['period_type'] == 'Monthly':
                arry = re.split('/|-', period_date_text)
                if int(arry[2]) < 12:
                    month2 = str(int(arry[2]))
                    year2 = arry[3]
                else:
                    month2 = '12'
                    year2 = str(int(arry[3]))

                start = datetime.datetime.strptime(arry[1] + '-' + arry[0] + '-' + "1", "%Y-%m-%d")
                end = datetime.datetime.strptime(year2 + '-' + month2 + '-' + "1", "%Y-%m-%d")

                date_array = \
                    (start + datetime.timedelta(days=x) for x in range(0, (end - start).days, 27))
                for date_object in date_array:
                    list_month.add((date_object.strftime("%m"), _(date_object.strftime("%B"))))

            else:
                period_details = AdministrativePeriodsDetiles.objects.values('id', 'from_date_for_fingerprint',
                                                                             'to_date_for_fingerprint').filter(
                    administrative_period=int(period_id))
                for date in period_details:
                    list_month.add((date['id'], str(date['from_date_for_fingerprint']) + ' / ' + str(
                        date['to_date_for_fingerprint'])))
        return JsonResponse({"success": 'success', 'data': list(list_month)})

def get_organizational_chart_employees(request):
    """
    تستدعى هذه الدالة من واجهة احتساب الحضور والغياب عند ما يختار
    المستخدم الوحده الادارية ترجع لة بقايمة الموظفين التابعين 
    للوحدة الادارية المختارة 
    """
   
    if request.is_ajax and request.method == "GET":
        organizational_chart_id = request.GET.get('organizational_chart_id')
        organizational_chart_text = request.GET.get('organizational_chart_text')
        employees_id = EmployeeFunctionalData.objects.values('employee_id').filter(
            organizational=organizational_chart_id).order_by('employee_id')

        employees_name = list()
        if employees_id is not None:
            for emp_id in employees_id:
                emp = Emp_data.objects.values('id', 'arname').filter(pk=emp_id['employee_id']).order_by(
                    'id')
                employees_name.append((emp[0]['id'], emp[0]['arname']))
        return JsonResponse({"success": 'success', 'data': employees_name})

def get_period_details_date(request):
    """
    تستدعى هذه الدالة من واجهة احتساب الحضور والغياب 
    عندما يختار المستخدم شهر الفترة الادارية 
     ترجع بتاريخ الفترة من تاريخ الى تاريخ
    """
  
    if request.is_ajax and request.method == "GET":
        print('ZZZZZZZZZZZZZZZZZZZ')
        period_id = request.GET.get('period_id')
        period_date_text = request.GET.get('period_date_text')
        period_details_id = request.GET.get('period_details_id')
        set_date = set()
        period_type = AdministrativePeriods.objects.values('period_type').filter(pk=int(period_id))
        list_month = set()
        if period_type:
            if period_type[0]['period_type'] == 'Monthly':
                date_array = AdministrativePeriodsDetiles.objects.values('id', 'from_date_for_fingerprint',
                                                                         'to_date_for_fingerprint').filter(
                    administrative_period=int(period_id))
                for date in date_array:
                    if date['from_date_for_fingerprint'].strftime("%m") == period_details_id:
                        set_date.add((date['from_date_for_fingerprint'], date['to_date_for_fingerprint']))
            else:
                period_details = AdministrativePeriodsDetiles.objects.values('id', 'from_date_for_fingerprint',
                                                                             'to_date_for_fingerprint').filter(
                    pk=(period_details_id))
                for date in period_details:
                    set_date.add((date['from_date_for_fingerprint'], date['to_date_for_fingerprint']))

        return JsonResponse({"success": 'success', 'data': list(set_date)})

@permission_required('employeeattendance.add_calculateatendanceandleave', raise_exception=True)
def CalculateAttendanceAndLeave(request):
    """
    تعمل هذه الدالة على احتساب الحضور والغياب للموظفين 
    المختارين 
    create function for Calculate Attendance And Leave
    """
    # request.session["open_menu"] = {"Employees_attendaces": "menu-open"}
    # request.session["top_menu"] = {"Employees_attendaces": "active"}
    # request.session["sub_menu"] = {"attendance_and_leave": "active"}
    form = CalculateAttendanceAndLeaveForm(request.POST or None)
    STATUS = (
        ('Abcent', _('Abcent')),
        ('Attendee', _('Attendee')),
        ('Official vacation', _('Official vacation')),
        ('Taken vacation', _('Taken vacation')),
    )
    all_employee = list()
    employees = list()
    data = None
    if request.method == 'POST':
        employeeFunctionalData = EmployeeFunctionalData.objects.all()
        joinEmployeeWithWorkPeriod = JoinEmployeeWithWorkPeriod.objects.all()
        if form.is_valid():
            from_date1 = form.cleaned_data.get('from_date')
            to_date1 = form.cleaned_data.get('to_date')
            if from_date1 > datetime.date.today():
                data = {
                    'msg': _("Attendance and leave cannot be calculated for a period that has not yet been worked on"),
                    'state': 1}
                return JsonResponse(data)
            with transaction.atomic():
                CalculateAtendanceAndLeaveDetails.objects.all().delete()          
                CalculateAtendanceAndLeave.objects.all().delete()
                if form.cleaned_data.get('all_employee') == True:
                    '''
                    If all employees want'''
                    all_employee = employeeFunctionalData.values('employee_id').filter(
                        employee_id__emp_status=True).order_by('employee_id')
                else:
                    '''
                    If employees want an administrative unit
                    '''
                    organizational_chart = int(form.cleaned_data.get('organizational_chart'))
                    all_employee = employeeFunctionalData.values('employee_id').filter(
                        organizational=organizational_chart, employee_id__emp_status=True).order_by('employee_id')
                if all_employee and joinEmployeeWithWorkPeriod:
                    '''
                    We call this function to synchronize fingerprints from fingerprint device
                    '''
                    from fingerprintdevices.views import pull_fingerprints
                    # try:
                    #     msg, state = pull_fingerprints()
                    #     if state == 0:
                    #         data = {'msg': _("There is no fingerprint hardware"), 'state': 3}
                    # except:
                    #     pass
                for employee in (all_employee):
                    '''
                    For the passage of all employees
                    '''
                    from_date = form.cleaned_data.get('from_date')
                    to_date = form.cleaned_data.get('to_date')
                    start_date = from_date
                    end_date = to_date
                    count_days = (to_date - from_date).days + 1
                    date_array = (from_date + datetime.timedelta(days=x) for x in range(0, count_days))
                    for date_object in date_array:
                        '''
                        To pass all days (date)
                        '''
                        employee_work_period_and_policy = joinEmployeeWithWorkPeriod.filter(
                            Q(from_date__lte=date_object,to_date__gte=date_object) | Q(from_date__lte=date_object,to_date=None),
                            work_period__is_active=True, employee=employee['employee_id']).exclude(
                            )
                        try:
                            if employee_work_period_and_policy:
                                for work_period_and_policy in employee_work_period_and_policy:
                                    is_active, attendance_beginning, attendance_ending, leaving_beginning, leaving_ending, type_finger = work_period_and_policy.get_time_period_and_policy(date_object)
                                    if is_active:
                                        work_period_and_policy.attendance_calculate(date_object , attendance_beginning, attendance_ending, leaving_beginning, leaving_ending, type_finger)
                                    else:
                                        CalculateAtendanceAndLeave.objects.update_or_create(
                                        employee_id=employee['employee_id'],
                                        date=date_object,
                                            )
                                        calc_id = CalculateAtendanceAndLeave.objects.last()
                                        accept_date = EmployeeFunctionalData.objects.values('accept_date').filter(
                                            employee=employee['employee_id'])
                                        if accept_date[0]['accept_date'] > date_object:
                                            success = add_data_calculate_attendence(calc_id, work_period_and_policy.policy, work_period_and_policy.work_period, 0, 0, '00:00:00',
                                                                                    '00:00:00', STATUS[0][0], 0)
                                        else:
                                            success = add_data_calculate_attendence(calc_id, work_period_and_policy.policy, work_period_and_policy.work_period, 0, 0, '00:00:00',
                                                                                    '00:00:00', STATUS[2][0], 0)

                        except Exception as e:
                            print(e)
            Emp = CalculateAtendanceAndLeave.objects.values('employee').filter(employee_id__in=all_employee).distinct('employee')
            for emp1 in Emp:
                emp_data = Emp_data.objects.values('arname').filter(pk=emp1['employee'])
                employees.append({'id': emp1['employee'], 'name': emp_data[0]['arname']})
            if employees == []:
                data = {'msg': _(
                    "Sorry,There are no employees for this month Or that employees are not related to work periods"),
                    'state': 1}
                return JsonResponse(data)
            if data != None:
                print('*'*40)
                print(employees)
                print('*'*40)

                return JsonResponse({
                    'table': render_to_string('employeeattendance/employee_calculate.html', {'employees': employees})
                    , 'state': 3,
                    'msg': data['msg'],
                })
            return render(request, 'employeeattendance/employee_calculate.html', {'employees': employees})
    return render(request, 'employeeattendance/calculate_attendance_and_leave.html', {'form': form})

def add_data_calculate_attendence(calc_id, working_policy, work_period, delay_minute_sum, additional_minute_sum,
                                  attendance_time, leave_time, statue, early_departure_minute_sum):
    """
    تستدعى هذه من دالة احتساب الحضور والغياب
    لأظافة تفاصيل الحضور
    تستقبل الموظف , سياسة,العمل, وفترة العمل, ومجموع دقائق التأخير
      والزيادة , وقت الحضور ,الانصراف ,الحالة, دقائق الانصراف المبكر   
    """
    CalculateAtendanceAndLeaveDetails.objects.create(
        working_policy=working_policy.id,
        work_period_id=work_period.id,
        delay_minute_sum=delay_minute_sum,
        additional_minute_sum=additional_minute_sum,
        attendance_time=attendance_time,
        leave_time=leave_time,
        calculate_atendance_and_leave=calc_id,
        statue=statue,
        early_departure_minute_sum=early_departure_minute_sum,
    )
    return True

def view_attendee_and_leave(request, id):
    '''
    تستدعى هذه الدالة من واحهة احتساب الحضور والغياب
    لعرض تفاصيل الحضور والغياب للموظف المحدد تستفبل رقم 
    الموظف وترجع باالتفاصيل 
    '''
    if request.method == "POST":
        from_date = request.POST.get('from_date')
        to_date = request.POST.get('to_date')
        calculateAtendanceAndLeaveDetails = CalculateAtendanceAndLeaveDetails.objects.all()
        id_employee = id
        employee = Emp_data.objects.values('arname').filter(pk=id)
        data_employee = list()
        work_period = JoinEmployeeWithWorkPeriod.objects.values('work_period', 'work_period__name').filter(
            # Q(from_date__lte=from_date,to_date__gte=to_date) | Q(from_date__lte=from_date,to_date=None),
            employee=id_employee, work_period__is_active=True).exclude(
                from_date__gt=to_date,to_date__lt=from_date,
            ).order_by('work_period_id').distinct('work_period')
        # work_period = JoinEmployeeWithWorkPeriod.objects.values('work_period', 'work_period__name').filter(
        #     Q(from_date__lte=from_date,to_date__gte=to_date) | Q(from_date__lte=from_date,to_date=None),
        #     employee=id_employee, work_period__is_active=True).order_by('work_period_id').distinct('work_period')
        period_list = list()
        period_record = list()
        for period in work_period:
            period_list.append({'name_period': period['work_period__name'], 'id': period['work_period']})
        date_calculate = CalculateAtendanceAndLeave.objects.values('id', 'date').filter(employee=id_employee)

        for data_emp in date_calculate:
            period_record = []
            for per_list in period_list:
                details = calculateAtendanceAndLeaveDetails.values('attendance_time', 'leave_time', 'statue').filter(
                    calculate_atendance_and_leave__date=(data_emp['date']), calculate_atendance_and_leave__employee=id,
                    work_period=int(per_list['id']))
                if details:
                    if details[0]['attendance_time'] == parse_time('00:00:00') and details[0][
                        'leave_time'] == parse_time('00:00:00'):
                        period_record.append({
                            'attendance_time': ' ',
                            'leave_time': ' ',
                            'statue':_(details[0]['statue'])
                        })
                    else:
                        period_record.append({
                            'attendance_time': details[0]['attendance_time'],
                            'leave_time': details[0]['leave_time'],
                            'statue': _(details[0]['statue'])
                        })
                else:
                    period_record.append({
                            'attendance_time': '',
                            'leave_time': '' ,
                            'statue':_('------------')
                        })

            data_employee.append({'date': data_emp['date'], 'record': period_record})
    return render(request, 'employeeattendance/view_calculate_attendee_and_leave.html',
                  {'name': employee[0]['arname'], 'period': period_list, 'data': data_employee})

@login_required(login_url='login')
def employee_vacation_request_report(request):   
    """
     تستدعى عند طلب تقارير الاجازات 
    ترجع هذه الدالة بكافة الادارة الموجودة 
    """
    # request.session["open_menu"] = {"reporter": "menu-open"}
    # request.session["top_menu"] = {"employeeattendance": "active"}
    # request.session["sub_menu"] = {"vacation_report": "active"}

    organizationalchart = OrganizationalChart.objects.all().order_by('id')
    data = {
        'organizationalchart': organizationalchart,

    }
    return render(request, "reports/vacation_to_employees_report.html", data)

def get_employee_organization_vacation_request(request):
    """
    تستدعى هذه الدالة من واجهة تقرير الاجازات 
    تستقبل الادارة المختارة من قبل المستخدم 
    وترجع بكافة الموظفين التابعين لهذه الإدارة
    """

    if request.is_ajax and request.method == "GET":
        organizational_chart = request.GET.get('organizational_chart')
        employee1 = set(Vacation_request.objects.values_list('employee'))
        employee2 = list(employee1)
        emp = list()
        for i in employee2:
            emp.append(i[0])
        emp2 = EmployeeFunctionalData.objects.filter(employee__in=emp, 
                                                     organizational_id=organizational_chart).order_by(
            'employee')
        emp3 = Emp_data.objects.filter(EmployeeFunctionalDatas__in=emp2)
        data = serializers.serialize('json', emp2)
        data1 = serializers.serialize('json', emp3)
        return JsonResponse({"success": "success", "data": data, 'data1': data1}, status=200)
    else:
        return JsonResponse({"success": 'fail'}, status=400)

def get_employees_vacation_request_organization(request):   
    '''
    تستدعى هذه الدالة من واجهة تقارير الاجازات عند ما يختار المستخدم 
    عرض تقارير الاجازات من موظف الى موظف  عند النقر عل زر بحث 
    ترجع بالاجازات الموجودة للموظفين المحددين
    '''
    from_employee_id = 0
    to_employee_id = 0
    organizationalchar_id = 0
    employees = EmployeeFunctionalData.objects.all()
    if request.is_ajax and request.method == 'GET':
        organizationalchar_id = request.GET.get('organizationalchar_id')
        from_employee_id = request.GET.get('from_employee_id')
        to_employee_id = request.GET.get('to_employee_id')
        to_date = request.GET.get('to_date')
        from_date = request.GET.get('from_date')
        to_date = parse_date(to_date)
        from_date = parse_date(from_date)
        if from_employee_id == to_employee_id:
            employees = EmployeeFunctionalData.objects.values('employee', 'employee__enname').filter(
                employee_id=int(to_employee_id)).all().distinct('employee')
        elif from_employee_id < to_employee_id:
            employees = EmployeeFunctionalData.objects.values('employee', 'employee__enname').filter(
                employee_id__gte=int(from_employee_id), employee_id__lte=int(to_employee_id),
                organizational=int(organizationalchar_id)).all().distinct('employee')
        elif from_employee_id > to_employee_id:
            from_employee_id, to_employee_id = to_employee_id, from_employee_id
            employees = EmployeeFunctionalData.objects.values('employee', 'employee__enname').filter(
                employee_id__gte=int(from_employee_id), employee_id__lte=int(to_employee_id),
                organizational=int(organizationalchar_id)).all().distinct('employee')
        empdata = {}
        data = {}
        all_empdata_list = list()
        for i in employees:
            repetition_emp = Vacation_request.objects.filter(employee=i['employee'], dateprocess__gte=from_date,
                                                             dateprocess__lte=to_date).count()
            if repetition_emp != 0:
                empdata = {'name': i['employee__enname'], 'id': i['employee'],
                           'count': repetition_emp,
                           'data': Vacation_request.objects.values('type_vacation__name', 'betweendate', 'fromdate',
                                                                   'todate', 'reason').filter(employee=i['employee'],
                                                                                              dateprocess__gte=from_date,
                                                                                              dateprocess__lte=to_date),
                           }
                all_empdata_list.append(empdata)
        data['recorders'] = all_empdata_list
        data['title'] = _('Vacation Report')
        return render(request, "reports/table_v.html", data)

def all_vacation_request(request):
    '''
    تستدعى هذه الدالة من واجهة تقارير الاجازات عند ما يختار 
    المستخدم عرض تقارير كافة الموظفين
    '''
    if request.is_ajax and request.method == 'GET':
        from_date = request.GET.get('from_date')
        to_date = request.GET.get('to_date')
        to_date = parse_date(to_date)
        from_date = parse_date(from_date)
        employees = Emp_data.objects.values('enname', 'id').all()
        empdata = {}
        data = {}
        all_empdata_list = list()
        for i in employees:
            repetition_emp = Vacation_request.objects.filter(employee=i['id'], dateprocess__gte=from_date,
                                                             dateprocess__lte=to_date).count()
            if repetition_emp != 0:
                empdata = {'name': i['enname'], 'id': i['id'],
                           'count': repetition_emp,
                           'data': Vacation_request.objects.values('type_vacation__name', 'betweendate', 'fromdate',
                                                                   'todate', 'reason').filter(employee=i['id'],
                                                                                              dateprocess__gte=from_date,
                                                                                              dateprocess__lte=to_date),
                           }
                all_empdata_list.append(empdata)
        data['recorders'] = all_empdata_list
        data['title'] = _('Vacation Report')
        return render(request, "reports/table_v.html", data)

def view_sumition_calculate_attendee_and_leave(request):
    ''''
    تستدعى هذه الدالة من واجهة احتساب الحضور والغياب 
    عندما ينقر المستخدم على زر عرض الكل  حيث تعرض ملخص 
    اجمالي ايام الحضور والغياب ودقائق التأخير ودقائق الانصراف المبكر
    '''
    
    STATUS = (
        ('Abcent', _('Abcent')),
        ('Official vacation', _('Official vacation')),
    )
    
    organizational_chart_id =int(request.POST.get('organizational_chart'))
    all_employee =request.POST.get('all_employee') 
    

      
    employees = list()
    if request.method == "POST":
        emp_dat = ''
        calculateAtendanceAndLeaveDetails = CalculateAtendanceAndLeaveDetails.objects.all()
        calculateAtendanceAndLeave = CalculateAtendanceAndLeave.objects.all().order_by('date')
        if all_employee == 'true':
            Emp = CalculateAtendanceAndLeave.objects.values('employee').all().distinct('employee')
        else:
            organization_employee = EmployeeFunctionalData.objects.filter(organizational_id=organizational_chart_id).values('employee')
            # print(organization_employee)
            Emp = CalculateAtendanceAndLeave.objects.values('employee').filter(employee_id__in=organization_employee).distinct('employee')
        
        emp_period = JoinEmployeeWithWorkPeriod.objects.all()
        workPeriodDetail = WorkPeriodDetail.objects.all()
        emp_data = Emp_data.objects.all()

        for emp1 in Emp:
            emp_dat = emp_data.values('arname').filter(pk=emp1['employee'])

            sum_delay_minute = calculateAtendanceAndLeaveDetails.filter(
                calculate_atendance_and_leave__employee=emp1['employee']).aggregate(Sum('delay_minute_sum'))[
                'delay_minute_sum__sum']
            sum_m_extra = calculateAtendanceAndLeaveDetails.filter(
                calculate_atendance_and_leave__employee=emp1['employee']).aggregate(Sum('additional_minute_sum'))[
                'additional_minute_sum__sum']
            sum_m_early = calculateAtendanceAndLeaveDetails.filter(
                calculate_atendance_and_leave__employee=emp1['employee']).aggregate(Sum('early_departure_minute_sum'))[
                'early_departure_minute_sum__sum']
            if sum_delay_minute is not None:
                sum_delay_minute = int(sum_delay_minute)
            else:
                sum_delay_minute = 0

            if sum_m_extra is not None:
                sum_m_extra = int(sum_m_extra)
            else:
                sum_m_extra = 0

            if sum_m_early is not None:
                sum_m_early = int(sum_m_early)
            else:
                sum_m_early = 0

            frist_obj = calculateAtendanceAndLeave.values('date').first()
            last_obj = calculateAtendanceAndLeave.values('date').last()
            first_date = frist_obj['date']
            last_date = last_obj['date']

            count_abcent = 0
            count_attendance = 0
            count_Official_vacation = 0
            # date_array = (first_date + datetime.timedelta(days=x) for x in range(0, (last_date - first_date).days + 1))
            for date_object in calculateAtendanceAndLeave.values('date').distinct('date').order_by('date'):
                count_period = emp_period.filter(
                        # Q(from_date__lte=date_object['date'],to_date__gte=date_object['date']) | Q(from_date__lte=date_object['date'],to_date=None),
                        work_period__is_active=True, employee_id=emp1['employee']).exclude(
                        from_date__gte=date_object['date'],to_date__lte=date_object['date'],
                        ).distinct('work_period').count()
                count_period_abcent = calculateAtendanceAndLeaveDetails.filter(statue='Abcent', 
                        calculate_atendance_and_leave__date=date_object['date'],
                        calculate_atendance_and_leave__employee = emp1['employee']).count()
                count_abcent_period_for_day = calculateAtendanceAndLeaveDetails.values('work_period').filter(
                    calculate_atendance_and_leave__date=date_object['date'], statue=STATUS[0][0],
                    calculate_atendance_and_leave__employee=emp1['employee'])
                count_Official_vacation_for_day = calculateAtendanceAndLeaveDetails.values('work_period').filter(
                    calculate_atendance_and_leave__date=date_object['date'], statue=STATUS[1][0],
                    calculate_atendance_and_leave__employee=emp1['employee'])
                count_attendance_for_day = calculateAtendanceAndLeaveDetails.values('work_period').filter(
                    calculate_atendance_and_leave__date=date_object['date'], statue='Attendee',
                    calculate_atendance_and_leave__employee=emp1['employee'])
                if len(count_abcent_period_for_day) == 0 and count_period == len(count_Official_vacation_for_day) and count_Official_vacation_for_day:
                    count_Official_vacation += 1
                elif count_period != 0 and (count_period == len(count_abcent_period_for_day) or count_period == (
                        len(count_Official_vacation_for_day) + len(count_abcent_period_for_day))):
                    count_abcent += 1
                elif count_period != 0 and len(count_attendance_for_day) != 0:
                    count_attendance += 1
                    for period_day in count_abcent_period_for_day:
                        period_work_details = workPeriodDetail.values('attendance_actual', 'leaving_actual').filter(
                            work_period_name=period_day['work_period'], day=str(date_object['date'].strftime("%A")))

                        sum_delay_minute += period_work_details[0]['leaving_actual'].hour * 60 + period_work_details[0][
                            'leaving_actual'].minute - (period_work_details[0]['attendance_actual'].hour * 60 +
                                                        period_work_details[0]['attendance_actual'].minute)

            employees.append({'id': emp1['employee'], 'name': emp_dat[0]['arname'],
                              'count_Official_vacation': count_Official_vacation, 'count_abcent': count_abcent,
                              'count_attendance': count_attendance, 'sum_delay_minute': sum_delay_minute,
                              'sum_m_extra': sum_m_extra, 'sum_m_early': sum_m_early})
      
    return render(request, 'employeeattendance/view_summition_calculat_attendance.html', {'data': employees})
class TypeOfVacationsView(LoginRequiredMixin,CreateView):
    """
    يستخدم هذا الكلاس لأظافة وحذف وتعديل انواع الإجازات 
    """
    login_url = '/Em/login'
    def get(self, request, *args, **kwargs):
        """
        دالة عرض الواجهة 
        """
        # request.session["open_menu"] = {"Employees_attendaces": "menu-open"}
        # request.session["top_menu"] = {"Employees_attendaces": "active"}
        # request.session["sub_menu"] = {"type_vacations": "active"}

        if 'id' in request.GET.keys():
            if request.GET.get('id'):
                try:

                    data = TypeOfVacations.objects.filter(
                        pk=int(request.GET.get('id')))

                    result = {'status': 1, 'data': serializers.serialize('json', data)}


                except:
                    result = {'status': 0, 'data': 'ee'}

            else:
                result = {'status': 0, 'data': ''}

            return JsonResponse(result)
        else:
            context = {
                'form': NewTypeOfVacations(),
                'url': reverse('TypeOfVacationsView'),
                'title_form': _(" Add Vacations Type"),
                'title_list': _("Vacations Types"),
                'urljson': reverse('TypeOfVacationsJson'),
                'permission': request.user.has_perm('employeeattendance.add_typeofvacations')

            }
        if request.user.has_perm('employeeattendance.view_typeofvacations'):
            return render(request, 'employeesmanagement/VacationType.html', context)
        else:
            return render(request, 'error/403.html', {})

    def post(self, request, *args, **kwargs):
        """
        دالة الإظافة والتعديل
        """
        form = NewTypeOfVacations(request.POST)

        if request.POST.get('id'):
            data = get_object_or_404(TypeOfVacations, pk=int(request.POST.get('id')))
            form = NewTypeOfVacations(request.POST, instance=data)
        if form.is_valid():
            obj = form.save()
            obj.save()
            if request.POST.get('id'):
                if obj.id:
                    msg = message.update_successfully()
                    result = {'status': 1, 'message': msg}
                else:
                    msg = message.edit_error()
                    result = {'status': 2, 'message': msg}
            else:
                if obj.id:
                    msg = message.add_successfully()
                    result = {'status': 1, 'message': msg}
                else:
                    msg = message.add_error(request)
                    result = {'status': 2, 'message': msg}


        else:
            result = {'status': 0, 'error': form.errors.as_json()}
        return JsonResponse(result)

    def delete(self, request, *args, **kwargs):
        """
        دالة الحذف
        """
        pk = int(QueryDict(request.body).get('id'))

        if pk:
            try:
                data = get_object_or_404(TypeOfVacations, pk=pk)
                data.delete()
                msg = message.delete_successfully()
                result = {'status': 1, 'message': msg}
            except:
                msg = message.record_error_delete()
                result = {'status': 0, 'message': msg}
        else:
            msg = message.record_error_delete()
            result = {'status': 0, 'message': msg}
        return JsonResponse(result)
class TypeOfVacationsJson(BaseDatatableView):

    """
    يستخدم هذا الكلاس لعرض انواع 
    الاجازات قي واجهة اظافة انواع الاجازات
    """

    model = TypeOfVacations
    columns = [
        'id',
        'name',
        'VacationDayes',
        'active',
        "action",
    ]
    order_columns = [
        'id',
        'name',
        'VacationDayes',
        'active',
        "action",
    ]
    count = 0

    def render_column(self, row, column):
        """Render Column For Datatable
        """
        if column == "id":
            self.count += 1
            return self.count
        elif column == "action":
            action = ""
            action_edit = '<a class="edit_row" data-url="{2}" data-id="{0}" ' \
                          'style="DISPLAY: -webkit-inline-box;"  data-toggle="tooltip"' \
                          ' title="{1}"><i class="fa fa-edit"></i></a>'.format(
                row.pk, _("Edit"), reverse("TypeOfVacationsView"))

            action_delete = '<a class="delete_row" data-url="{2}" data-id="{0}" ' \
                            'style="DISPLAY: -webkit-inline-box;"  data-toggle="tooltip"' \
                            ' title="{1}"><i class="fa fa-trash"></i></a>'.format(
                row.pk, _("Delete"), reverse("TypeOfVacationsView"))
            if self.request.user.has_perm("employeeattendance.change_typeofvacations"):
                action += action_edit

            if self.request.user.has_perm("employeeattendance.delete_typeofvacations"):
                action += action_delete

            return action
        else:
            return super(TypeOfVacationsJson, self).render_column(row, column)

    def filter_queryset(self, qs):
        """To Filter data in table using in search
        """
        sSearch = self.request.GET.get("sSearch", None)
        if sSearch:
            qs = qs.filter(
                Q(name__icontains=sSearch)
                | Q(active__icontains=sSearch)
                | Q(VacationDayes__icontains=sSearch)
                | Q(id__icontains=sSearch)
            )
        return qs
class WorkingPolicyView(LoginRequiredMixin,CreateView):
    """
    يستخدم هذا الكلاس لاظافة سياسة العمل
    """
    login_url = '/Em/login'
    def get(self, request, *args, **kwargs):
        """
        دالة عرض الواجهة
        """
        # request.session["open_menu"] = {"salary": "menu-open"}
        # request.session["top_menu"] = {"salary": "active"}
        # request.session["sub_menu"] = {"working_policy": "active"}
        if 'id' in request.GET.keys():
            if request.GET.get('id'):
                try:
                    if not JoinEmployeeWithWorkPeriod.objects.filter(policy_id=int(request.GET.get('id'))):
                        data = WorkingPolicy.objects.filter(pk=int(request.GET.get('id')))

                        data1 = WorkingPolicyDetails.objects.filter(working_policy_id=int(request.GET.get('id')))

                        result = {
                            'status': 1,
                            'data': serializers.serialize('json', data),
                            'data1': serializers.serialize('json', data1),
                        }
                    else:
                        result = {
                            'status': 2,
                            'message': _('Can Not Edit You Have Relation with anther table'),
                        }



                except Exception as e:

                    result = {'status': 0, 'data': 'ee', 'data1': ''}
            else:
                result = {'status': 0, 'data': '', 'data1': ''}
            return JsonResponse(result)
        else:

            # formset1 = modelformset_factory(WorkingPolicyDetails, WorkingPolicyDetailsForm, extra=4)
            # formset = formset1(request.POST or None, queryset=WorkingPolicyDetails.objects.none())
            context = {
                'form': WorkingPolicyForm(),
                # 'formset': formset,
                'url': reverse('WorkingPolicyView'),
                'title_form': _('Add Work Period'),
                'title_list': _("Work policy"),
                'urljson': reverse('WorkingPolicyJson'),
                'permission': request.user.has_perm("employeeattendance.add_workingpolicy")

            }
            if request.user.has_perm("employeeattendance.view_workingpolicy"):
                return render(request, 'employeeattendance/WorkingPolicy.html', context)
            else:
                return render(request, 'error/403.html', {})

    def post(self, request, *args, **kwargs):
        """
        دالة الاظافة والتعديل
        """
        VOILATION_NAME = {
            'No fingerPrint': _('No fingerPrint'),
            'Extra minutes': _('Extra minutes'),
            'Fingerprint Presence only': _('Fingerprint Presence only'),
            'Fingerprint Leave only': _('Fingerprint Leave only'),
            'Delay in perpetuity': _('Delay in perpetuity'),
            'Early departure': _('Early departure')
        }
        if int(request.POST.get('type_finger')) == 1:
            count_details = 4
        elif int(request.POST.get('type_finger')) == 2:
            count_details = 0
        elif int(request.POST.get('type_finger')) == 3:
            count_details = 1
        form = WorkingPolicyForm(request.POST or None)
        if count_details != 0:    
            formset1 = modelformset_factory(WorkingPolicyDetails, WorkingPolicyDetailsForm, extra=int(count_details))
            formset = formset1(request.POST or None)
        
        if request.POST.get('id'):
            ins = get_object_or_404(WorkingPolicy, pk=int(request.POST.get('id')))
            form = WorkingPolicyForm(request.POST or None, request.FILES or None, instance=ins)
            if count_details != 0:    
                formset1 = modelformset_factory(WorkingPolicyDetails, WorkingPolicyDetailsForm, extra=int(count_details))
                formset = formset1(request.POST or None, queryset=WorkingPolicyDetails.objects.filter(
                    working_policy_id=int(request.POST.get('id'))))

        with transaction.atomic():

            if request.POST.get('id'):
                WorkingPolicyDetails.objects.filter(working_policy_id=(request.POST.get('id'))).delete()
            if count_details != 0:
                error_formst = error_formset(formset)
            else:
                error_formst = []
            if error_formst == [] and form.is_valid():
                obj = form.save(commit=False)
                obj.save()
                if count_details != 0:
                    for formset_row in formset:
                        formset_row1 = formset_row.save(commit=False)
                        for k, v in VOILATION_NAME.items():
                            if formset_row1.voilation_name == k or formset_row1.voilation_name == v:
                                formset_row1.voilation_name = k
                        formset_row1.working_policy_id = obj.id
                        formset_row1.save()
            else:
                result = {'status': 0, 'error_form': form.errors.as_json(), 'error_formset': error_formst}
                return JsonResponse(result)

        if request.POST.get('id'):
            if obj.id:
                msg = message.update_successfully()
                result = {'status': 1, 'message': msg}
            else:
                msg = message.edit_error()
                result = {'status': 2, 'message': msg}
        else:
            if obj.id:
                msg = message.add_successfully()
                result = {'status': 1, 'message': msg}
            else:
                msg = message.add_error(request)
                result = {'status': 2, 'message': msg}

        return JsonResponse(result)

    def delete(self, request, *args, **kwargs):
        """ دالة الحذف"""
        pk = int(QueryDict(request.body).get('id'))
        if pk:
            try:
                data = get_object_or_404(WorkingPolicy, pk=pk)
                if JoinEmployeeWithWorkPeriod.objects.filter(
                        policy_id=pk).exists():
                    msg = _("The record cannot be deleted because it is related to employees")
                    result = {'status': 2, 'message': msg}
                else:

                    details = WorkingPolicyDetails.objects.filter(
                        working_policy_id=pk)
                    with transaction.atomic():
                        for record in details:
                            record.delete()
                        data.delete()
                        msg = message.delete_successfully()
                        result = {'status': 1, 'message': msg}
            except Exception as e:
                msg = message.record_error_delete()
                result = {'status': 0, 'message': msg}
        else:
            msg = message.record_error_delete()
            result = {'status': 0, 'message': msg}
        return JsonResponse(result)
class WorkingPolicyJson(BaseDatatableView):
    """
    يستخدم هذا الكلاس في عرض سياسة العمل في 
    واجهة اظافة سياسة العمل
    """

    model = WorkingPolicy
    columns = [
        'id',
        'name',
        'type_finger',
        'number_of_finger',
        'm_before_present',
        'm_after_leave',
        "action",
    ]
    order_columns = [
        'id',
        'name',
        'type_finger',
        'number_of_finger',
        'm_before_present',
        'm_after_leave',
        "action",
    ]

    count = 0

    def render_column(self, row, column):
        """Render Column For Datatable
        """
        if column == "id":
            self.count += 1
            return self.count
        elif column == "action":
            action = ""
            action_edit = '<a class="edit_row" data-url="{2}" data-id="{0}" ' \
                          'style="DISPLAY: -webkit-inline-box;"  data-toggle="tooltip"' \
                          ' title="{1}"><i class="fa fa-edit"></i></a>'.format(row.pk, _("Edit"),
                                                                               reverse("WorkingPolicyView"))
            action_delete = '<a class="delete_row" data-url="{2}" data-id="{0}" ' \
                            'style="DISPLAY: -webkit-inline-box;"  data-toggle="tooltip"' \
                            ' title="{1}"><i class="fa fa-trash"></i></a>'.format(row.pk, _("Delete"),
                                                                                  reverse("WorkingPolicyView"))

            if self.request.user.has_perm('employeeattendance.change_workingpolicy'):
                action += action_edit
            if self.request.user.has_perm('employeeattendance.delete_workingpolicys'):
                action += action_delete
            return action


        else:
            return super(WorkingPolicyJson, self).render_column(row, column)

    def filter_queryset(self, qs):
        """To Filter data in table using in search
        """
        sSearch = self.request.GET.get("sSearch", None)
        if sSearch:
            qs = qs.filter(
                Q(name__icontains=sSearch)
                | Q(type_finger__icontains=sSearch)
                | Q(number_of_finger__icontains=sSearch)
                | Q(m_before_present__icontains=sSearch)
                | Q(m_after_leave__icontains=sSearch)
                | Q(id__icontains=sSearch)
            )
        return qs
class ManualAttendeeView(LoginRequiredMixin,CreateView):
    """
    يستخدم هذا الكلاس في عملية التحضيرير اليدوي
    """
   
    login_url = '/Em/login'
    def get(self, request, *args, **kwargs):
        """ دالة عرض الواجهة"""
        # request.session["open_menu"] = {"Employees_attendaces": "menu-open"}
        # request.session["top_menu"] = {"Employees_attendaces": "active"}
        # request.session["sub_menu"] = {"manual_attendance": "active"}

        if 'id' in request.GET.keys():
            if request.GET.get('id'):
                try:
                    data = ManualAttendee.objects.filter(pk=int(request.GET.get('id')))
                    data1 = ManualAttendeeDetails.objects.values('employee__arname', 'time_leave',
                                                                 'time_attendee').filter(
                        manual_attendee_id=int(request.GET.get('id')))
                    formset1 = modelformset_factory(ManualAttendeeDetails, ManualAttendeeDetailsForm, extra=len(data1))
                    formset = formset1(None, queryset=ManualAttendeeDetails.objects.none())

                    return JsonResponse({
                        'formset': render_to_string('forms/Add_attendee_details.html',
                                                    {'formset': formset}
                                                    )
                        , 'status': 1,
                        'data': serializers.serialize('json', data),
                        'data1': list(data1),
                    })



                except Exception as e:

                    result = {'status': 0, 'data': 'ee', 'data1': ''}
            else:
                result = {'status': 0, 'data': '', 'data1': ''}

            return JsonResponse(result)
        else:

            context = {
                'form': ManualAttendeeForm(),
                'url': reverse('ManualAttendeeView'),
                'title_form': _("Manual Attendee"),
                'title_list': _("Manual Attendee"),
                'urljson': reverse('ManualAttendeeJson'),
                'permission': request.user.has_perm('employeeattendance.add_manualattendee')

            }
            if request.user.has_perm('employeeattendance.view_manualattendee'):
                return render(request, 'employeeattendance/ManualAttendee.html', context)
            else:
                return render(request, 'error/403.html', {})

    def post(self, request, *args, **kwargs):
        """
        دالة الحفظ والتعديل
        """
        form = ManualAttendeeForm(request.POST or None)
        formset1 = modelformset_factory(ManualAttendeeDetails, ManualAttendeeDetailsForm)
        formset = formset1(request.POST or None, queryset=ManualAttendeeDetails.objects.none())
        if request.POST.get('id'):
            ins = get_object_or_404(ManualAttendee, pk=int(request.POST.get('id')))
            form = ManualAttendeeForm(request.POST or None, request.FILES or None, instance=ins)
            formset1 = modelformset_factory(ManualAttendeeDetails, ManualAttendeeDetailsForm)
            formset = formset1(request.POST or None, queryset=ManualAttendeeDetails.objects.filter(
                manual_attendee_id=int(request.POST.get('id'))))
        try:
            i = 0
            result_value_form = ''
            with transaction.atomic():
                error_formst = error_formset(formset)
                if error_formst == [] and form.is_valid():
                    if request.POST.get('id'):
                        ManualAttendeeDetails.objects.filter(manual_attendee_id=(request.POST.get('id'))).delete()
                    form = form.save()

                    for formset_row in formset:

                        if formset_row.cleaned_data.get('chek_attendee') == True:

                            obj = formset_row.save(commit=False)
                            result_value_form = obj.check_fields_is_valid()
                            if result_value_form != True:
                                msg = result_value_form
                                raise MyExcept()

                            obj.manual_attendee_id = form.id
                            employee_name = formset_row.cleaned_data['employee_name']
                            obj_employee = Emp_data.objects.get(arname=employee_name)
                            obj.employee = obj_employee
                            obj.save()
                            

                        else:
                            i = i + 1

                    if i == int(request.POST.get('form-TOTAL_FORMS')):
                        msg = _('The personnel to be prepared must be specified')
                        raise MyExcept()



                else:
                    result = {'status': 0, 'error_form': form.errors.as_json(), 'error_formset': error_formst}
                    return JsonResponse(result)
        except MyExcept as e:
            data = {'message': msg, 'status': 3}
            return JsonResponse(data)

        if request.POST.get('id'):
            if obj.id:
                msg = message.update_successfully()
                result = {'status': 1, 'message': msg}
            else:
                msg = message.edit_error()
                result = {'status': 2, 'message': msg}
        else:
            if obj.id:
                msg = message.add_successfully()
                result = {'status': 1, 'message': msg}
            else:
                msg = message.add_error(request)
                result = {'status': 2, 'message': msg}

        return JsonResponse(result)

    def delete(self, request, *args, **kwargs):
        """ دالة الحذف"""
        pk = int(QueryDict(request.body).get('id'))
        if pk:
            try:
                data = get_object_or_404(ManualAttendee, pk=pk)

                data.delete()
                msg = message.delete_successfully()
                result = {'status': 1, 'message': msg}
            except:
                msg = message.record_error_delete()
                result = {'status': 0, 'message': msg}
        else:
            msg = message.record_error_delete()
            result = {'status': 0, 'message': msg}
        return JsonResponse(result)
        
class ManualAttendeeJson(BaseDatatableView):
    """
    يستخدم هذا الكلاس لعرض عمليات التحضير 
    يستدعى من واجهة التحضير اليدوي عند النفقر على
    زر العملبات السابقة
    """

    model = ManualAttendee
    columns = [
        'id',
        'date_attendee',
        'date_opration',
        'action',

    ]
    order_columns = [
        'id',
        'date_attendee',
        'date_opration',
        'action',
    ]

    count = 0
    # def get_initial_queryset(self):

    #     return self.model.objects.filter(pk=id)
    def render_column(self, row, column):
        """Render Column For Datatable
        """
        record = self.model.objects.filter(pk=row.pk)
        if not ManualAttendeeDetails.objects.filter(manual_attendee_id=row.pk):
            pass
        elif column == "id":
            self.count += 1
            return self.count
        elif column == "action":
            action = ""
            action_edit = '<a class="edit_row" data-url="{2}" data-id="{0}" ' \
                          'style="DISPLAY: -webkit-inline-box;"  data-toggle="tooltip"' \
                          ' title="{1}"><i class="fa fa-edit"></i></a>'.format(row.pk, _("Edit"),
                                                                               reverse("ManualAttendeeView"))
            action_delete = '<a class="delete_row" data-url="{2}" data-id="{0}" ' \
                            'style="DISPLAY: -webkit-inline-box;"  data-toggle="tooltip"' \
                            ' title="{1}"><i class="fa fa-trash"></i></a>'.format(row.pk, _("Delete"),
                                                                                  reverse("ManualAttendeeView"))

            if self.request.user.has_perm('employeeattendance.change_manualattendee'):
                action += action_edit
            if self.request.user.has_perm('employeeattendance.delete_manualattendee'):
                action += action_delete
            return action


        else:
            return super(ManualAttendeeJson, self).render_column(row, column)

    def filter_queryset(self, qs):
        """To Filter data in table using in search
        """
        sSearch = self.request.GET.get("sSearch", None)
        if sSearch:
            qs = qs.filter(
                Q(date_attendee__icontains=sSearch)
                | Q(date_opration__icontains=sSearch)
                | Q(id__icontains=sSearch)
            )
        return qs

def load_manual_attendee_details(request):
    """
    تستدعى هذه الدالة من واجهة التحضير اليدوي عند النقر
    على زر عرض التفاصيل  حيث تعرض قايمة باسماء الموظفين
    وزمن الحضور والانصراف مع خيار التحضير وزر الحفظ
    """
    if request.method == 'POST' and request.is_ajax:
        form_manual_attendee = ManualAttendeeForm(request.POST or None)
        tabel1 = list()
        my_list_of_things = []
        msg = _('Sorry, there are no employees')
        if OfficialVacations.objects.filter(date_offi_v=parse_date(request.POST.get('date_attendee'))):
            return JsonResponse({'msg': _('Sorry, this day is considered an official vacation'), 'statu': '3'})
        if form_manual_attendee.is_valid():
            if request.POST.get('check_organization_chart') == "on":
                '''
                If he wants employees of an administrative unit
                '''
                organizational_chart_name = request.POST.get('organizational_chart')
                organizational_chart_id1 = OrganizationalChart.objects.values('id').filter(
                    name_ar=organizational_chart_name).order_by('id')
                organizational_chart_employee = EmployeeFunctionalData.objects.values('employee_id').filter(
                    organizational=int(organizational_chart_id1[0]['id'])).order_by('id')
                organization_emp_list = list(organizational_chart_employee)
                if organization_emp_list != []:

                    for emp_id in organizational_chart_employee:
                        emp_name = Emp_data.objects.values('arname').filter(pk=emp_id['employee_id'])
                        tabel1.append(emp_name[0]['arname'])

                else:
                    msg = _('Sorry, there are no employees associated with this organizational structure')
                    return JsonResponse({'msg': msg, 'statu': '3'})



            elif request.POST.get('select_all_employee') == 'on':
                '''
                If all employees want
                '''
                all_employee = [(mot['arname']) for mot in
                                Emp_data.objects.values('arname').filter(emp_status=True)]
                for emp in all_employee:
                    tabel1.append(emp)

            else:
                '''
                If he wanted between employees
                '''
                from_employee = request.POST.get('from_employee')
                to_employee = request.POST.get('to_employee')
                from_employee_id1 = Emp_data.objects.values('id').filter(arname=from_employee)
                to_employee_id1 = Emp_data.objects.values('id').filter(arname=to_employee)
                if from_employee_id1 and to_employee_id1:
                    from_employee_id = (from_employee_id1[0]['id'])
                    to_employee_id = (to_employee_id1[0]['id'])
                    if from_employee_id == to_employee_id:
                        '''
                        If an employee is in a field from an employee he is the same as in an employee field
                        '''
                        tabel1.append(from_employee)
                    elif from_employee_id < to_employee_id:
                        '''
                        If the employee number is in a field from an employee smoler than that in a field to an employee
                        '''
                        obj = Emp_data.objects.values('id', 'arname').filter(pk__gte=from_employee_id,
                                                                             pk__lte=to_employee_id, emp_status=True)

                        list__name = list(obj)
                        for emp in list__name:
                            tabel1.append(emp['arname'])
                    else:
                        '''
                        If the employee number is in a field from an employee greater than that in a field to an employee
                        '''
                        from_employee_id, to_employee_id = to_employee_id, from_employee_id
                        obj = Emp_data.objects.values('id', 'arname').filter(pk__gte=from_employee_id,
                                                                             pk__lte=to_employee_id, emp_status=True)
                        list_name = list(obj)
                        for emp in list_name:
                            tabel1.append(emp['arname'])
            if tabel1 == []:
                return JsonResponse({'msg': msg, 'statu': '0'})

            else:

                for a in range(len(tabel1)):
                    my_list_of_things.append(
                        [tabel1[a], request.POST.get('time_attendee'), request.POST.get('time_leave')])
            my_iterator = iter(my_list_of_things)
            formset_manual_attendee_details = formset_factory(ManualAttendeeDetailsForm, extra=len(my_list_of_things))
            formset_manual_attendee_details.form = functools.partial(ManualAttendeeDetailsForm,
                                                                     item_iterator=my_iterator)
            return JsonResponse({'data1': render_to_string("forms/Add_attendee_details.html",
                                                           {'formset': formset_manual_attendee_details}),
                                 'data2': len(my_list_of_things), 'statu': 2})



        else:
            return JsonResponse({'statu': 0, 'error': form.errors.as_json()})
class MyExcept(Exception):
    pass

def time_diff(time_str1, time_str2):
    """
    دالة لمعرفة ساعات العمل بين وقتين
    Returns:
        [type] -- [ساعات العمل]
    """
    t1 = datetime.datetime.strptime(time_str1, '%H:%M:%S')
    t2 = datetime.datetime.strptime(time_str2, '%H:%M:%S')
    dt = abs(t2 - t1)
    return time(dt.seconds // 3600, (dt.seconds // 60) % 60).strftime('%H:%M')
        
def get_form_work_policy_details(request):
    """
    دالة يتم استدعائها بالاجكس من واجهة سياسة العمل
    عند اختيار نوع البصمة لتقوم باضهار التفاصيل حسب الخيار
    
    Returns:
        [formset] -- [التفاصيل المراد تعبئتها حسب الخيار]
    """
    if int(request.GET.get('val')) == 2 :
        formset = None
    elif int(request.GET.get('val')) == 1:
        formset1 = modelformset_factory(WorkingPolicyDetails, WorkingPolicyDetailsForm, extra=4)
        formset = formset1(request.POST or None, queryset=WorkingPolicyDetails.objects.none())
    
    elif int(request.GET.get('val')) == 3:
        formset1 = modelformset_factory(WorkingPolicyDetails, WorkingPolicyDetailsForm, extra=1)
        formset = formset1(request.POST or None, queryset=WorkingPolicyDetails.objects.none())
    

    return render(request,'employeeattendance/WorkPolicyDetails.html',{'formset':formset})

def calculate_attendance_for_period(request):
    """
    دالة لعمل تقرير تفصيلي لموظفين معينين
    وكل فترات العمل التي تخصهم ولفترة ادارية معينة
    """
    if request.method == 'POST' and request.is_ajax:
        with transaction.atomic():
            all_date = CalculateAtendanceAndLeave.objects.values('date').all().distinct('date').order_by('date')
            all_employee = CalculateAtendanceAndLeave.objects.values('employee__arname','employee').all().distinct('employee_id').order_by('employee_id')
            date_first = (all_date.first()['date'])
            date_last = all_date.last()['date']
            all_period_between_tow_date = JoinEmployeeWithWorkPeriod.objects.exclude(
                                    from_date__gt=date_last,to_date__lt=date_first,
                                ).values('work_period_id','work_period__name').distinct('work_period_id')
            data_list = []
            count_day_between_date = int(len(all_date)/5)
            count_day_after_last_date = int(len(all_date)%5)
            date_list=set()
            counter = 0
            for a in range(count_day_between_date+1):
                if a == count_day_between_date : 
                    date_list.add(all_date[len(all_date)-1]['date'])
                else:
                    date_list.add(all_date[counter]['date'])
                counter += 5
            list_new_date = []
            date_list = list(date_list)
            date_list.sort()
            for s_date in range(int(len(date_list))-1):
                if s_date == len(date_list)-2:
                    list_new_date.append(str(date_list[s_date])+':'+str(date_list[s_date+1]))
                else:
                    list_new_date.append(str(date_list[s_date])+':'+str(date_list[s_date+1] - datetime.timedelta(days=1)))
            for employee in all_employee:
                period_list = []
                for date_object in all_date:
                    attendance_list = []
                    for period in all_period_between_tow_date:
                        is_period = JoinEmployeeWithWorkPeriod.objects.filter(
                                        work_period_id=period['work_period_id'],
                                        employee_id=employee['employee'],
                                    ).exclude(
                                    from_date__gt=date_object['date'],to_date__lt=date_object['date'],
                                    ).values('work_period_id').distinct('work_period_id')
                        if is_period :
                            data_attendance_period = CalculateAtendanceAndLeaveDetails.objects.filter(
                                calculate_atendance_and_leave__employee_id=employee['employee'],
                                calculate_atendance_and_leave__date=date_object['date'],
                                work_period_id=period['work_period_id']).values(
                                    'early_departure_minute_sum',
                                    'delay_minute_sum',
                                    'attendance_time',
                                    'leave_time',
                                    'statue')
                            if data_attendance_period:
                                data_attendance_period=data_attendance_period[0]
                                early_departure_minute_sum = data_attendance_period['early_departure_minute_sum']
                                delay_minute_sum = data_attendance_period['delay_minute_sum']
                                attendance_time = data_attendance_period['attendance_time']
                                leave_time = data_attendance_period['leave_time']
                                work_hours = time_diff(str(leave_time),str(attendance_time))
                                if str(attendance_time) == '00:00:00':
                                    attendance_time = 0
                                if str(leave_time) == '00:00:00':
                                    leave_time = 0
                                statue = data_attendance_period['statue']
                                if str(work_hours) == '00:00':
                                    work_hours = 0
                                attendance_list.append({'period':period['work_period__name'],
                                    'early_departure_minute_sum':early_departure_minute_sum,
                                    'delay_minute_sum':delay_minute_sum,
                                    'attendance_time':attendance_time,
                                    'leave_time':leave_time,
                                    'work_hours':work_hours,
                                    'statue':_(statue)}
                                    )
                            else:
                                attendance_list.append({
                                'early_departure_minute_sum':'-----',
                                'delay_minute_sum':'-----',
                                'attendance_time':'-----',
                                'leave_time':'-----',
                                'work_hours':'-----',
                                'statue':'-----'
                            })
                        else:
                            attendance_list.append({
                                'early_departure_minute_sum':'-----',
                                'delay_minute_sum':'-----',
                                'attendance_time':'-----',
                                'leave_time':'-----',
                                'work_hours':'-----',
                                'statue':'-----'
                            })
                    period_list.append({'attendance':attendance_list})
                data_list.append({'date':date_object['date'],'employee':employee['employee__arname'],'date_period':period_list})
            
            return render(request,'employeeattendance/report_attendance_all_period.html',{'data':data_list,
                                                            'all_date':(all_date),
                                                            'count_period':len(all_period_between_tow_date),
                                                            'all_period':all_period_between_tow_date,
                                                            'count_day_between_date':count_day_between_date,
                                                            'count_day_after_last_date':count_day_after_last_date,
                                                            'list_new_date':list_new_date,
                                                            'date_first':date_first,
                                                            'date_last':date_last,})
