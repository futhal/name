import datetime
from django.conf import settings

from django.core.validators import MaxValueValidator, MinValueValidator
from django.db import models
from django.utils.translation import ugettext_lazy as _
from employeesmanagement.base import BaseModelF
# from employeesmanagement.models import 
 

class WorkingPolicy(models.Model):
    """
    جدول سياسة العمل ويحتوي على الاعمدة التالية
    الاسم , نوع البصمة ,عدد البصمات , دقايق قبل الحضور 
    دقائق قبل المغادرة
    """
    TYPE_FINGER_CHOICE = (
        ('1', _('The first entry and the second exit')), ('2', _('One fingerprint')), ('3', _('Presence only')),)
    name = models.CharField(max_length=50, unique=True, verbose_name=_("work policy name"))
    type_finger = models.CharField(max_length=50, choices=TYPE_FINGER_CHOICE, verbose_name=_("type finger"))
    number_of_finger = models.PositiveIntegerField(verbose_name=_("number of finger"))
    m_before_present = models.PositiveIntegerField(verbose_name=_("minute before present"))
    m_after_leave = models.PositiveIntegerField(verbose_name=_("minute after leave"))

    class Meta:
        db_table = 'working_policy'
        verbose_name = _('Working Policy')

    def __str__(self):
        return self.name

    def get_data(self):
        """
        دالة لارجاع بيانات سياسة العمل
        Returns:
            [type] -- [بيانات سياسة العمل]
        """
        m_before_present = self.m_before_present
        m_after_leave = self.m_after_leave
        type_finger = self.type_finger
        return m_before_present, m_after_leave, type_finger

    def get_data_detail(self):
        """
        دالة لجلب تفاصيل سياسة العمل
        Returns:
            [data_detail] -- [تفاصيل سياسة العمل]
        """
        data_detail = self.WorkingPolicyDetailss.values(
            'calc_violation_after', 'minute_equal').filter(
            convert_to='2')[0]
        return data_detail['calc_violation_after'], data_detail['minute_equal']


class WorkingPolicyDetails(models.Model):
    """
   جدول تفاصيل  سياسة العمل ويحتوي على الأعمدة التالية
   سياسة العمل مفتاح اجنبي من جدول سياسة العمل
    نوع المخالفة , بند البصمة , عدد دقايق التاخير المسموح بها
    مقدار دقايق الخصم مقابل دقيقة  تاخير او انصراف مبكر
    بند البصمة مفتاح اجنبي من جدول بنود البصمة
    """

    ITEMS_CHOICE = (
        ('1', _('Absence')), ('2', _('Late')), ('3', _('Early leave')), ('4', _('Present')), ('5', _('Extra minutes')),)

    working_policy = models.ForeignKey(WorkingPolicy, on_delete=models.CASCADE, related_name='WorkingPolicyDetailss',
                                       blank=True, null=True, verbose_name=_("working policy name"))
    voilation_name = models.CharField(max_length=50, verbose_name=_("convert to"))
    convert_to = models.CharField(max_length=20, choices=ITEMS_CHOICE, default=1, verbose_name=_("minute after leave"))
    calc_violation_after = models.PositiveIntegerField(verbose_name=_("calclate violation after"), blank=False,
                                                       null=False)
    minute_equal = models.PositiveIntegerField(verbose_name=_("minute equal"), blank=False, null=False)

    class Meta:
        db_table = 'working_policy_details'
        verbose_name = _('Working Policy Details')


class TypeOfVacations(models.Model):
    """
    جدول انواع الاجازات  ويحتوي على الاعمدة التالية 
    الأسم , و عدد الايام , وهل مفعل ام موقف
    """
    name = models.CharField(max_length=50, unique=True, verbose_name=_("name"))
    VacationDayes = models.IntegerField(
        default=1,
        validators=[MaxValueValidator(180), MinValueValidator(1)], verbose_name=_("Vacation Dayes"))

    active = models.BooleanField(default=True, verbose_name=_("active"))

    class Meta:
        db_table = 'typeofvacations'
        verbose_name = _('Vacations Types')

    def __str__(self):
        return self.name


class BalanceVacations(BaseModelF):
    """
    جدول ارصدة الاجازات ويحتوي على الأعمدة التالية
    الموظف , نوع الاجازة , الرصيد الكلي ,الرصيد الحالي ,سنة الرصيد
    """
    employee = models.ForeignKey('employeesmanagement.Emp_data', on_delete=models.CASCADE, verbose_name=_("employee"))
    v_type = models.ForeignKey(TypeOfVacations, on_delete=models.PROTECT, verbose_name=_("vaction type"))
    total_balance_day = models.PositiveIntegerField(verbose_name=_("total balance day"))
    current_balance_day = models.PositiveIntegerField(verbose_name=_("current balance day"))
    balance_year = models.PositiveIntegerField(default=int(datetime.datetime.now().strftime("%Y")),
                                               verbose_name=_("balance year"))

    class Meta:
        db_table = 'balance_vacations'
        verbose_name = _('Vacations Balance')


class Vacation_request(BaseModelF):
    """
    جدول الاجازات للموظفين ويحتوي على الاعمدة التالية
    الموظف , نوع الاجازة , تاريخ العملية ,تاريخ بداية الاجازة
    تاريخ نهاية الإجازة , عدد الايام , والسبب
    """
    employee = models.ForeignKey('employeesmanagement.emp_data', on_delete=models.CASCADE, related_name="Employee",
                                 verbose_name=_("employee"))
    type_vacation = models.ForeignKey(TypeOfVacations, on_delete=models.PROTECT, related_name="Vacation_Requests",
                                      verbose_name=_("type vacation"))
    dateprocess = models.DateField(verbose_name=_("date process"))
    fromdate = models.DateField(verbose_name=_("from date"))
    todate = models.DateField(verbose_name=_("to date"))
    betweendate = models.IntegerField(default=1, verbose_name=_("between date"))
    reason = models.CharField(max_length=200, verbose_name=_("reason"), blank=True)

    class Meta:
        db_table = 'vacation_request'
        verbose_name = _('Vacation Request')


class OfficialVacations(models.Model):
    """
    جدول العطلات الرسمية ويحتوي على الاعمدة التالية
    اسم اليوم , ونوع العطلة الرسمية , ورقم الشهر , تاريخ العطلة
    والوصف , وتاريخ الإنشاء 
    """
    type_officialvacations = [
        ('Weekend', _('Weekend')),
        ('Feast', _('Feast')),
        ('National', _('National')),
        ('Other', _('Other')),
    ]
    dayname = [
        ('Saturday', _('Saturday')),
        ('Sunday', _('Sunday')),
        ('Monday', _('Monday')),
        ('Tuesday', _('Tuesday')),
        ('Wednesday', _('Wednesday')),
        ('Thursday', _('Thursday')),
        ('Friday', _('Friday')),
    ]
    day_name = models.CharField(max_length=20, choices=dayname, verbose_name=_("day name"))
    type_offi_v = models.CharField(max_length=20, choices=type_officialvacations,
                                   verbose_name=_("type offitial vaction"))
    month_number = models.IntegerField(default=1, validators=[MaxValueValidator(12), MinValueValidator(1)],
                                       verbose_name=_("month number"))
    date_offi_v = models.DateField(verbose_name=_("date offitial vaction"))
    descript_offi_v = models.CharField(max_length=100, null=True, verbose_name=_("Description"), blank=True)
    created_date = models.DateField(verbose_name=_("created date"))

    class Meta:
        db_table = 'officialvacations'
        verbose_name = _('Official Vacations')

    def __str__(self):
        return self.day_name  # "{1}----{2}".format(self.day_name,self.date_offi_v)


class ManualAttendee(models.Model):
    """
    جدول التحضير اليدوي ويحتوي على الأعمدة التالية 
    تاريخ اجراء العملية  , وتاريخ يوم التحضير
    """
    date_opration = models.DateField(verbose_name=_("Date opration"))
    date_attendee = models.DateField(verbose_name=_("Date attendeence"))

    class Meta:
        db_table = 'manual_attendee'
        verbose_name = _('Manual Attendee')

    def __str__(self):
        return str(self.pk)


class ManualAttendeeDetails(BaseModelF):
    """
    جدول تفاصيل التحضير اليدوي  ويحتوي على الأعمدة التالية 
    الموظف , والتحضير اليدوي مفتاح اجنبي من جدول التحضير اليدوي
    وزمن الحضور , و زمن المغادرة 
    """
    employee = models.ForeignKey('employeesmanagement.emp_data', on_delete=models.CASCADE, null=True, blank=True,
                                 verbose_name=_("employee"))
    manual_attendee = models.ForeignKey(ManualAttendee, on_delete=models.PROTECT, null=True, blank=True,
                                        verbose_name=_("manual attendee"))
    time_leave = models.TimeField(verbose_name=_("time leave"))
    time_attendee = models.TimeField(verbose_name=_("time attendeence"))

    # related_name=_("Time Leave")
    # related_name=_("Time Attendee")

    class Meta:
        db_table = 'manual_attendee_details'
        verbose_name = _('Manual Attendee Details')

    def check_fields_is_valid(self):
        if self.time_leave <= self.time_attendee:
            # يجب ان يكون وقت المغادرة اكبر من وقت الحضور
            return _('The time of departure must be greater than the time of attendance')
        return True


class CalculateAtendanceAndLeave(BaseModelF):
    """
   جدول احتساب الحضور والانصراف ويحتوي على الاعمدة التالية
    الموظف , تاريخ اليوم
    """
    employee = models.ForeignKey('employeesmanagement.emp_data', on_delete=models.PROTECT)
    date = models.DateField(verbose_name=_("date"))

    class Meta:
        db_table = 'calculate_atendance_and_leave'
        verbose_name = _('Calculate Atendance And Leave')

    def __str__(self):
        return str(self.pk)

    # def minute_extra_early_late(self, countt):
    #     """
    #     دالة احتساب دقائيق التأخير والانصراف المبكر للموظف
    #     """
    #     obj1 = self.calculateatendanceandleavedetails_set.all()
    #     for ob in obj1:
    #         print(ob.statue)
    #     if self.calculateatendanceandleavedetails_set.filter(
    #             statue__in=['Abcent', 'Official vacation']).count() == countt:
    #         print('hu'*30)
    #         obj = self.calculateatendanceandleavedetails_set.all()

    #         if countt == 1:
    #             if ((obj.filter(statue='Abcent').count() == 1) or (
    #                     obj.filter(statue='Official vacation').count() == 1)):
    #                 return True
    #         elif countt >= 2:
    #             if (obj.filter(statue='Abcent').count() >= 1):
    #                 return True
    #     extra_minute, delay_minute, early_leave_minute = 0, 0, 0
    #     for i in self.calculateatendanceandleavedetails_set.all():

    # if i.statue == "Abcent": delay_minute = i.work_period.sum_minute_in_one_day() else: extra_minute, delay_minute,
    # early_leave_minute = i.additional_minute_sum, i.delay_minute_sum, i.early_departure_minute_sum return
    # extra_minute, delay_minute, early_leave_minute

    def minute_work_in_this_day(self):
        """
        تقوم هذه الدالة تقوم بارجاع مجموع دقائق العمل لكل الفترات بيوم محدد
        """
        count_minute_work_in_this_day = 0
        for i in self.calculateatendanceandleavedetails_set.all():
            count_minute_work_in_this_day += i.work_period.sum_minute_in_this_day(self.date)
        return count_minute_work_in_this_day


    def price_one_minute_in_day(self, price_day):
        """
        تقوم هذه الدالة تقوم بارجاع سعر الدقيقةباليوم المحدد
        عن طريق قسمة سعر اليوم على  عدد دقائق الدوام باليوم
        وتقوم باستقبال سعر دوام اليوم
        """
        return price_day / self.minute_work_in_this_day()




    def minute_extra_early_late(self, price_day):
        """
        دالة احتساب دقائيق التأخير والانصراف المبكر للموظف
        """
        all_data_details = self.calculateatendanceandleavedetails_set.all()
        if all_data_details.filter(statue='Abcent').count() == all_data_details.all().count():
            """
            (true)إذا غاب الموظف كل الفترات يتم إرجاع
            ويتم إحتساب اليوم كيوم غياب
            """
            
            return True
        elif (all_data_details.filter(statue='Abcent').count() >= 1) and (all_data_details.filter(statue='Attendee').count() == 0):
            """
            (true)إذا غاب الموظف بعض الفترات وباقي الفترات كانت اجازه رسمية يتم إرجاع
            ويتم إحتساب اليوم كيوم غياب
            """
            return True
        else:
            price_minute = self.price_one_minute_in_day(price_day)
            """
            إذا حضر الموظف  بعض الفترات وغاب البعض بنفس اليوم أو حضر كل الفترات أو كان باجازه يتم  
            جمع دقائق التأخير والدقائق الاضافي والانصراف المبكر والفتره الغائب فيها يتم جمعها كدقائق تأخير 
            كما هو موضح حسب الشروظ  في الاكواد التالية
            كما يتم ضرب دقائق الاضافي والزائدة والتأخير بسعر الدقيقة بيوم العمل
            """
            extra_minute, delay_minute, early_leave_minute = 0, 0, 0
            for i in all_data_details:
                if i.statue == "Abcent":
                    """ إذا كانت الفترة غياب يتم جمع دقائقها كدقائق تأخير
                    """
                    # delay_minute = i.work_period.sum_minute_in_one_day()
                    delay_minute = i.work_period.sum_minute_in_this_day(self.date)
                else:
                    """
                    إذا لم يكن المستخدم غياب يتم جمع دقائق التأخير والدقائق الزائدة ودقائق الانصراف المبكر أن وجدت
                    """
                    extra_minute, delay_minute, early_leave_minute = i.additional_minute_sum, i.delay_minute_sum, i.early_departure_minute_sum
                
                """
                هنا يتم ضرب مجموع دقائق التأخير والا ضافي والزائدة بسعر الدقيقة باليوم بشرط ان توجد دقائق 
                """
                if delay_minute != 0:
                    delay_minute *= price_minute
                if extra_minute != 0:
                    extra_minute *= price_minute
                if early_leave_minute != 0:
                    early_leave_minute *= price_minute
                return extra_minute, delay_minute, early_leave_minute


class CalculateAtendanceAndLeaveDetails(models.Model):

    """
    جدول تفاصيل احتساب الحضور والانصراف ويحتوي على الأعمدة التالية
    سياسة العمل , فترة العمل , ومجموع دقايق التأخير , ومجموع دقايق
    الإنصراف المبكر , ومجموع الدقايق الاظافية , زمن الحضور
    زمن الإنصراف , واحتساب الحضور والانصراف مفتاح اجنبي , والحالة 
    """
    STATUS = (
        ('Abcent', _('Abcent')),
        ('Attendee', _('Attendee')),
        ('Official vacation', _('Official vacation')),
        ('Taken vacation', _('Taken vacation')),
    )
    working_policy = models.IntegerField(verbose_name=_("working policy"))
    work_period = models.ForeignKey('salary.WorkPeriod', on_delete=models.CASCADE, verbose_name=_("work period"))
    delay_minute_sum = models.IntegerField(verbose_name=_("delay minute sum"))
    early_departure_minute_sum = models.IntegerField(verbose_name=_("early departure minute sum"))
    attendance_time = models.TimeField(verbose_name=_("attendance time"))
    leave_time = models.TimeField(verbose_name=_("leave time"))
    additional_minute_sum = models.IntegerField(verbose_name=_("additional minute sum"))
    calculate_atendance_and_leave = models.ForeignKey(CalculateAtendanceAndLeave, on_delete=models.CASCADE, null=True,
                                                      blank=True, verbose_name=_("calculate atendance and leave"))
    statue = models.CharField(choices=STATUS, max_length=20, verbose_name=_("statue"))

    class Meta:
        db_table = 'calculate_atendance_and_leave_details'
        verbose_name = _('Calculate Atendance And Leave Details')


