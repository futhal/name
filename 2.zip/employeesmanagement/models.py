import datetime
from accounts.models import User
from django.core.validators import RegexValidator
from django.db import models
from django.utils.translation import ugettext_lazy as _
from mptt.models import MPTTModel, TreeForeignKey
from salary.models import DiscountEmployeeAdvance, AdministrativePeriodsDetiles
from .publicChoices import NATIONALITIES, socialstatus, LANGUAGE, gender_, RELIGION, blood_type
from employeesmanagement.base import BaseModelF
from fingerprintdevices.models import UserFinger
phone_regex = RegexValidator(regex=r'^\+?1?\d{6,20}$', message=_("phone number error"))

from django.db.models import Q

class JobTitle(models.Model):
    """[جدول المسميات الوظيفية]    
    الحقول:
       [name] -- [الاسم]   
    
        [Description] -- [الوصف]
    """
    name = models.CharField(max_length=50, unique=True, verbose_name=_("Job Title"))
    Description = models.CharField(max_length=100, verbose_name=_("Description"), blank=True)

    class Meta:
        db_table = 'jobTitle'
        verbose_name = _('Job Titles')

    def __str__(self):
        return self.name


class CompanyData(models.Model):
    """[جدول بيانات الشركة]
    
    الحقول :
       [name_arabic] ---[الاسم العربي]
        [name_english] -- [الاسم الاجنبي]
        [mobile_number] -- [الموبايل]
        [phone_number] -- [الهاتف]
        [fax_number] -- [الفاكس]
        [email] -- [البريدالإلكتروني]
        [website] -- [الموقع الإلكتروني]
        [arabic_address] -- []
        [foreign_address] -- [العنوان الاجنبي]
        [company_logo] -- [شعار الشركة]
        [first_line] --  [خاص بالتقارير]
        الجــــــمــــــــهورية اليمنبــــــــــــــــــــــة
        [second_line] -- [خاص بالتقارير]
        شــــــــــــــــــركة اي تي تيكـــــــــــــــــ
        [third_line] -- [خاص بالتقارير ]
        صنعـــــــــــــــــــــــاء عطــــــــــــان
        [first_line_en] -- [خاص بالتقارير]
        Repuplic Of Yemen
        [second_line_en] -- [خاص بالتقارير]
        IT Tech Company
        [third_line_en] -- [خاص بالتقارير]
        Sanna
    """
    name_arabicc = models.CharField(max_length=100, verbose_name=_("Arabic Name"), blank=True, null=True)
    name_english = models.CharField(max_length=100, verbose_name=_("English Name"), blank=True, null=True)
    mobile_number = models.CharField(blank=False, null=False, verbose_name=_('Mobile Number'), validators=[phone_regex],
                                     max_length=100)
    phone_number = models.CharField(verbose_name=_("Phone Number"), blank=True, validators=[phone_regex],
                                    max_length=100)
    fax_number = models.IntegerField(verbose_name=_("Fax Number"), blank=True, null=True)
    email = models.EmailField(verbose_name=_("Email"), blank=True, null=True)
    website = models.URLField(verbose_name=_("Website"), blank=True, null=True)
    arabic_address = models.TextField(max_length=200, verbose_name=_("Arabic Address"), blank=True, null=True)
    foreign_address = models.TextField(max_length=200, verbose_name=_("English Address"), blank=True, null=True)
    company_logo = models.ImageField(upload_to='media\\employeesmanagement\\photes', verbose_name=_('Company Logo'),
                                     default="", blank=True, null=True)
    first_line = models.CharField(verbose_name=_('first_line'), default='', blank=True, null=True, max_length=100)
    second_line = models.CharField(verbose_name=_('second_line'), default='', blank=True, null=True, max_length=100)
    third_line = models.CharField(verbose_name=_('third_line'), default='', blank=True, null=True, max_length=100)
    first_line_en = models.CharField(verbose_name=_('first_line_en'), default='', blank=True, null=True, max_length=100)
    second_line_en = models.CharField(verbose_name=_('second_line_en'), default='', blank=True, null=True, max_length=100)
    third_line_en = models.CharField(verbose_name=_('third_line_en'), default='', blank=True, null=True, max_length=100)

    class Meta:
        db_table = 'company_data'
        verbose_name = _('Company Data')


class Emp_data(BaseModelF):
    """[جدول بيانات الموظف]
    
    الحقول:
        [arname] -- [الاسم العربي]    
   
        [enname] -- [الاسم الاجنبي]
        [emp_status] -- [حالة الموظف]    
   
        [removed] -- [هل محذوف]
        [number_employ] -- [رقم الموظف في جهاز البصمة]
    """
    arname = models.CharField(max_length = 50, verbose_name = _("Arabic Name"))
    enname = models.CharField(max_length = 50, verbose_name = _("English Name"))
    emp_status = models.BooleanField(blank=True, null=True, default=False, verbose_name =_('Status'))
    removed = models.BooleanField(blank=True, null=True, default=False, verbose_name =_('removed'))
    number_employ = models.ForeignKey(UserFinger, verbose_name=_("Finger Print Id"),on_delete=models.SET_NULL,blank=True, null=True)
    personal_image = models.ImageField(upload_to='media\\employeesmanagement\\photes',verbose_name=_("Personal Image"),blank=True, null=True)                                  

    def __str__(self):
        return self.arname

    class Meta:
        db_table = 'emp_data'
        verbose_name =_("Employee Date")

        constraints = [
            models.UniqueConstraint(fields=['arname','removed'],
                            condition=Q(removed=False),
                            name='unique employee')
        ]

        
    def accept_date(self):
        """
        دالة تعيد تاريخ قبول-تعيين الموظف
        """
        for i in self.EmployeeFunctionalDatas.all():
            return i.accept_date

    def is_accept(self):
        """
        دالة تعيد حالة الموظف 
        True إذا كان مقبول
        False إذا لم يتم قبولة
        """
        if self.emp_status:
            return True
        else:
            return False

    def accept_befor_date(self, date):
        """
        دالة تقوم بالتاكد من أن تاريخ قبول الموظف قبل تاريخ معين أم لا

        """
        if self.accept_date() <= date:
            return True
        else:
            return False


    def delete_emoloyee(self):
        """
        هذه الدالة تقوم بحذف موظف من قاعدة البيانات عن طريق تغيير حقل 
        removed = True
        """

        self.removed = True
        self.emp_status = False
        user = User.objects.filter(employee=self.pk)
        if user :
            user[0].is_active = False         
            user[0].save()
        
        self.save()
        
       
        return _("The Delete Operation Completed Successfully")

    # def data_employee_for_culculate_salary2(self, from_date, to_date):
        #     """
        #     this method for return minut_early, minute_daily, minute_extra, 
        #     """
        #     """
        #     هذه الدالة تقوم بارجاع دقائق التاخير والاضافي والزائدة بعد ضرب كلا منها بسعر الدقيقة
        #     وكذلك أيام الغياب بعد ضربه بسعر اليوم 
        #     """
        #     # count_period_employee = self.joinemployeewithworkperiod_set.filter(work_period__is_active=True).count()

        #     abcent, extra_minutes, delay_minutes, early_leave_minutes = 0, 0, 0, 0
        #     count_period_employee, count_m_work_in_day, all_minute_for_employee = 0, 0, 0
        #     for i in range(delta.days + 1):
        #         day = from_date + timedelta(days=i)
        #     # count_day_to_day = 0
        #     # obj = self.EmployeeFunctionalDatas.filter(employee=self.id)
        #     for i in self.joinemployeewithworkperiod_set.filter(work_period__is_active=True):
        #         count_period_employee += 1
        #         count_m_work_in_day += i.work_period.sum_minute_in_one_day()
        #     count_day_in_period = (to_date - from_date).days + 1
        #     # count_day_in_period = (to_date-from_date).days
        #     count_minute_in_period = count_m_work_in_day * count_day_in_period
        #     # if price minute debendant of minut work
        #     if count_minute_in_period == 0:
        #         count_minute_in_period = 1
        #     price_minute = obj[0].salary / count_minute_in_period
        #     price_day = obj[0].salary / count_day_in_period
        #     # # if price minute debendant of all minut period
        #     # price_minute2 = obj[0].salary / (count_day_in_period * 1440)
        #     delta = to_date - from_date 
        #     attendence = self.detectpreparation_set.all()
        #     for i in range(delta.days + 1):
        #         day = from_date + timedelta(days=i)
        #         extra_minute, delay_minute, early_leave_minute = 0, 0, 0
        #         day_attendence = attendence.filter(date=day)
        #         if day_attendence.filter(statue='Abcent').count() == count_period_employee or (
        #             day_attendence.filter(statue='Abcent').count() >= 1 and day_attendence.filter(statue='Attendee').count() == 0):
        #             abcent += 1
        #         else:
        #             for i in day_attendence:        
        #                 if i.statue == "Abcent":
        #                     """
        #                     إذا كانت الفترة غياب يتم جمع دقائقها كدقائق تأخير
        #                     """
        #                     delay_minute = i.work_period.sum_minute_in_this_day(day)
        #                 else:
        #                     """
        #                     إذا لم يكن المستخدم غياب يتم جمع دقائق التأخير والدقائق الزائدة ودقائق الانصراف المبكر أن وجدت
        #                     """
        #                     extra_minute, delay_minute, early_leave_minute = i.additional_minute_sum, i.delay_minute_sum, i.early_departure_minute_sum
        #         # print("&"*99)
        #         # print(extra_minute)
        #         # print(delay_minute)
        #         # print(early_leave_minute)
        #         extra_minutes += extra_minute
        #         delay_minutes += delay_minute
        #         early_leave_minutes += early_leave_minute
        #     abcent = abcent * price_day
        #     # elif remander_day >= 1:
        #     #     abcent = (abcent * price_day) +  (remander_day * price_day)
        #     # print("#@!"*99)
        #     # print(extra_minutes)
        #     # print(delay_minutes)
        #     # print(early_leave_minutes)
        #     # print(abcent)
        #     return (extra_minutes * price_minute), (delay_minutes * price_minute), (early_leave_minutes * price_minute), abcent

    def data_employee_for_culculate_salary2(self, from_date, to_date):
        """
        this method for return minut_early, minute_daily, minute_extra, 
        """
        """
        هذه الدالة تقوم بارجاع مجموع كلا من دقائق التأخير والدقائق الاضافي ودقائق الانصراف المبكر بعد ضرب كلاً منها بسعر الدقائق حسب أيام الدوام ومرتب الموظف
        وكذلك تقوم بإرجاع أيام الغياب بعد ضربه بسعر اليوم حسب مرتب الموظف 
        """
        abcent, extra_minute, delay_minute, early_leave_minute, attendance = 0, 0, 0, 0, 0
        count_day_in_period = (to_date - from_date ).days + 1
        minute_in_period = 60*24*count_day_in_period
        obj = self.EmployeeFunctionalDatas.filter(employee=self.id)
        # price_minute = obj[0].salary / minute_in_period
        price_day = obj[0].salary / count_day_in_period
        counter = 0
        #سيقوم العداد هذا بإحتساب عدد الايام اللي لدي سجلات حضور وغياب وذلك لمعرفة عدد الايام اللي مضت من الفترة قبل قبول الموظف لاحتسابها عليه كأيام غياب
        for i in self.calculateatendanceandleave_set.filter(date__gte=from_date,date__lte=to_date):
            counter += 1
            if i.minute_extra_early_late(price_day) == True:
                abcent += 1
            else:
                attendance += 1
                extra, delay, early_leave = i.minute_extra_early_late(price_day)
                extra_minute += extra
                delay_minute += delay
                early_leave_minute += early_leave
        abcent += (count_day_in_period - counter)
        abcent = abcent * price_day
        return extra_minute, delay_minute, early_leave_minute, abcent

    def data_employee_for_culculate_salary(self, from_date, to_date, period_id):
        """
        this method for return advance, deduction, allowance, and salary employee for one adminstrations period
        """
        """
        هذه الدالة تقوم بارجاع كجموع البدل والاستقطاعات والسلف والمرتب الاساسي للموظف لفتره إدارية معينة
        """
        total, allowance, deduction, remander = 0, 0, 0, 0
        total_advance_employee_reqular = 0
        total_advance_employee_permanent = 0
        # Regular advance
        #مجموع السلق الموقتة للموطف بنفس الفترة الادارية 
        for d1 in self.EmployeeAdvances.filter(advance_type__type_advancee="Regular advance", date__gte=from_date,
                                               date__lte=to_date, removed=False):
            total_advance_employee_reqular += d1.amount
            if d1.rest == 1:
                create_discount = DiscountEmployeeAdvance.objects.create(employee_advance_id=d1.id,
                                                                         date_period=d1.created_at, amount=d1.amount,
                                                                         id_period_id=period_id,
                                                                         date=datetime.date.today())
                d1.rest = 0
                d1.save()

        # permanent advance
        #مجموع السلق الدائمة للموطف بنفس الفترة الادارية 
        for d in self.EmployeeAdvances.filter(advance_type__type_advancee="permanent advance", removed=False):
            discount = DiscountEmployeeAdvance.objects.filter(employee_advance=d.id, date__gte=from_date,
                                                              date__lte=to_date)
            date22 = d.created_at
            if discount:
                total_advance_employee_permanent += discount[0].amount
            elif date22.date() < to_date:
                if d.rest >= 1:
                    if d.rest == 1:
                        if d.amount % d.discount_percentage == 0:
                            remander = d.discount_percentage
                        else:
                            remander = d.amount % d.discount_percentage
                    elif d.rest > 1:
                        remander = d.discount_percentage
                    create_discount = DiscountEmployeeAdvance.objects.create(employee_advance_id=d.id,
                                                                             date_period=d.created_at, amount=remander,
                                                                             id_period_id=period_id,
                                                                             date=datetime.date.today())
                    total_advance_employee_permanent += remander
                    d.rest -= 1
                    d.save()
                    #مجموع السلف العادية والموقته للموظف بالفترة المطلوبة
        total = total_advance_employee_reqular + total_advance_employee_permanent

        # deduction
        #مجموع استقطاعات الموظف بنفس الفترة الادارية
        for d1 in self.employeededuction_set.filter(date__gte=from_date, date__lte=to_date, removed=False):
            deduction += d1.amount

        # allowance
        #مجموع بدل الموظف بنفس الفترة الادارية
        for d in self.employeeallwance_set.filter(allwance_type__allwance_type='Permanent', date__lte=to_date,removed=False):
            allowance += d.amount
        for d in self.employeeallwance_set.filter(allwance_type__allwance_type='Temporary ', date__gte=from_date,date__lte=to_date, removed=False):                                                  
            allowance += d.amount

        obj = self.EmployeeFunctionalDatas.filter(employee=self.id)
        return total, allowance, deduction, obj[0].salary, obj[0].job

    def check_amount_advance_employee(self):
        """
        this method for return all advance the employee for month
        """
        """
        هذه الدلة سوف تقوم بالتأكد من أن الموظف بامكانه استلام سلفة جديدة من خلال مقارنة مرتب وبدل الموظف والتأكد أنها لن تكون أقل من  مجموع السلف والاستقطاعات
        """
        total_advance_employee_reqular = 0
        total_advance_employee_permanent = 0
        for d in self.EmployeeAdvances.filter(advance_type__type_advancee="Regular advance", rest=1, removed=False):
            #هنا يتم جمع السلف المؤقتة للموظف 
            total_advance_employee_reqular += d.amount
        for d1 in self.EmployeeAdvances.filter(advance_type__type_advancee="permanent advance", rest__gte=1, removed=False):
            #هنا يتم جمع السلف الدائمة للموظف 
            if d1.rest == 1:
                total_advance_employee_permanent += d1.amount
            elif d1.rest > 1:
                total_advance_employee_permanent += d1.discount_percentage
        obj = self.EmployeeFunctionalDatas.filter(employee=self.id)
        if (total_advance_employee_permanent + total_advance_employee_reqular + self.check_amount_deduction()) > (obj[0].salary + self.check_amount_allowance()):
            #إذا كانت البدل ومرتب الموظف أكبر من الاستقطاعات والسلف ستعيدالدالةTrue  
            return True
        else:
             #إذا كانت البدل ومرتب الموظف أقل من الاستقطاعات والسلفFalse  
            return False

    def check_amount_type_advance(self, type_advance, advance_type):
        """
        this method for return all advance the employee for one advance regular or permanent type
        """
        """
        هذه الداله سوف تقوم بارجاع مجموع  سلفة دائمة أو مؤقته محددة لموظف
        وتتم العملية عن طريق استدعاء دالة ترد المجموع إذا كانت من نوع مستديمةودالة اخرى إذا كانت من نوع مؤقتة
        """
        if type_advance == "Regular advance":
            return self.check_amount_advance_regular(advance_type)
        else:
            return self.check_amount_advance_permanent(advance_type)

    def check_amount_advance_regular(self, advance_type):
        """
        this method for return all advance the employee for one advance regular type
        """
        """
        هذه الداله سوف تقوم بارجاع مجموع  سلفة مؤقتة محددة لموظف
        لن يتم جمع ما تم إخلائة من هذه السلفة سيتم احتساب المتبقي من السلفة لدى الموظف فقط
        """
        total_advance_employee = 0
        for d in self.EmployeeAdvances.filter(advance_type=advance_type, rest=1, removed=False):
            total_advance_employee += d.amount
        return total_advance_employee

    def check_amount_advance_permanent(self, advance_type):
        """
        this method for return all advance the employee for one advance permanent type
        """
        """
         هذه الداله سوف تقوم بارجاع مجموع  سلفة دائمة محددة لموظف
        (لن يتم جمع ما تم إخلائة من هذه السلفة سيتم احتساب المتبقي من السلفة لدى الموظف فقط )
        """
        total_advance_employee = 0
        for d in self.EmployeeAdvances.filter(advance_type=advance_type, rest__gte=1):
            if d.rest == 1:
                total_advance_employee += d.amount
            elif d.rest > 1:
                mod = d.amount % d.discount_percentage
                if mod == 0:
                    total_advance_employee += (d.discount_percentage * d.rest)
                else:
                    total_advance_employee += (
                            (d.discount_percentage * (d.rest - 1)) + (d.amount / d.discount_percentage))
                total_advance_employee += d.discount_percentage
        return total_advance_employee

    def check_amount_allowance(self):
        """
        هذه الداله سوف تقوم بارجاع مجموع البدل لموظق داخل الفتره الادارية المجدده 
        """
        obj = AdministrativePeriodsDetiles.objects.filter(from_date_for_fingerprint__lte=datetime.date.today(),
                                                          to_date_for_fingerprint__gte=datetime.date.today())
        total_allowance_employee = 0
        if obj:
            for d in self.employeeallwance_set.filter(removed=False):
                if (obj[0].from_date_for_fingerprint <= d.date) and (
                        d.date <= obj[0].to_date_for_fingerprint) and d.allwance_type.allwance_type == 'Temporary ':
                    total_allowance_employee += d.amount
                elif d.allwance_type.allwance_type == 'Permanent' and obj[0].to_date_for_fingerprint >= d.date:
                    total_allowance_employee += d.amount
        else:
            total_allowance_employee = 0
        return total_allowance_employee

    def check_amount_deduction(self):
        """
        هذه الداله سوف تقوم بارجاع مجموع الاستقطاعات لموظق داخل الفتره الادارية المجدده 
        """
        obj = AdministrativePeriodsDetiles.objects.filter(from_date_for_fingerprint__lte=datetime.date.today(),
                                                          to_date_for_fingerprint__gte=datetime.date.today())
        total_deduction_employee = 0
        if obj:
            for d in self.employeededuction_set.filter(removed=False, date__lte=obj[0].to_date_for_fingerprint,
                                                    date__gte=obj[0].from_date_for_fingerprint):
                total_deduction_employee += d.amount
        else:
            total_deduction_employee = 0
        return total_deduction_employee


class OrganizationalChart(MPTTModel):
    """[جدول الوحدات الإدارية]

    الحقول:
        [نوع الوحدة الادارية :رئيسية ام فرعية]
        [name_ar] -- [الاسم العلربي]
        [parent] -- [ الادارة الاب]  
        [note] -- [ ملاحظة]
        [person] -- [المدير]   
        [phone] -- [رقم التلفون]   
        [mainOrSub] --[نوع الوحدة الادارية :رئيسية ام فرعية]
        [my_level] -- [المستوى ]   
    """
    type_unit = ((1, _('Main')), (2, _('Sub')))
    name_ar = models.CharField(max_length=50, verbose_name=_('Node name'))
    parent = TreeForeignKey('self', on_delete=models.PROTECT, null=True, blank=True, verbose_name=_('Parent'))
    note = models.CharField(max_length=100, null=True, blank=True, verbose_name=_('Note'))
    person = models.CharField(max_length=100, null=True, blank=True, verbose_name=_('Responsible Person'))
    phone = models.CharField(max_length=50, blank=True, null=True, verbose_name=_('phone Responsible Person'))
    mainOrSub = models.PositiveIntegerField(choices=type_unit, verbose_name=_("Adminstractive Unit Type"))
    my_level = models.PositiveIntegerField()

    class Meta:
        
        db_table = 'organizational_chart'
        verbose_name = _('Organizational Chart')

    def __str__(self):
        
        return self.name_ar


class Job(models.Model):
    """[جدول الوظايف]
    الحقول:
        [name] -- [الاسم]
        [jobTitale] -- [ المسمى الوظيفي]  
    """
    name = models.CharField(max_length=50, unique=True, verbose_name=_('Job Name'))
    jobTitale = models.ForeignKey(JobTitle, on_delete=models.PROTECT, related_name='Job', verbose_name=_('Job Title'))

    class Meta:
        db_table = 'job'
        verbose_name = _('Jobs')

    def __str__(self):
        return self.name


class TypeOfSpecialties(models.Model):
    """[جدول انواع التخصصات]
    
    الحقول:
        [name] -- [الاسم]
        [Description] -- [الوصف]
    """
    name = models.CharField(max_length=50, unique=True, verbose_name=_('Special Name'))
    Description = models.CharField(max_length=100, verbose_name=_('Description'), blank=True)

    class Meta:
        db_table = 'TypeOfSpecialties'
        verbose_name = _('Specialties Types')

    def __str__(self):
        return self.name


class TypeOfDocument(models.Model):
    """[جدول انواع الوثايق]
    
    الحقول:
        [name] -- [الاسم]
        [Description] -- [الوصف]
    
    """
    name = models.CharField(max_length=200, unique=True, verbose_name=_('Document Name'))
    Description = models.CharField(max_length=200, verbose_name=_('Description'), blank=True)

    class Meta:
        db_table = 'TypeOfDocument'
        verbose_name = _('Documents Types')

    def __str__(self):
        return self.name


class TypeOfQualifications(models.Model):
    """[جدول انواع المؤهلات]
    
    الحقول:
        [name] -- [الاسم]
        [Description] -- [الوصف]
    """
    name = models.CharField(max_length=50, unique=True, verbose_name=_('Qualification Name'))
    Description = models.CharField(max_length=100, verbose_name=_('Description'), blank=True)

    class Meta:
        db_table = 'TypeOfQualifications'
        verbose_name = _('Qualifications Types')

    def __str__(self):
        return self.name


class TypeAllwoance(models.Model):
    """[جدول انواع البدل]
    
    الحقول:  
        [name] -- [الاسم]
        [description] -- [الوصف] 
    """
    ALLWANCE_TYPE = (('Temporary ', _('Temporary ')), ('Permanent', _('Permanent')),)
    allwance_type = models.CharField(max_length=20, choices=ALLWANCE_TYPE, default='Temporary ',
                                     verbose_name=_("allwance type"))
    name = models.CharField(max_length=200, verbose_name=_("Allowance name"), unique=True)
    description = models.CharField(max_length=200, verbose_name=_('Description'), blank=True)

    class Meta:
        db_table = 'type_allwance'
        verbose_name = _('Allwoances Types')

    def __str__(self):
        return self.name


class TypeDeduction(models.Model):
    """[جدول انواع الاستقطاعات]
    
    الحقول:
        [name] -- [الاسم]
        [Description] -- [الوصف]
    """
    name = models.CharField(max_length=200, verbose_name=_("Names"), unique=True)
    description = models.CharField(max_length=200, verbose_name=_('Description'), blank=True)

    class Meta:
        db_table = 'type_deduction'
        verbose_name = _('Deductions Types')

    def __str__(self):
        return self.name


class EmployeeFunctionalData(BaseModelF):
    """[جدول البيانات الوظيفية  للموظف]
    
    الحقول:        
        [organizational] -- [الوحدة الإدارية]
        [qualifications] -- [المؤهل]
        [job] -- [الوظيفه]
        [placequalification] -- [مكان المؤهل]
        [specialte] -- [التخصص]
        [placeIssueQualification] -- [بلد المؤهل]
        [qualificationIssueDate] -- [تاريخ التخرج]
        [serviceyears] -- [سنوات الخدمة]
        [ageretire] -- [عمر التقاعد]
        [accept_date] -- [تاريخ القبول]
        [salary] -- [الراتب]
        [employee] -- [رقم الموظف]
        [supervisor] -- [المشرف]
    """
    organizational = models.ForeignKey(OrganizationalChart, on_delete=models.PROTECT,
                                       related_name="EmployeeFunctionalData", default=None, null=True, blank=True,
                                       verbose_name=_('Organizational Chart'))
    qualifications = models.ForeignKey(TypeOfQualifications, on_delete=models.PROTECT,
                                       related_name="EmployeeFunctionalDatas", default=None,
                                       verbose_name=_('Qualifications'))
    job = models.ForeignKey(Job, on_delete=models.PROTECT, related_name="EmployeeFunctionalDatas",
                            verbose_name=_('Job'))
    placequalification = models.CharField(max_length=50, unique=False, verbose_name=_("Qualification country"),
                                          default=None, null=True, blank=True)
    specialte = models.ForeignKey(TypeOfSpecialties, on_delete=models.PROTECT, related_name="EmployeeFunctionalDatas",
                                  verbose_name=_('Specialties Type'))
    placeIssueQualification = models.CharField(max_length=50, unique=False, verbose_name=_("Qualification  Issue"))
    qualificationIssueDate = models.DateField(null=False, blank=False, verbose_name=_("Qualification Date"))
    serviceyears = models.IntegerField(blank=True, null=True, verbose_name=_("Years of service"))
    ageretire = models.IntegerField(blank=True, null=True, verbose_name=_("Age required to retire"))
    accept_date = models.DateField(verbose_name=_("Accept Date"))

    salary = models.FloatField(max_length=50, unique=False, verbose_name=_("Salary"))
    employee = models.ForeignKey(Emp_data, limit_choices_to={'emp_status': True}, on_delete=models.CASCADE,
                                 related_name="EmployeeFunctionalDatas", default=None, verbose_name=_('Employee'))
    supervisor = models.CharField(max_length=50, unique=False, blank=True, null=True, verbose_name=_('Supervisor'))

    class Meta:
        db_table = 'employee'
        verbose_name = _('Employee Data')

    def __str__(self):
        return str(self.employee)


class EmployeePersonalData(BaseModelF):
    """[جدول البيانات الشخصية للموظف]
    الحقول:
        [social_status] -- [الحالة الإجتماعية]
        [nationality] -- [الجنسية]
        [religin] -- [الديانة]
        [gender] -- [الجنس]
        [language] -- [اللغة]
        [bloodtype] -- [فصيلة الدم]
        [personalityType] -- [نوع البطاقة]
        [personalityNumber] -- [رقم البطاقة]
        [issueDate] -- [تاريخ الاصدار]
        [expireDate] -- [تاريخ الانتهاء]
        [issuePlace] -- [مكان الاصدار]
        [birthDate] -- [تاريخ الميلاد]
        [birthPlace] -- [مكان الميلاد]
        [arNamefornearPersonal] -- [الاسم العربي لاقرب شخص]
        [enNameFornearPersonal] -- [الاسم الاجنبي لأقرب شخص]
        [telephoneforNearPesonal] -- [رقم الهاتف لأقرب شخص]
        [phoneForNearPersonal] -- [رقم الجوال لأقرب شخص]
        [emailForNearPersonal] -- [البريد الإلكتروني لأقرب شخص]
        [note] -- [ملاحظة]
        [employee] -- [رقم الموظف]  
   
    """
    social_status = models.CharField(max_length=20, choices=socialstatus, default='1', verbose_name=_('Social Status'))
    nationality = models.CharField(max_length=200, unique=False, choices=NATIONALITIES, verbose_name=_('Nationality'))
    religin = models.CharField(max_length=200, unique=False, choices=RELIGION, verbose_name=_("Religion"))
    gender = models.CharField(max_length=200, choices=gender_, unique=False, verbose_name=_('Gender'))
    language = models.CharField(max_length=200, choices=LANGUAGE, unique=False, verbose_name=_('Language'))
    bloodtype = models.CharField(max_length=200, choices=blood_type, null=True, blank=True,
                                 verbose_name=_("blood type"))
    personalityType = models.CharField(max_length=200, null=True, blank=True, verbose_name=_("Identity type"))
    personalityNumber = models.CharField(max_length=100,null=True, blank=True, verbose_name=_("ID Number"))
    issueDate = models.DateField(null=True, blank=True, verbose_name=_("Release Date"))
    expireDate = models.DateField(auto_now=False, verbose_name=_("Expiry date"))
    issuePlace = models.CharField(max_length=200, blank=True, verbose_name=_("Issuer"))
    birthDate = models.DateField(null=True, blank=True, verbose_name=_("Birth Date"))
    birthPlace = models.CharField(max_length=200, null=True, blank=True, verbose_name=_("place of birth"))
    arNamefornearPersonal = models.CharField(max_length=200, null=True, blank=True,
                                             verbose_name=_("The arabic name of the closest person"))
    enNameFornearPersonal = models.CharField(max_length=200, null=True, blank=True,
                                             verbose_name=_("The english name of the closest person"))
    telephoneforNearPesonal = models.CharField(null=True, blank=True, verbose_name=_("Tel to the nearest person"),
                                               validators=[phone_regex], max_length=100)
    phoneForNearPersonal = models.CharField(null=True, blank=True, verbose_name=_("Phone to the nearest person"),
                                            validators=[phone_regex], max_length=100)
    emailForNearPersonal = models.EmailField(max_length=200, null=True, blank=True,
                                             verbose_name=_("Email to the nearest person"))
    note = models.CharField(max_length=200, null=True, blank=True, verbose_name=_("Note"))
    employee = models.ForeignKey(Emp_data, limit_choices_to={'emp_status': True}, on_delete=models.CASCADE,
                                 related_name="EmployeePersonalData", default=None, verbose_name=_('Employee'))

    class Meta:
        db_table = 'employeePersonalData'
        verbose_name = _('Employee Personal Data')

    def __str__(self):
        return self.employee.arname

class EmployeeContactData(BaseModelF):
    """[جدول بيانات الإتصال للموظف]
    
    الحقول:       
        [telephoneNumber] -- [الهاتف]
        [employee] -- [رقم المؤظف]
        [phoneNumber] -- [الجوال]
        [faxnumber] -- [الفاكس]
        [inboxNumber] -- [صندوق البريد]
        [address] -- [النعوان]
        [webaddress] -- [موقع الإلكترونب]
        [email] -- [الإيميل]
    """
    telephoneNumber = models.CharField(blank=True, null=True, verbose_name=_("Tel Number"), validators=[phone_regex],
                                       max_length=100)
    employee = models.ForeignKey(Emp_data, limit_choices_to={'emp_status': True}, on_delete=models.CASCADE,
                                 related_name="EmployeeContactDatas", default=None, verbose_name=_('Employee'))
    phoneNumber = models.CharField(verbose_name=_("Phone Number"), validators=[phone_regex], max_length=100)
    faxnumber = models.IntegerField(blank=True, null=True, verbose_name=_("Fax Number"))
    inboxNumber = models.IntegerField(blank=True, null=True, verbose_name=_("Mailbox number"))

    address = models.CharField(blank=True, null=True, max_length=200, verbose_name=_("Facebook"))
    webaddress = models.URLField(blank=True, null=True, max_length=200, verbose_name=_("Web Address"))
    email = models.EmailField(blank=True, null=True, max_length=200, verbose_name=_("Email"))

    class Meta:
        db_table = 'employeeContactData'
        verbose_name = _("Employee Contact Data")

    def __str__(self):
        return self.employee.arname


class Language(BaseModelF):
    """[جدول اللغات للموظف]
        [language_name] -- [اسم اللغة]
        [write_degree] -- [درجة الكتابة]
        [read_degree] -- [درجة القراءة]
        [speak_degree] -- [درجة النطق]    
        [employee] -- [الموظف]    
    """
    DEGREE = (
        ("", ""), ("Beginer", _("Beginer")), ("Medium", _("Medium")), ("Good", _("Good")),
        ("Excellent", _("Excellent")))
    language_name = models.CharField(max_length=30, null=True, blank=True, verbose_name=_("Language"))
    write_degree = models.CharField(max_length=30, choices=DEGREE, null=True, blank=True, verbose_name=_(" Write"))
    read_degree = models.CharField(max_length=30, choices=DEGREE, null=True, blank=True, verbose_name=_(" Read "))
    speak_degree = models.CharField(max_length=30, choices=DEGREE, null=True, blank=True, verbose_name=_(" Speak "))
    employee = models.ForeignKey(Emp_data, limit_choices_to={'emp_status': True}, on_delete=models.CASCADE,
                                 related_name="Languages", default=None, verbose_name=_('Employee'))

    class Meta:
        db_table = 'language'
        verbose_name = _('Language')


class ProgrammingLanguage(BaseModelF):
    """[جدل اللغات البرمجية التي يجيدها الموظف]
        [language_programming_name] -- [اسم اللغة البرمجية]    
        [programming_degree] -- [درجة الاجادة]    
        [employee] -- [الموظف]    
    """
    PROGRAMMING_DEGREE = (
        ("", ""), ("Beginer", _("Beginer")), ("Medium", _("Medium")), ("Good", _("Good")),
        ("Excellent", _("Excellent")))
    language_programming_name = models.CharField(max_length=50, null=False, blank=True,
                                                 verbose_name=_(" Programming Language Name"))
    programming_degree = models.CharField(max_length=50, choices=PROGRAMMING_DEGREE, null=True, blank=False,
                                          verbose_name=_("level"))
    employee = models.ForeignKey(Emp_data, limit_choices_to={'emp_status': True}, on_delete=models.CASCADE,
                                 default=None)

    class Meta:
        db_table = 'programmingLanguage'
        verbose_name = _('Programming Language')


class Education(BaseModelF):
    """[جدول البيانات التعليمة لطالب التوظيف]
    الحقول:
        [educational_phase] -- [ المرحلة التعليمية]    
        [institution] -- [المعهد]    
        [faculy] -- [الكلية]    
        [major] -- [الموضوع]    
        [appreciation] -- [ التقدير ]    
        [graduation_year] -- [سنة التخرج]    
        [employee] -- [الموظف]    

    """
    EDUCATIONAL_PHASE = (
        ("", ""), ("Secondry School", _("Secondry School")), ("diploma", _("diploma")), ("Bachelor", _("Bachelor")),
        ("Master", _("Master")), ("Doctorah", _("Doctorah")))
    educational_phase = models.CharField(max_length=50, choices=EDUCATIONAL_PHASE, null=False, blank=True,
                                         verbose_name=_('Educational Phase'))
    institution = models.CharField(max_length=50, null=False, blank=True, verbose_name=_('Institution'))
    faculy = models.CharField(max_length=50, null=True, blank=True, verbose_name=_('Faculy'))
    major = models.CharField(max_length=50, null=False, blank=True, verbose_name=_('Major'))
    appreciation = models.CharField(max_length=50, null=False, blank=True, verbose_name=_('Appreciation'))
    graduation_year = models.CharField(max_length=10, null=False, blank=True, verbose_name=_('Graduation Year'))
    employee = models.ForeignKey(Emp_data, limit_choices_to={'emp_status': True}, on_delete=models.CASCADE,
                                 related_name="Educations", default=None, verbose_name=_('Employee'))

    class Meta:
        db_table = 'education'
        verbose_name = _('Education')


class Job_before(BaseModelF):
    """[جدول الوظايف السابقة]
        [start_date] -- [ تاريخ بداية العمل]    
        [end_date] -- [ تاريخ النهاية ]    
        [job_title_start] -- [ اول تسمية وظيفية]    
        [job_title_end] -- [ احر تسمية وظيفية]    
        [salary_start] -- [ بداية الراتب ]    
        [salary_end] -- [ نهاية الراتب ]    
        [company_name] -- [ اسم الشركة ]    
        [job_duties] -- [ واجبات العمل ]    
        [reason_leave] -- [ سبب ترك العمل]
        [employee] -- [ رقم الوظف ]
    """
    start_date = models.CharField(blank=True, max_length=10, null=False, verbose_name=_('Start Date'))
    end_date = models.CharField(max_length=10, null=False, blank=True, verbose_name=_('End Date'))
    job_title_start = models.CharField(max_length=50, null=False, blank=True, verbose_name=_("Job Title Start"))
    job_title_end = models.CharField(max_length=50, null=False, blank=True, verbose_name=_("Job Title End"))
    salary_start = models.FloatField(blank=True, max_length=50, unique=False, default=0, verbose_name=_("Salary Start"))
    salary_end = models.FloatField(blank=True, max_length=50, unique=False, default=0, verbose_name=_("Salary Last"))
    company_name = models.CharField(blank=True, max_length=200, verbose_name=_('Company Name'))
    job_duties = models.CharField(blank=True, max_length=100, verbose_name=_('Job Duties'))
    reason_leave = models.TextField(blank=True, max_length=200, verbose_name=_('Reason Leave'))
    employee = models.ForeignKey(Emp_data, limit_choices_to={'emp_status': True}, on_delete=models.CASCADE,
                                 related_name="Job_before", default=None, verbose_name=_('Employee'))

    class Meta:
        db_table = 'job_before'
        verbose_name = _('Before Job')

class General_question(BaseModelF):
    """[جدول الاسئلة العامة]
        [work_at_night] -- [هل تمانع من العمل ليلأ]    
        [leave_out] -- [هل سافرت خارجياً من قبل؟]    
        [travel_in] -- [هل تمانع من السفر (داخلياً / خارجيا) إذا تطلب العمل ذلك ؟]
        [Convted_of_crime] -- [هل سبق وأن أدنت بأي جريمة مخلة بالشرف أو الامانة ؟]    
        [suffers_health] -- [هل تعانى من أي عاهة صحية ؟]    
        [empld_currntly] -- [هل أنت موظف حاليا؟] 
        [workd_for_ittech] -- [هل سبق أن عملت بشركة آيتي تيك ؟]    
        [have_reltve_intech] -- [هل لديك أحد ألاقارب يعمل في شركة آيتي تيك ؟]    
        [when_start_worked] -- [متى تستطيع البدء بالعمل ؟] 
        [salary_expectd] -- [ما هو الراتب الشهري الذى تتوقعه ؟]    
        [more_about_you] -- [اذكر اي معلومات تتعلق بثقافتك وهواياتك يمكن أن تدعم طلبك ؟]    
        [submsion_source] -- [مصدر التقديم] 
        [peple_refr_name_1] -- [اسم الشخص الاول]    
        [peple_job_1] -- [وظيفة الشخص الاول]    
        [peple_address_1] -- [عنوان الشخص الاول] 
        [peple_phone_1] -- [تلفون الشخص الاول]    
        [peple_refr_name_2] -- [اسم الشخص الثاني]    
        [peple_job_2] -- [وظيفة الشخص الثاني] 
        [peple_address_2] -- [عنوان الشخص الثاني]    
        [peple_phone_2] -- [تلفون الشخص الثاني]    
        [reltve_refr_name] -- [اسم الشخص الاول] 
        [relve_job_1] -- [وظيفة الشخص الاول]    
        [reltve_address_1] -- [عنوان الشخص الاول]    
        [reltve_phone_1] -- [ تلفون الشخص الاول] 
        [reltve_name_2] -- [ اسم الشخص الثاني]    
        [reltve_job_2] -- [وظيفة الشخص الثاني]    
        [reltve_address_2] -- [عنوان الشخص الثاني] 
        [reltve_phone_2] -- [تلفون الشخص الثاني]    
        [employee] -- [ رقم الموظف ]    
    
    """
    work_at_night = models.TextField(verbose_name=_("Do you object working at night ?"), blank=True)
    leave_out = models.TextField(verbose_name=_("Did you travel abroad before ?"), blank=True)
    travel_in = models.TextField(verbose_name=_("Do you mind traveling (Internal / External) if work requires ?"),
                                 blank=True)
    Convted_of_crime = models.TextField(verbose_name=_("Have you ever been convicted of a crime ?"), blank=True)
    suffers_health = models.TextField(verbose_name=_("Have you any physical defects ?"), blank=True)
    empld_currntly = models.TextField(default=False, verbose_name=_("Are you employed now ?"), blank=True)
    workd_for_ittech = models.TextField(verbose_name=_("Did you ever served in this Company ?"), blank=True)
    have_reltve_intech = models.TextField(verbose_name=_("Do you have any relatives working in any of this Company ?"),
                                          blank=True)
    when_start_worked = models.TextField(max_length=200, verbose_name=_("When can you join ?"), blank=True)
    salary_expectd = models.FloatField(max_length=50, unique=False, default=0,
                                       verbose_name=_("Gross monthly salary expected ?"),
                                       blank=True)
    more_about_you = models.TextField(max_length=300, verbose_name=_(
        "Mention any information about your knowledge and hobbies that could support your application ?"), blank=True)
    submsion_source = models.CharField(max_length=200, verbose_name=_("Referral source"), blank=True)
    peple_refr_name_1 = models.CharField(max_length=200, verbose_name=_("Name person 1"), blank=True)
    peple_job_1 = models.CharField(max_length=200, verbose_name=_("Occupation person 1"), blank=True)
    peple_address_1 = models.CharField(max_length=200, verbose_name=_("Address person 1"), blank=True)
    peple_phone_1 = models.CharField(_("Tel. No person 1"), max_length=17, validators=[phone_regex], blank=True)
    peple_refr_name_2 = models.CharField(max_length=200, verbose_name=_("Name person 2"), blank=True)
    peple_job_2 = models.CharField(max_length=100, verbose_name=_("Occupation person 2"), blank=True)
    peple_address_2 = models.CharField(max_length=100, verbose_name=_("Address person 2"), blank=True)
    peple_phone_2 = models.CharField(blank=True, verbose_name=_("Tel. No person 2"), validators=[phone_regex],
                                     max_length=100)
    reltve_refr_name = models.CharField(blank=True, max_length=200, verbose_name=_("Name person 1"))
    relve_job_1 = models.CharField(blank=True, max_length=200, verbose_name=_("Occupation person 1"))
    reltve_address_1 = models.CharField(blank=True, max_length=100, verbose_name=_("Address person 1"))
    reltve_phone_1 = models.CharField(blank=True, verbose_name=_("Tel. No person 1"),
                                      validators=[phone_regex], max_length=100)
    reltve_name_2 = models.CharField(max_length=200, verbose_name=_("Name person 2"),
                                     blank=True)
    reltve_job_2 = models.CharField(max_length=100, verbose_name=_("Occupation person 2"), blank=True)
    reltve_address_2 = models.CharField(max_length=100, verbose_name=_("Address person 2"),
                                        blank=True)
    reltve_phone_2 = models.CharField(blank=True, verbose_name=_("Tel. No person 2"),
                                      validators=[phone_regex], max_length=100)
    employee = models.ForeignKey(Emp_data, on_delete=models.CASCADE, related_name="General_questions", default=None,
                                 verbose_name=_("employee"))

    class Meta:
        db_table = 'general_question'
        verbose_name = _('General Question')
