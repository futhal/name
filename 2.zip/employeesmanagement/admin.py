# # Register your models here.
from django.contrib import admin

from .models import Emp_data

# admin.site.register(JobTitle)
# # admin.site.register(OrganizationalChart)
# admin.site.register(Job)
# admin.site.register(TypeOfSpecialties)
# admin.site.register(TypeOfDocument)
# admin.site.register(TypeOfQualifications)
# admin.site.register(EmployeeContactData)
# admin.site.register(EmployeeFunctionalData)
# admin.site.register(EmployeePersonalData)
admin.site.register(Emp_data)
