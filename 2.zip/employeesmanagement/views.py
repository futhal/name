
from django.contrib import messages
from django.contrib.auth.decorators import (
    login_required,
    permission_required,
)
from django.http import HttpResponse
from django.core import management
from django.db.models import Max
from django.contrib.auth.mixins import LoginRequiredMixin
from django.core import serializers
from django.db import transaction
from django.db.models import Q
from django.forms import (
    modelformset_factory,
)
from django.http import (
    QueryDict,
    JsonResponse,
)
from fingerprintdevices.models import Attendance
from django.shortcuts import (
    render,
    redirect,
    get_object_or_404,
)
from django.urls import reverse
from django.utils.translation import ugettext_lazy as _
from django.views.generic import (
    ListView,
    CreateView,
)
from django_datatables_view.base_datatable_view import BaseDatatableView
from mptt.templatetags.mptt_tags import cache_tree_children

from ittech.ittech_message import message
from .forms import (
    Type_deducationform,
    OrganizationalChartForm,
    CompanyDataForm,
    EmployeeRequestProgrammingLanguage,
    EmployeeRequestEducation,
    EmployeeRequestLastJob,
    Employee_general_question,
    EmployeeRequestLanguage,
    NewJobTitleForm,
    TypeAllwoanceform,
    Emp_dataForm,
    NewJobForm,
    NewTypeSpecialties,
    NewTypeOfDocument,
    NewTypeOfQualification,
    EmployeeFunDataForm,
    EmployeePersnlForm,
    EmployeeContactForm
)
from .models import (
    TypeDeduction,
    CompanyData,
    JobTitle,
    Job,
    TypeOfSpecialties,
    TypeOfDocument,
    TypeOfQualifications,
    Emp_data,
    EmployeeFunctionalData,
    TypeAllwoance,
    OrganizationalChart,
    EmployeeContactData,
    EmployeePersonalData,
    Language,
    ProgrammingLanguage,
    Education,
    General_question,
    Job_before
)

from .publicChoices import RELIGION_dict, LANGUAGE_dict, gender_, \
    NATIONALITIES_dict, socialstatus_dict
import xlwt
import django_excel as excel
from django.forms import forms
from fingerprintdevices.models import UserFinger,UserWithFingerPrint,Attendance
from employeeattendance.models import (
    WorkingPolicy,WorkingPolicyDetails,TypeOfVacations,BalanceVacations,Vacation_request,OfficialVacations,ManualAttendee
    ,ManualAttendeeDetails,CalculateAtendanceAndLeave,
    CalculateAtendanceAndLeaveDetails
)
from salary.models import JoinEmployeeWithWorkPeriod
from django.http import HttpResponse
from datetime import datetime, timedelta


# class UploadFileForm(forms.Form):
#     excel_file = forms.FileField(label='Excel',required=False)

# def upload(request): 
#     if request.method == "POST":
#         form = UploadFileForm(request.POST, request.FILES)
#         if form.is_valid():
#             filehandle = request.FILES["excel_file"]
#             return excel.make_response(filehandle.get_sheet(), "csv", file_name="download")
    
#     else:
#         form = UploadFileForm()
#     return render(request,'employeesmanagement/upload_form.html', {'form': form})

def export_data(request):
    '''
    دالة التصدير الى الاكسيل
    '''
    # request.session["open_menu"] = {"Employee_managment": "menu-open"}
    # request.session["top_menu"] = {"Employee_managment": "active"}
    # request.session["sub_menu"] = {"export_data": "active"}

    all_model={"Employee Data":Emp_data,
    'Deductions Types':TypeDeduction,
    'Allwoances Types':TypeAllwoance,
    'Company Data':CompanyData,
    'Job Titles':JobTitle,
    'Jobs':Job,
    'Specialties Types':TypeOfSpecialties,
    'Documents Types':TypeOfDocument,
    'Qualifications Types':TypeOfQualifications,
    'Organizational Chart':OrganizationalChart,
    'Employee Data':EmployeeFunctionalData,
    'Employee Personal Data':EmployeePersonalData,
    'Employee Contact Data':EmployeeContactData,
    'Language':Language,
    'Programming Language':ProgrammingLanguage,
    'User Finger':UserFinger,
    'Working Policy':WorkingPolicy,
    'Working Policy Details':WorkingPolicyDetails,
    'Vacations Types':TypeOfVacations,
    'Vacations Balance':BalanceVacations,
    'Vacation Request':Vacation_request,
    'Official Vacations':OfficialVacations,
    'Manual Attendee':ManualAttendee,
    'Manual Attendee Details':ManualAttendeeDetails,
    'Calculate Atendance And Leave':CalculateAtendanceAndLeave,
    'Calculate Atendance And Leave Details':CalculateAtendanceAndLeaveDetails,          
    'user with finger print':UserWithFingerPrint,          
    'zk_attendance':Attendance          
             
    }
  
    if request.POST:     
        model=all_model[request.POST.get('list_model')]
        if request.POST.get('list_model') == 'zk_attendance': 
                       
            last_month = datetime.today() - timedelta(days=31)
            # query_set = UserFinger.objects.value_list('name',flat=False)
            query_set = Attendance.objects.filter(date__gte=last_month).order_by('date')
            # dict_print={ 'name':'','atten':{}}
           
            # for q in query_set1:
            #     list_emp=list(filter(lambda x:x.user=q,query_set2))
                
            #     dict_print['name'] = q.user__name
            #     dict_print['name'] = q.user__name

            column_names=[
                'user__name',
                'terminal__name',
                'date',
                'time',
            ]           
            try:
                return excel.make_response_from_query_sets(query_set, column_names, "xls", status=200)

            except Exception as e:
                print(str(e),)
        else:        
            try:
                
                return excel.make_response_from_tables([model], "xls", file_name=_(request.POST.get('list_model')))
            except Exception as e:
                print(str(e))
        
  
    return render(request,"employeesmanagement/export_data.html",{'all_model':all_model})

@login_required(login_url='login')
def index(request):
    """ 
    دالة لعرض اول صفحة تظهر بعد تسجيل الدخول بنجاح 
    """
    # last_opertion = CalculateAtendanceAndLeave.objects.values('date').all().distinct('date').order_by('date')
    # # last_opertion = CalculateAtendanceAndLeave.objects.values('employee').filter(date__range=['2021-01-27','2021-01-31']).distinct('date').order_by('date')
    # # all_employee = CalculateAtendanceAndLeave.objects.values('employee').all().distinct('employee_id').order_by('employee_id')
    # print('last_opertion')
    # # print(all_employee.first())
    # # print(all_employee.last())
    # # last_opertion_first = (last_opertion.first()['date'])
    # # last_opertion_last = last_opertion.last()['date']
    
    # print('last_opertion')
    # print(last_opertion_first)
    # print(last_opertion_last)
    # print('last_opertion')
    # print(JoinEmployeeWithWorkPeriod.objects.filter(Q(from_date__gte=last_opertion_first,to_date__lte=last_opertion_last) | Q(from_date__gte=last_opertion_first,to_date=None)).values('work_period_id').distinct('work_period_id'))
    return render(request, 'starter.html', {})

@login_required(login_url='login')
def main_page(request):
    """
    دالة لعرض فورم تسجيل الدخول للمستخدم 
    """
    return render(request, 'login.html', {})

@login_required(login_url='login')
@permission_required('employeesmanagement.add_employeepersonaldata', raise_exception=True)
def employementApplication(request):
    """
     دالة لاضافة بيانات طلبات التوظيف للجداول التالية 
     1- جدول بيانات Emp_data
     2- جدول البيانات الشخصية EmployeePersnl
     3- جدول بيانات الاتصال EmployeeContact
     4- جدول الاسئلة العامة General_question
     5-  جدول اللغات Language
     6-  جدول اللغات البرمجية ProgrammingLanguage
     7- جدول الاعمال السابقة Job_before
     8- جدول الوثائق التعليمية Education
    """
    empdata = Emp_dataForm(request.POST or None, request.FILES or None)
    requestdata1 = EmployeePersnlForm(request.POST or None, request.FILES or None)
    contactdata1 = EmployeeContactForm(request.POST or None, request.FILES or None)
    general_question1 = Employee_general_question(request.POST or None, request.FILES or None)
    lastjob1 = EmployeeRequestLastJob(request.POST or None, request.FILES or None)
    language = modelformset_factory(Language, EmployeeRequestLanguage)
    programming_language = modelformset_factory(ProgrammingLanguage, EmployeeRequestProgrammingLanguage)
    educationa = modelformset_factory(Education, EmployeeRequestEducation)
    language1 = language(request.POST or None, queryset=Language.objects.none(), prefix="language")
    programming_language1 = programming_language(request.POST or None, queryset=ProgrammingLanguage.objects.none(),
                                                 prefix="Programming")
    educationa1 = educationa(request.POST or None, queryset=Education.objects.none(), prefix="educationa")
    if request.method == "POST":

        if empdata.is_valid() and requestdata1.is_valid() and contactdata1.is_valid() and language1.is_valid() and programming_language1.is_valid() and educationa1.is_valid() and lastjob1.is_valid() and general_question1.is_valid():
            try:
                with transaction.atomic():
                    obj = empdata.save(commit=False)
                    obj.save()
                    obj1 = requestdata1.save(commit=False)
                    obj1.employee_id = obj.id
                    obj1.save()

                    obj2 = contactdata1.save(commit=False)
                    obj2.employee_id = obj.id
                    obj2.save()

                    obj3 = language1.save(commit=False)
                    for form in obj3:
                        form.employee_id = obj.id
                        form.save()

                    obj4 = programming_language1.save(commit=False)
                    for form in obj4:
                        form.employee_id = obj.id
                        form.save()

                    obj5 = educationa1.save(commit=False)
                    for form in obj5:
                        form.employee_id = obj.id
                        form.save()

                    obj6 = lastjob1.save(commit=False)
                    obj6.employee_id = obj.id
                    obj6.save()

                    obj7 = general_question1.save(commit=False)
                    obj7.employee_id = obj.id
                    obj7.save()

                    messages.success(request, _("Added successfully"))
                    return redirect('employementApplication')
            except Exception:
                messages.error(request, _("Fill All Fields with data correct"))

    content = {}
    content['empdata'] = empdata
    content['requestdata'] = requestdata1
    content['contactdata'] = contactdata1
    content['formset2'] = language1
    content['formset'] = programming_language1
    content['educational'] = educationa1
    content['lastjob'] = lastjob1
    content['general_question'] = general_question1
    return render(request, 'forms/EmployeeApplications.html', content)

@login_required(login_url='login')
@permission_required('employeesmanagement.change_employeepersonaldata', raise_exception=True)
def edit_employement_application(request, pk):
    """
     دالة لتعديل بيانات طلبات التوظيف للجداول التالية 
     1- جدول بيانات Emp_data
     2- جدول البيانات الشخصية EmployeePersnl
     3- جدول بيانات الاتصال EmployeeContact
     4- جدول الاسئلة العامة General_question
     5-  جدول اللغات Language
     6-  جدول اللغات البرمجية ProgrammingLanguage
     7- جدول الاعمال السابقة Job_before
     8- جدول الوثائق التعليمية Education
    """
    # request.session["open_menu"] = {"Employee_managment": "menu-open"}
    # request.session["top_menu"] = {"Employee_managment": "active"}
    # request.session["sub_menu"] = {"functional_request": "active"}

    if pk == 0:
        messages.success(request, _("Please select the applicant and view the data"))
        return redirect('get_employee_procedures', 0)
    form = Emp_data.objects.get(pk=pk)
    empdata = Emp_dataForm(
        request.POST or None, request.FILES or None, instance=form
    )

    form = EmployeePersonalData.objects.get(employee_id=pk)
    requestdata1 = EmployeePersnlForm(
        request.POST or None, request.FILES or None, instance=form
    )
    form = General_question.objects.get(employee_id=pk)
    general_question1 = Employee_general_question(
        request.POST or None, request.FILES or None, instance=form
    )
    form = Job_before.objects.get(employee_id=pk)
    lastjob1 = EmployeeRequestLastJob(
        request.POST or None, request.FILES or None, instance=form
    )
    form = EmployeeContactData.objects.get(employee_id=pk)
    contactdata1 = EmployeeContactForm(
        request.POST or None, request.FILES or None, instance=form
    )

    language = modelformset_factory(Language, EmployeeRequestLanguage, extra=0, min_num=1)
    programming_language = modelformset_factory(ProgrammingLanguage, EmployeeRequestProgrammingLanguage, extra=0,
                                                min_num=1)
    educationa = modelformset_factory(Education, EmployeeRequestEducation, extra=0, min_num=1)
    general_question = modelformset_factory(General_question, Employee_general_question, extra=0)
    language1 = language(
        request.POST or None,
        queryset=Language.objects.filter(employee_id=pk),

        prefix="language",
    )
    programming_language1 = programming_language(
        request.POST or None,
        queryset=ProgrammingLanguage.objects.filter(employee_id=pk),
        prefix="programming_language",
    )
    educationa1 = educationa(
        request.POST or None,
        queryset=Education.objects.filter(employee_id=pk),
        prefix="educationa",
    )
    print(contactdata1)
    if empdata.is_valid() and requestdata1.is_valid() and contactdata1.is_valid() and language1.is_valid() and programming_language1.is_valid() and educationa1.is_valid() and lastjob1.is_valid() and general_question1.is_valid():
        try:
            with transaction.atomic():
                obj = empdata.save(commit=False)
                obj.save()
                obj1 = requestdata1.save(commit=False)
                obj1.employee_id = obj.id
                obj1.save()
                obj2 = contactdata1.save(commit=False)
                obj2.employee_id = obj.id
                obj2.save()

                obj3 = language1.save(commit=False)
                for form in obj3:
                    form.employee_id = obj.id
                    form.save()

                obj4 = programming_language1.save(commit=False)
                for form in obj4:
                    form.employee_id = obj.id
                    form.save()
                obj5 = educationa1.save(commit=False)
                for form in obj5:
                    form.employee_id = obj.id
                    form.save()
                obj6 = lastjob1.save(commit=False)
                obj6.employee_id = obj.id
                obj6.save()
                obj7 = general_question1.save(commit=False)
                obj7.employee_id = obj.id
                obj7.save()

                messages.success(request, _("Edited successfully"))
                return redirect('get_functional_request')
        except Exception:
            messages.error(request, _("Fill All Fields with data correct"))

    content = {}
    content['empdata'] = empdata
    content['requestdata'] = requestdata1
    content['contactdata'] = contactdata1
    content['formset2'] = language1
    content['formset'] = programming_language1
    content['educational'] = educationa1
    content['lastjob'] = lastjob1
    content['general_question'] = general_question1
    return render(request, 'forms/EmployeeApplications.html', content)
class FunctionalRequestTableListJso(BaseDatatableView):
    """
     كلاس لعرض الموظفين الذين قدموا طلبات التوظيف  
    """
    model = Emp_data
    columns = ['id', 'arname', 'enname', 'emp_status', 'action']
    order_columns = ['id', 'arname', 'enname', 'emp_status', 'action']
    count = 0

    def render_column(self, row, column):
        if column == "id":
            self.count += 1
            return self.count

        elif column == "action":
            return '<a href="{0}" style="DISPLAY: -webkit-inline-box;" class="btn btn-default btn-xs" data-toggle="tooltip" title="{1}"><i class="fa fa-edit"></i></a><a href="{2}" style="DISPLAY: -webkit-inline-box;" class="btn btn-default btn-xs" onclick=" return deleteItem()" data-toggle="tooltip" title="{3}"><i class="fa fa-trash"></i></a>'.format(
                reverse("edit_employement_application", args=[row.pk]),
                _("Edit"),
                reverse("edit_employement_application", args=[row.pk]),
                _("Delete"),
            )

        else:
            return super(FunctionalRequestTableListJso, self).render_column(row, column)

@login_required(login_url='login')
@permission_required('employeesmanagement.view_employeepersonaldata', raise_exception=True)
def get_functional_request(request):
    """
    دالة لعرض الموظفين الذين قدموا طلبات التوظيف
    """
    # request.session["open_menu"] = {"Employee_managment": "menu-open"}
    # request.session["top_menu"] = {"Employee_managment": "active"}
    # request.session["sub_menu"] = {"functional_request": "active"}
    emp_data = Emp_data.objects.filter(emp_status=False)
    return render(request, 'forms/functionalrequest.html', {'employee_data': emp_data})

@login_required(login_url='login')
@permission_required('employeesmanagement.view_companydata', raise_exception=True)
def add_data_company(request):
    """
    CompanyData دالة اضافة لجدول بيانات الشركة   
    """
    company_data1 = CompanyData.objects.all()
    company_data = None
    i = 0
    if not company_data1:

        data_form = CompanyDataForm(request.POST or None, request.FILES or None)
    else:
        company_data = company_data1.order_by('pk')[0]
        ins = CompanyData.objects.get(pk=company_data.pk)
        data_form = CompanyDataForm(request.POST or None, request.FILES or None, instance=ins)
        company_data = '/media/'+str(company_data.company_logo) if company_data.company_logo else None
    if data_form.is_valid() :
        data = data_form.save(commit=False)
        if request.POST.get('cancel') == 'True':
            data.company_logo = None
        data.save()
       
        messages.success(request, _("Added successfully"))
        return redirect('login')
    return render(request, 'forms/data_company.html', {'data_form': data_form,'company_data':company_data,'not_empty':company_data1})
class OrganizationalChartCreateView(LoginRequiredMixin,CreateView):
    """
    هذا كلاس الوحدة التنظيمية   
    """
    login_url = '/Em/login'
    def get(self, request, *args, **kwargs):
        """ 
        تعمل هذه الدالة على عرض فورم الوحدة التنظيمية  
        """
        # request.session["open_menu"] = {"Employee_managment": "menu-open"}
        # request.session["top_menu"] = {"Employee_managment": "active"}
        # request.session["sub_menu"] = {"OrganizationalChart": "active"}
        context = {
            "form": OrganizationalChartForm(),
            'permission': request.user.has_perm('employeesmanagement.add_organizationalchart')
        }
        return render(request, "employeesmanagement/OrganizationalChart.html", context)

    def post(self, request, *args, **kwargs):
        """ 
        تعمل هذه الدالة على حفظ فورم الوحدة التنظيمية  
        """
        form = OrganizationalChartForm(request.POST)
        parent = request.POST.get('parent')

        if parent:
            if int(OrganizationalChart.objects.values('mainOrSub').filter(pk=int(parent))[0]['mainOrSub']) == 2:
                '''
                لفحص هل نوع الوحدة الإدارية الاب فرعية اذا كانت
                كذلك فاننا لانستطيع إضافة وحدةإدارية تحتها
                '''
                msg = _('Node Is Sub So do not you add children this node')
                return JsonResponse({"status": 2,'message':{'message':msg,'class':'info'}})


        objects_name_node = OrganizationalChart.objects.values('name_ar').all()
        id_name = request.POST.get('name_ar')
        list__name_node = list(objects_name_node)
        if list__name_node != ' ':
            for emp in list__name_node:
                id_emp = (emp['name_ar'])
                if id_emp == id_name:
                    """ 
                     للتحقق من ان الوحدة التنظيمية غير موجودة مسبقآ  
                    """
                    msg = _('Node name is found')
                    return JsonResponse({"status": 2,'message':{'message':msg,'class':'info'}})


        objects_person = OrganizationalChart.objects.values('person').all()
        list_person = list(objects_person)
        id_person = (request.POST.get('person'))
        for emp in list_person:
            id_emp = (emp['person'])
            if id_emp == id_person:
                """ 
                    للتحقق من ان الشخص المسؤول غير موجودة مسبقآ  
                """
                msg = _('Responsible Person Is Found')
                return JsonResponse({"status": 2,'message':{'message':msg,'class':'info'}})

        if form.is_valid():

            organizational_chart = form.save(commit=False)
            organizational_chart.save()
            msg = message.add_successfully()
            result = {"status": 1, "message": msg}
        else:
            msg = message.add_error()
            result = {"status": 2, "error": form.errors.as_json(), "message": msg}
        return JsonResponse(result)
class MainOrganizationalChartListView(ListView):
    """
    هذه الدالة تعمل على ارجاع كل الوحدات التنظيمية 
    ويتم استدعائها بالجكس لتحديت حقل  
     كلما حدث تغيير في جدول الوحدات الادارية parent
     عند (الاضافة والتعديل والحذف)و
    """

    http_method_names = [
        "get",
    ]

    def get(self, request, *args, **kwargs):
        queryset = OrganizationalChart.objects.all()
        response_data = serializers.serialize("json", queryset)
        return JsonResponse(response_data, safe=False)

def organizational_chart_update_view(request, nodeId):
    """
    هذه الدالة تعمل على تعديل الوحدة  (التنظيمية)الادارية
    """

    organizational_chart = get_object_or_404(OrganizationalChart, id=nodeId)
    form = OrganizationalChartForm(request.POST or None, instance=organizational_chart)
    result = {'status':0,'message' : message.edit_error()}
    if request.method == "POST":
        parent = request.POST.get('parent')

        if parent:
            if int(OrganizationalChart.objects.values('mainOrSub').filter(pk=int(parent)).exclude(id=nodeId)[0]['mainOrSub'])== 2:
                """ 
                لفحص هل نوع الوحدة الإدارية الاب اذا كانت فرعية فاننا لانستطيع إضافة الوحدة الإدارية تحتها باستثناء هذه العقدة قبل التعديل 
                """
                msg = _('Node Is Sub So do not you add children this node')
                return JsonResponse({"status": 2,'message':{'message':msg,'class':'info'}})


        objects_name_node = OrganizationalChart.objects.values('name_ar').all().exclude(id=nodeId)
        id_name = request.POST.get('name_ar')
        list__name_node = list(objects_name_node)
        if list__name_node != ' ':
            for emp in list__name_node:
                id_emp = (emp['name_ar'])
                if id_emp == id_name:
                    """ 
                    للتحقق من ان الوحدة الادارية (التنظيمية) غير موجودة مسبقآ باستثناء هذه العقدة قبل التعديل 
                    """
                    msg = _('Node name is found')
                    return JsonResponse({"status": 2,'message':{'message':msg,'class':'info'}})


        objects_person = OrganizationalChart.objects.values('person').all().exclude(id=nodeId)
        list_person = list(objects_person)
        id_person = (request.POST.get('person'))
        for emp in list_person:
            id_emp = (emp['person'])
            if id_emp == id_person:
                """ 
                    للتحقق من ان الشخص المسؤول غير موجودة مسبقآ باستثناء هذه العقدة قبل التعديل 
                """
                msg = _('Responsible Person Is Found')
                return JsonResponse({"status": 2,'message':{'message':msg,'class':'info'}})

        if form.is_valid():
            form.save()
            msg = message.update_successfully()
            result = {"status": 1, "message": msg}
        else:
            msg = message.edit_error()
            result = {"status": 2, "error": form.errors.as_json(), "message": msg}
    return JsonResponse(result)
class OrganizationalChartListView(ListView):
    """
    هذه الدالة تعمل على ارجاع كل الوحدات التنظيمية مع الوحدات الادارية التي تندرج تحتها 
    """

    model = OrganizationalChart
    http_method_names = [
        "get",
    ]
    tempmax = 0

    def get_queryset(self):
        """
        هذه الدالة تعمل على ارجاع كل الوحدات التنظيمية  
        """
        self.tempmax = OrganizationalChart.objects.aggregate(Max("tree_id"))["tree_id__max"]
        return OrganizationalChart.objects.all()

    def get(self, request, *args, **kwargs):
        """
        هذه الدالة تعمل على ارجاع كل الوحدات التنظيمية مع الوحدات الفرعية لها   
        """
        queryset = self.get_queryset()
        root_nodes = cache_tree_children(queryset)
        dicts = []
        for n in root_nodes:
            dicts.append(self.recursive_node_to_dict(n))
            # print(dicts)

        return JsonResponse(dicts, safe=False)

    def recursive_node_to_dict(self, node):
        """
        هذه الدالة تعمل على ارجاع كل الوحدات التنظيمية التي تندرج تحت وحدة تنظيمية معينة  
        """
        result = {
            'id': node.pk,
            'name': str(node.my_level) + "-" + node.name_ar,
            'name_ar': node.name_ar,
            'person': node.person,
            'phone': node.phone,
            'parent': (node.parent_id),
            'mainOrSub': node.mainOrSub,
            'note': node.note,
            'my_level': (node.my_level),
            'max': self.tempmax,
            'tree_id': node.tree_id,
        }
        children = [self.recursive_node_to_dict(c) for c in node.get_children()]
        if children:
            result["children"] = children

        return result

def organizational_chart_delete(request):
    """
    هذه الدالة تعمل على حذف وحدة تنظيمية معينة
    ترجع رسالة النجاح او الفشل
            
    """
    nodeId = request.GET.get("nodeId")
    node = OrganizationalChart.objects.get(id=nodeId)
    try:
        if not EmployeeFunctionalData.objects.filter(organizational=nodeId):
            if node.delete():
                msg = message.delete_successfully()
                result = {"status": 1, "message": msg}

            else:
                msg = message.delete_error()
                result = {"status": 2, "message": msg}
    except:
        msg = message.delete_error()
        result = {"status": 3, "message": msg}
    
    return JsonResponse(result)
class TypeOfSpecialtiesView(LoginRequiredMixin,CreateView):
    """
    هذا كلاس لجدول انواع التخصصات    
    """
    login_url = '/Em/login'
    def get(self, request, *args, **kwargs):
        """ 
        هذه الدالة تعمل على عرض فورم فارغ لنوع التخصص او الاستعلام عن بيانات نوع التخصص المراد تعديلة 
        """
        # request.session["open_menu"] = {"Employee_managment": "menu-open"}
        # request.session["top_menu"] = {"Employee_managment": "active"}
        # request.session["sub_menu"] = {"special": "active"}

        if 'id' in request.GET.keys():
            if request.GET.get('id'):
                try:

                    data = TypeOfSpecialties.objects.filter(
                        pk=int(request.GET.get('id')))
                    result = {'status': 1, 'data': serializers.serialize('json', data)}


                except:
                    result = {'status': 0, 'data': 'ee'}

            else:
                result = {'status': 0, 'data': ''}
            return JsonResponse(result)
        else:
            if not request.user.has_perm('employeesmanagement.add_typeofspecialties') and not request.user.has_perm(
                    'employeesmanagement.change_typeofspecialties') and not request.user.has_perm(
                'employeesmanagement.delete_typeofspecialties') and not request.user.has_perm(
                'employeesmanagement.view_typeofspecialties'):
                return render(request, "error/403.html", {})
            context = {
                'form': NewTypeSpecialties(),
                'url': reverse('TypeOfSpecialtiesView'),
                'title_form': _('Add Type Special'),
                'title_list': _('Specialties Types'),
                'urljson': reverse('TypeOfSpecialtiesJson'),
                'permission': request.user.has_perm('employeesmanagement.add_typeofspecialties'),
            }
            return render(request, 'employeesmanagement/type_form.html', context)

    def post(self, request, *args, **kwargs):
        """ 
        هذه الدالة تعمل على حفظ نوع التخصص سواء كان جديد او تعديل
        """
        form = NewTypeSpecialties(request.POST)
        if request.POST.get('id'):
            data = get_object_or_404(TypeOfSpecialties, pk=int(request.POST.get('id')))
            form = NewTypeSpecialties(request.POST, instance=data)
        if form.is_valid():
            obj = form.save()
            obj.save()

            if request.POST.get('id'):

                if obj.id:
                    msg = message.update_successfully()
                    result = {'status': 1, 'message': msg}
                else:
                    msg = message.edit_error()
                    result = {'status': 2, 'message': msg}
            else:
                if obj.id:
                    msg = message.add_successfully()
                    result = {'status': 1, 'message': msg}
                else:
                    msg = message.add_error(request)
                    result = {'status': 2, 'message': msg}
        else:

            result = {'status': 0, 'error': form.errors.as_json()}
        return JsonResponse(result)

    def delete(self, request, *args, **kwargs):
        """
        هذه الدالة تعمل على حذف نوع تخصص معين  
        """
        pk = int(QueryDict(request.body).get('id'))
        if pk:
            try:
                data = get_object_or_404(TypeOfSpecialties, pk=pk)
                data.delete()
                msg = message.delete_successfully()
                result = {'status': 1, 'message': msg}
            except:
                msg = message.record_error_delete()
                result = {'status': 0, 'message': msg}
        else:
            msg = message.record_error_delete()
            result = {'status': 0, 'message': msg}
        return JsonResponse(result)
class TypeOfSpecialtiesJson(BaseDatatableView):
    """
     هذا كلاس لعرض جدول انواع التخصصات
    """

    model = TypeOfSpecialties
    columns = [
        'id'
        , 'name'
        , 'Description'
        , "action",
    ]
    order_columns = [
        'id'
        , 'name'
        , 'Description'
        , "action",
    ]
    count = 0

    def render_column(self, row, column):
        """Render Column For Datatable
        """
        if column == "id":
            self.count += 1
            return self.count
        elif column == "action":
            action = ""
            action_edit = '<a class="edit_row" data-url="{2}" data-id="{0}" ' \
                          'style="DISPLAY: -webkit-inline-box;"  data-toggle="tooltip"' \
                          ' title="{1}"><i class="fa fa-edit"></i></a>'.format(row.pk, _("Edit"),
                                                                               reverse("TypeOfSpecialtiesView"))
            action_delete = '<a class="delete_row" data-url="{2}" data-id="{0}" ' \
                            'style="DISPLAY: -webkit-inline-box;"  data-toggle="tooltip"' \
                            ' title="{1}"><i class="fa fa-trash"></i></a>'.format(row.pk, _("Delete"),
                                                                                  reverse("TypeOfSpecialtiesView"))

            if self.request.user.has_perm('employeesmanagement.change_typeofspecialties'):
                action += action_edit
            if self.request.user.has_perm('employeesmanagement.delete_typeofspecialties'):
                action += action_delete
            return action

        else:
            return super(TypeOfSpecialtiesJson, self).render_column(row, column)

    def filter_queryset(self, qs):
        """To Filter data in table using in search
        """
        sSearch = self.request.GET.get("sSearch", None)
        if sSearch:
            qs = qs.filter(
                Q(name__icontains=sSearch)
                | Q(Description__icontains=sSearch)
                | Q(id__icontains=sSearch)
            )
        return qs
class JobTitleView(LoginRequiredMixin,CreateView):
    """
    هذا كلاس لجدول المسميات الوظيفية    
    """
    login_url = '/Em/login'

    def get(self, request, *args, **kwargs):
        """ 
        هذه الدالة تعمل على عرض فورم فارغ المسميات الوظيفية او الاستعلام عن بيانات المسميات الوظيفية المراد تعديلة 
        """
        # request.session["open_menu"] = {"Employee_managment": "menu-open"}
        # request.session["top_menu"] = {"Employee_managment": "active"}
        # request.session["sub_menu"] = {"JobTitle_list": "active"}

        if 'id' in request.GET.keys():
            if request.GET.get('id'):
                try:

                    data = JobTitle.objects.filter(
                        pk=int(request.GET.get('id')))
                    result = {'status': 1, 'data': serializers.serialize('json', data)}


                except:
                    result = {'status': 0, 'data': 'ee'}

            else:
                result = {'status': 0, 'data': ''}
            return JsonResponse(result)
        else:
            if not request.user.has_perm('employeesmanagement.add_jobtitle') and not request.user.has_perm(
                    'employeesmanagement.change_jobtitle') and not request.user.has_perm(
                'employeesmanagement.delete_jobtitle') and not request.user.has_perm(
                'employeesmanagement.view_jobtitle'):
                return render(request, "error/403.html", {})

            context = {
                'form': NewJobTitleForm(),
                'url': reverse('JobTitleView'),
                'title_form': _("add Job Titel "),
                'title_list': _("add Job Titel "),
                'urljson': reverse('JobTitleJson'),
                'permission': request.user.has_perm('employeesmanagement.add_jobtitle'),

            }
            return render(request, 'employeesmanagement/type_form.html', context)

    def post(self, request, *args, **kwargs):
        """ 
        هذه الدالة تعمل على حفظ المسميات الوظيفية سواء كان جديد او تعديل
        """
        form = NewJobTitleForm(request.POST)

        if request.POST.get('id'):
            data = get_object_or_404(JobTitle, pk=int(request.POST.get('id')))
            form = NewJobTitleForm(request.POST, instance=data)
        if form.is_valid():
            obj = form.save()
            obj.save()

            if request.POST.get('id'):

                if obj.id:
                    msg = message.update_successfully()
                    result = {'status': 1, 'message': msg}
                else:
                    msg = message.edit_error()
                    result = {'status': 2, 'message': msg}
            else:
                if obj.id:
                    msg = message.add_successfully()
                    result = {'status': 1, 'message': msg}
                else:
                    msg = message.add_error(request)
                    result = {'status': 2, 'message': msg}
        else:
            result = {'status': 0, 'error': form.errors.as_json()}
        return JsonResponse(result)

    def delete(self, request, *args, **kwargs):
        """
        هذه الدالة تعمل على حذف مسمى وظيفي معين  
        """
        pk = int(QueryDict(request.body).get('id'))
        if pk:
            try:
                data = get_object_or_404(JobTitle, pk=pk)
                data.delete()
                msg = message.delete_successfully()
                result = {'status': 1, 'message': msg}
            except:
                msg = message.record_error_delete()
                result = {'status': 0, 'message': msg}
        else:
            msg = message.record_error_delete()
            result = {'status': 0, 'message': msg}
        return JsonResponse(result)
class JobTitleJson(BaseDatatableView):
    """
    كلاس لعرض جدول المسميات الوظيفية 
    """

    model = JobTitle
    columns = [
        'id'
        , 'name'
        , 'Description'
        , "action",
    ]
    order_columns = [
        'id'
        , 'name'
        , 'Description'
        , "action",
    ]
    count = 0

    def render_column(self, row, column):
        """Render Column For Datatable
        """
        if column == "id":
            self.count += 1
            return self.count
        elif column == "action":
            action = ""
            action_edit = '<a class="edit_row" data-url="{2}" data-id="{0}" ' \
                          'style="DISPLAY: -webkit-inline-box;"  data-toggle="tooltip"' \
                          ' title="{1}"><i class="fa fa-edit"></i></a>'.format(row.pk, _("Edit"),
                                                                               reverse("JobTitleView"))
            action_delete = '<a class="delete_row" data-url="{2}" data-id="{0}" ' \
                            'style="DISPLAY: -webkit-inline-box;"  data-toggle="tooltip"' \
                            ' title="{1}"><i class="fa fa-trash"></i></a>'.format(row.pk, _("Delete"),
                                                                                  reverse("JobTitleView"))

            if self.request.user.has_perm('employeesmanagement.change_jobtitle'):
                action += action_edit
            if self.request.user.has_perm('employeesmanagement.delete_jobtitle'):
                action += action_delete
            return action
        else:
            return super(JobTitleJson, self).render_column(row, column)

    def filter_queryset(self, qs):
        """To Filter data in table using in search
        """
        sSearch = self.request.GET.get("sSearch", None)
        if sSearch:
            qs = qs.filter(
                Q(name__icontains=sSearch)
                | Q(Description__icontains=sSearch)
                | Q(id__icontains=sSearch)
            )
        return qs
class JobView(LoginRequiredMixin,CreateView):
    """
    كلاس جدول الوظائف 
    """
    login_url = '/Em/login'
    def get(self, request, *args, **kwargs):
        """ 
        هذه الدالة تعمل على عرض فورم فارغ  لجدول الوظائف او الاستعلام عن بيانات الوظائف المراد تعديلة 
        """
        # request.session["open_menu"] = {"Employee_managment": "menu-open"}
        # request.session["top_menu"] = {"Employee_managment": "active"}
        # request.session["sub_menu"] = {"job_data": "active"}
        if 'id' in request.GET.keys():
            if request.GET.get('id'):
                try:

                    data = Job.objects.filter(pk=int(request.GET.get('id')))

                    result = {'status': 1, 'data': serializers.serialize('json', data)}


                except:
                    result = {'status': 0, 'data': 'ee'}
            else:
                result = {'status': 0, 'data': ''}
            return JsonResponse(result)
        else:
            if not request.user.has_perm('employeesmanagement.add_job') and not request.user.has_perm(
                    'employeesmanagement.change_job') and not request.user.has_perm(
                'employeesmanagement.delete_job') and not request.user.has_perm('employeesmanagement.view_job'):
                return render(request, "error/403.html", {})
            context = {
                'form': NewJobForm(),
                'url': reverse('JobView'),
                'title_form': _('Add Job'),
                'title_list': _("Jobs"),
                'urljson': reverse('JobJson'),
                'permission': request.user.has_perm('employeesmanagement.add_job'),

            }
            return render(request, 'employeesmanagement/Jobs.html', context)

    def post(self, request, *args, **kwargs):
        """ 
        هذه الدالة تعمل على حفظ الوظئف سواء كان جديد او تعديل
        """
        form = NewJobForm(request.POST)

        if request.POST.get('id'):
            data = get_object_or_404(Job, pk=int(request.POST.get('id')))
            form = NewJobForm(request.POST, instance=data)
        if form.is_valid():
            obj = form.save()
            obj.save()
            if request.POST.get('id'):

                if obj.id:
                    msg = message.update_successfully()
                    result = {'status': 1, 'message': msg}
                else:
                    msg = message.edit_error()
                    result = {'status': 2, 'message': msg}
            else:
                if obj.id:
                    msg = message.add_successfully()
                    result = {'status': 1, 'message': msg}
                else:
                    msg = message.add_error(request)
                    result = {'status': 2, 'message': msg}
        else:

            result = {'status': 0, 'error': form.errors.as_json()}
        return JsonResponse(result)

    def delete(self, request, *args, **kwargs):
        """
        هذه الدالة تعمل على حذف  وظيفة معين  
        """
        pk = int(QueryDict(request.body).get('id'))
        if pk:
            try:
                data = get_object_or_404(Job, pk=pk)
                data.delete()
                msg = message.delete_successfully()
                result = {'status': 1, 'message': msg}
            except:
                msg = message.record_error_delete()
                result = {'status': 0, 'message': msg}
        else:
            msg = message.record_error_delete()
            result = {'status': 0, 'message': msg}
        return JsonResponse(result)
class JobJson(BaseDatatableView):
    """
    هذا كلاس لعرض الوظائف  
    """

    model = Job
    columns = [
        'id'
        , 'name'
        , 'jobTitale'
        , "action",
    ]
    order_columns = [
        'id'
        , 'name'
        , 'jobTitale'
        , "action",
    ]
    count = 0

    def render_column(self, row, column):
        """Render Column For Datatable
        """
        if column == "id":
            self.count += 1
            return self.count
        elif column == "action":
            action = ""
            action_edit = '<a class="edit_row" data-url="{2}" data-id="{0}" ' \
                          'style="DISPLAY: -webkit-inline-box;"  data-toggle="tooltip"' \
                          ' title="{1}"><i class="fa fa-edit"></i></a>'.format(row.pk, _("Edit"), reverse("JobView"))
            action_delete = '<a class="delete_row" data-url="{2}" data-id="{0}" ' \
                            'style="DISPLAY: -webkit-inline-box;"  data-toggle="tooltip"' \
                            ' title="{1}"><i class="fa fa-trash"></i></a>'.format(row.pk, _("Delete"),
                                                                                  reverse("JobView"))

            if self.request.user.has_perm('employeesmanagement.change_add_job'):
                action += action_edit
            if self.request.user.has_perm('employeesmanagement.delete_add_job'):
                action += action_delete
            return action

        else:
            return super(JobJson, self).render_column(row, column)

    def filter_queryset(self, qs):
        """To Filter data in table using in search
        """
        sSearch = self.request.GET.get("sSearch", None)
        if sSearch:
            qs = qs.filter(
                Q(name__icontains=sSearch)
                | Q(jobTitale__name__icontains=sSearch)
                | Q(id__icontains=sSearch)
            )
        return qs
class TypeOfDocumentView(LoginRequiredMixin,CreateView):
    """
    كلاس جدول انواع الوثائق  
    """
    login_url = '/Em/login'
    def get(self, request, *args, **kwargs):
        """ 
        هذه الدالة تعمل على عرض فورم فارغ لجدول انواع الوثائق او الاستعلام عن بيانات انواع الوثائق المراد تعديلة 
        """
        # request.session["open_menu"] = {"Employee_managment": "menu-open"}
        # request.session["top_menu"] = {"Employee_managment": "active"}
        # request.session["sub_menu"] = {"documents": "active"}

        if 'id' in request.GET.keys():

            if request.GET.get('id'):
                try:

                    data = TypeOfDocument.objects.filter(
                        pk=int(request.GET.get('id')))

                    result = {'status': 1, 'data': serializers.serialize('json', data)}



                except:
                    result = {'status': 0, 'data': 'ee'}

            else:
                result = {'status': 0, 'data': ''}
            return JsonResponse(result)
        else:
            if not request.user.has_perm('employeesmanagement.add_typeofdocument') and not request.user.has_perm(
                    'employeesmanagement.change_typeofdocument') and not request.user.has_perm(
                'employeesmanagement.delete_typeofdocument') and not request.user.has_perm(
                'employeesmanagement.view_typeofdocument'):
                return render(request, "error/403.html", {})
            context = {
                'form': NewTypeOfDocument(),
                'url': reverse('TypeOfDocumentView'),
                'title_form': _('Add Document Type'),
                'title_list': _('Add Document Type'),
                'urljson': reverse('TypeOfDocumentJson'),
                'permission': request.user.has_perm('employeesmanagement.add_typeofdocument'),
            }
            return render(request, 'employeesmanagement/type_form.html', context)

    def post(self, request, *args, **kwargs):
        """ 
        هذه الدالة تعمل على حفظ انواع الوثائق سواء كان جديد او تعديل
        """
        form = NewTypeOfDocument(request.POST)

        if request.POST.get('id'):
            data = get_object_or_404(TypeOfDocument, pk=int(request.POST.get('id')))
            form = NewTypeOfDocument(request.POST, instance=data)
        if form.is_valid():
            obj = form.save()
            obj.save()

            if request.POST.get('id'):

                if obj.id:
                    msg = message.update_successfully()
                    result = {'status': 1, 'message': msg}
                else:
                    msg = message.edit_error()
                    result = {'status': 2, 'message': msg}
            else:
                if obj.id:
                    msg = message.add_successfully()
                    result = {'status': 1, 'message': msg}
                else:
                    msg = message.add_error(request)
                    result = {'status': 2, 'message': msg}
        else:
            result = {'status': 0, 'error': form.errors.as_json()}
        return JsonResponse(result)

    def delete(self, request, *args, **kwargs):
        """
        هذه الدالة تعمل على حذف  نوع وثيقة معين  
        """
        pk = int(QueryDict(request.body).get('id'))
        if pk:
            try:
                data = get_object_or_404(TypeOfDocument, pk=pk)
                data.delete()
                msg = message.delete_successfully()
                result = {'status': 1, 'message': msg}
            except:
                msg = message.record_error_delete()
                result = {'status': 0, 'message': msg}
        else:
            msg = message.record_error_delete()
            result = {'status': 0, 'message': msg}
        return JsonResponse(result)
class TypeOfDocumentJson(BaseDatatableView):
    """
    هذا الكلاس لعرض انواع الوثائق
    """

    model = TypeOfDocument
    columns = [
        'id'
        , 'name'
        , 'Description'
        , "action",
    ]
    order_columns = [
        'id'
        , 'name'
        , 'Description'
        , "action",
    ]
    count = 0

    def render_column(self, row, column):
        """Render Column For Datatable
        """
        if column == "id":
            self.count += 1
            return self.count
        elif column == "action":
            action = ""
            action_edit = '<a class="edit_row" data-url="{2}" data-id="{0}" ' \
                          'style="DISPLAY: -webkit-inline-box;"  data-toggle="tooltip"' \
                          ' title="{1}"><i class="fa fa-edit"></i></a>'.format(row.pk, _("Edit"),
                                                                               reverse("TypeOfDocumentView"))
            action_delete = '<a class="delete_row" data-url="{2}" data-id="{0}" ' \
                            'style="DISPLAY: -webkit-inline-box;"  data-toggle="tooltip"' \
                            ' title="{1}"><i class="fa fa-trash"></i></a>'.format(row.pk, _("Delete"),
                                                                                  reverse("TypeOfDocumentView"))

            if self.request.user.has_perm('employeesmanagement.change_typeofdocument'):
                action += action_edit
            if self.request.user.has_perm('employeesmanagement.delete_typeofdocument'):
                action += action_delete
            return action

        else:
            return super(TypeOfDocumentJson, self).render_column(row, column)

    def filter_queryset(self, qs):
        """To Filter data in table using in search
        """
        sSearch = self.request.GET.get("sSearch", None)
        if sSearch:
            qs = qs.filter(
                Q(name__icontains=sSearch)
                | Q(Description__icontains=sSearch)
                | Q(id__icontains=sSearch)
            )
        return qs
class TypeOfQualificationsView(LoginRequiredMixin,CreateView):
    """
    كلاس جدول انواع المؤهلات  
    """
    login_url = '/Em/login'
    def get(self, request, *args, **kwargs):
        """ 
        هذه الدالة تعمل على عرض فورم فارغ لجدول انواع المؤهلات او الاستعلام عن بيانات انواع المؤهلات المراد تعديلة 
        """
        # request.session["open_menu"] = {"Employee_managment": "menu-open"}
        # request.session["top_menu"] = {"Employee_managment": "active"}
        # request.session["sub_menu"] = {"qualf_data": "active"}

        if 'id' in request.GET.keys():
            if request.GET.get('id'):
                try:

                    data = TypeOfQualifications.objects.filter(
                        pk=int(request.GET.get('id')))
                    result = {'status': 1, 'data': serializers.serialize('json', data)}


                except:
                    result = {'status': 0, 'data': 'ee'}

            else:
                result = {'status': 0, 'data': ''}
            return JsonResponse(result)
        else:
            if not request.user.has_perm('employeesmanagement.add_typeofqualifications') and not request.user.has_perm(
                    'employeesmanagement.change_typeofqualifications') and not request.user.has_perm(
                'employeesmanagement.delete_typeofqualifications') and not request.user.has_perm(
                'employeesmanagement.view_typeofqualifications'):
                return render(request, "error/403.html", {})
            context = {
                'form': NewTypeOfQualification(),
                'url': reverse('TypeOfQualificationsView'),
                'title_form': _("Add Qualification"),
                'title_list': _(" Qualification Type"),
                'urljson': reverse('TypeOfQualificationsJson'),
                'permission': request.user.has_perm('employeesmanagement.add_typeofqualifications')

            }
            return render(request, 'employeesmanagement/type_form.html', context)

    def post(self, request, *args, **kwargs):
        """ 
        هذه الدالة تعمل على حفظ انواع المؤهلات سواء كان جديد او تعديل
        """
        form = NewTypeOfQualification(request.POST)
        if request.POST.get('id'):
            data = get_object_or_404(TypeOfQualifications, pk=int(request.POST.get('id')))
            form = NewTypeOfQualification(request.POST, instance=data)
        if form.is_valid():
            print('O'*30)
            obj = form.save()
            obj.save()

            if request.POST.get('id'):

                if obj.id:
                    msg = message.update_successfully()
                    result = {'status': 1, 'message': msg}
                else:
                    msg = message.edit_error()
                    result = {'status': 2, 'message': msg}
            else:
                if obj.id:
                    msg = message.add_successfully()
                    result = {'status': 1, 'message': msg}
                else:
                    msg = message.add_error(request)
                    result = {'status': 2, 'message': msg}
        else:
            result = {'status': 0, 'error': form.errors.as_json()}
        return JsonResponse(result)

    def delete(self, request, *args, **kwargs):
        """
        هذه الدالة تعمل على حذف  نوع المؤهل معين  
        """
        pk = int(QueryDict(request.body).get('id'))
        if pk:
            try:
                data = get_object_or_404(TypeOfQualifications, pk=pk)
                data.delete()
                msg = message.delete_successfully()
                result = {'status': 1, 'message': msg}
            except:
                msg = message.record_error_delete()
                result = {'status': 0, 'message': msg}
        else:
            msg = message.record_error_delete()
            result = {'status': 0, 'message': msg}
        return JsonResponse(result)
class TypeOfQualificationsJson(BaseDatatableView):
    """
    كلاس لعرض جدول انواع المؤهلات
    """

    model = TypeOfQualifications
    columns = [
        'id'
        , 'name'
        , 'Description'
        , "action",
    ]
    order_columns = [
        'id'
        , 'name'
        , 'Description'
        , "action",
    ]
    count = 0

    def render_column(self, row, column):
        """Render Column For Datatable
        """
        if column == "id":
            self.count += 1
            return self.count
        elif column == "action":
            action = ""
            action_edit = '<a class="edit_row" data-url="{2}" data-id="{0}" ' \
                          'style="DISPLAY: -webkit-inline-box;"  data-toggle="tooltip"' \
                          ' title="{1}"><i class="fa fa-edit"></i></a>'.format(row.pk, _("Edit"),
                                                                               reverse("TypeOfQualificationsView"))
            action_delete = '<a class="delete_row" data-url="{2}" data-id="{0}" ' \
                            'style="DISPLAY: -webkit-inline-box;"  data-toggle="tooltip"' \
                            ' title="{1}"><i class="fa fa-trash"></i></a>'.format(row.pk, _("Delete"),
                                                                                  reverse("TypeOfQualificationsView"))

            if self.request.user.has_perm('employeesmanagement.change_typeofqualifications'):
                action += action_edit
            if self.request.user.has_perm('employeesmanagement.delete_typeofqualifications'):
                action += action_delete
            return action

        else:
            return super(TypeOfQualificationsJson, self).render_column(row, column)

    def filter_queryset(self, qs):
        """To Filter data in table using in search
        """
        sSearch = self.request.GET.get("sSearch", None)
        if sSearch:
            qs = qs.filter(
                Q(name__icontains=sSearch)
                | Q(Description__icontains=sSearch)
                | Q(id__icontains=sSearch)
            )
        return qs
class TypeAllwanceView(LoginRequiredMixin,CreateView):
    """
    كلاس جدول انواع البدلات  
    """
    login_url = '/Em/login'
    def get(self, request, *args, **kwargs):
        """ 
        هذه الدالة تعمل على عرض فورم فارغ لجدول انواع البدلات او الاستعلام عن بيانات انواع البدلات المراد تعديلة 
        """
        # request.session["open_menu"] = {"salary": "menu-open"}
        # request.session["top_menu"] = {"Employee_managment": "active"}
        # request.session["sub_menu"] = {"typeallwance_data": "active"}

        if 'id' in request.GET.keys():
            if request.GET.get('id'):
                try:

                    data = TypeAllwoance.objects.filter(
                        pk=int(request.GET.get('id')))
                    result = {'status': 1, 'data': serializers.serialize('json', data)}

                except:
                    result = {'status': 0, 'data': 'ee'}

            else:
                result = {'status': 0, 'data': ''}
            return JsonResponse(result)
        else:
            if not request.user.has_perm('employeesmanagement.add_typeallwoance') and not request.user.has_perm(
                    'employeesmanagement.delete_typeallwoance') and not request.user.has_perm(
                'employeesmanagement.change_typeallwoance') and not request.user.has_perm(
                'employeesmanagement.view_typeallwoance'):
                return render(request, "error/403.html", {})
            context = {
                'form': TypeAllwoanceform(),
                'url': reverse('TypeAllwanceView'),
                'title_form': _('Add Allowance Type'),
                'title_list': _("Allwances  Types"),
                'urljson': reverse('TypeAllwanceJson'),
                'permission': request.user.has_perm('employeesmanagement.add_typeallwoance')

            }
            return render(request, 'employeesmanagement/allwance_type.html', context)

    def post(self, request, *args, **kwargs):
        """ 
        هذه الدالة تعمل على حفظ انواع البدلاب سواء كان جديد او تعديل
        """
        form = TypeAllwoanceform(request.POST)
        if request.POST.get('id'):
            data = get_object_or_404(TypeAllwoance, pk=int(request.POST.get('id')))
            form = TypeAllwoanceform(request.POST, instance=data)
        if form.is_valid():
            obj = form.save()
            obj.save()

            if request.POST.get('id'):

                if obj.id:
                    msg = message.update_successfully()
                    result = {'status': 1, 'message': msg}
                else:
                    msg = message.edit_error()
                    result = {'status': 2, 'message': msg}
            else:
                if obj.id:
                    msg = message.add_successfully()
                    result = {'status': 1, 'message': msg}
                else:
                    msg = message.add_error(request)
                    result = {'status': 2, 'message': msg}
        else:
            result = {'status': 0, 'error': form.errors.as_json()}
        return JsonResponse(result)

    def delete(self, request, *args, **kwargs):
        """
        هذه الدالة تعمل على حذف  نوع البدلات معين  
        """
        pk = int(QueryDict(request.body).get('id'))
        if pk:
            try:
                data = get_object_or_404(TypeAllwoance, pk=pk)
                data.delete()
                msg = message.delete_successfully()
                result = {'status': 1, 'message': msg}
            except:
                msg = message.record_error_delete()
                result = {'status': 0, 'message': msg}
        else:
            msg = message.record_error_delete()
            result = {'status': 0, 'message': msg}
        return JsonResponse(result)

class TypeAllwanceJson(BaseDatatableView):
    """
    كلاس لعرض  جدول انواع البدلات
    """

    model = TypeAllwoance
    columns = [
        'id'
        , 'name'
        , 'allwance_type'
        , 'description'
        , "action",
    ]

    order_columns = [
        'id'
        , 'name'
        , 'description'
        , 'allwance_type'
        , "action",
    ]
    count = 0

    def render_column(self, row, column):
        """Render Column For Datatable
        """
        if column == "id":
            self.count += 1
            return self.count
        elif column == "action":
            action = ""
            action_edit = '<a class="edit_row" data-url="{2}" data-id="{0}" ' \
                          'style="DISPLAY: -webkit-inline-box;"  data-toggle="tooltip"' \
                          ' title="{1}"><i class="fa fa-edit"></i></a>'.format(row.pk, _("Edit"),
                                                                               reverse("TypeAllwanceView"))
            action_delete = '<a class="delete_row" data-url="{2}" data-id="{0}" ' \
                            'style="DISPLAY: -webkit-inline-box;"  data-toggle="tooltip"' \
                            ' title="{1}"><i class="fa fa-trash"></i></a>'.format(row.pk, _("Delete"),
                                                                                  reverse("TypeAllwanceView"))

            if self.request.user.has_perm('employeesmanagement.change_typeallwoance'):
                action += action_edit
            if self.request.user.has_perm('employeesmanagement.delete_typeallwoance'):
                action += action_delete
            return action

        else:
            return super(TypeAllwanceJson, self).render_column(row, column)

    def filter_queryset(self, qs):
        """To Filter data in table using in search
        """
        sSearch = self.request.GET.get("sSearch", None)
        if sSearch:
            qs = qs.filter(
                Q(name__icontains=sSearch)
                | Q(description__icontains=sSearch)
                | Q(id__icontains=sSearch)
            )
        return qs
class TypeDeducationView(LoginRequiredMixin,CreateView):
    """
    كلاس جدول انواع الاستقطاعات  
    """
    login_url = '/Em/login'
    def get(self, request, *args, **kwargs):
        """ 
        هذه الدالة تعمل على عرض فورم فارغ لجدول انواع الاستقطاعات او الاستعلام عن بيانات انواع الاستقطاعات المراد تعديلة 
        """
        # if request.user.has_perm('employeesmanagement.add_typededuction'):
        # request.session["open_menu"] = {"salary": "menu-open"}
        # request.session["top_menu"] = {"Employee_managment": "active"}
        # request.session["sub_menu"] = {"type_deducation_data": "active"}

        if 'id' in request.GET.keys():
            if request.GET.get('id'):
                try:

                    data = TypeDeduction.objects.filter(
                        pk=int(request.GET.get('id')))
                    result = {'status': 1, 'data': serializers.serialize('json', data)}


                except:
                    result = {'status': 0, 'data': 'ee'}

            else:
                result = {'status': 0, 'data': ''}
            return JsonResponse(result)
        else:
            if not request.user.has_perm('employeesmanagement.add_typededuction') and not request.user.has_perm(
                    'employeesmanagement.change_typededuction') and not request.user.has_perm(
                'employeesmanagement.delete_typededuction') and not request.user.has_perm(
                'employeesmanagement.view_typededuction'):
                return render(request, "error/403.html", {})
            context = {
                'form': Type_deducationform(),
                'url': reverse('TypeDeducationView'),
                'title_form': _('Add Type Deducation'),
                'title_list': _("Deduction Type"),
                'urljson': reverse('TypeDeducationJson'),
                'permission': request.user.has_perm('employeesmanagement.add_typededuction')

            }
            return render(request, 'employeesmanagement/type_form.html', context)

    def post(self, request, *args, **kwargs):
        """ 
        هذه الدالة تعمل على حفظ انواع الاستقطاعات سواء كان جديد او تعديل
        """
        form = Type_deducationform(request.POST)
        if request.POST.get('id'):
            data = get_object_or_404(TypeDeduction, pk=int(request.POST.get('id')))
            form = Type_deducationform(request.POST, instance=data)
        if form.is_valid():
            obj = form.save()
            obj.save()

            if request.POST.get('id'):

                if obj.id:
                    msg = message.update_successfully()
                    result = {'status': 1, 'message': msg}
                else:
                    msg = message.edit_error()
                    result = {'status': 2, 'message': msg}
            else:
                if obj.id:
                    msg = message.add_successfully()
                    result = {'status': 1, 'message': msg}
                else:
                    msg = message.add_error(request)
                    result = {'status': 2, 'message': msg}
        else:
            result = {'status': 0, 'error': form.errors.as_json()}
        return JsonResponse(result)

    def delete(self, request, *args, **kwargs):
        """
        هذه الدالة تعمل على حذف  نوع الموظفين معين  
        """
        pk = int(QueryDict(request.body).get('id'))
        if pk:
            try:
                data = get_object_or_404(TypeDeduction, pk=pk)
                data.delete()
                msg = message.delete_successfully()
                result = {'status': 1, 'message': msg}
            except:
                msg = message.record_error_delete()
                result = {'status': 0, 'message': msg}
        else:
            msg = message.record_error_delete()
            result = {'status': 0, 'message': msg}
        return JsonResponse(result)
class TypeDeducationJson(BaseDatatableView):
    """
    كلاس لعرض جدول انواع الاستقطاعات
    """

    model = TypeDeduction
    columns = [
        'id'
        , 'name'
        , 'description'
        , "action",
    ]
    order_columns = [
        'id'
        , 'name'
        , 'description'
        , "action",
    ]
    count = 0

    def render_column(self, row, column):
        """Render Column For Datatable
        """
        if column == "id":
            self.count += 1
            return self.count
        elif column == "action":
            action = ""
            action_edit = '<a class="edit_row" data-url="{2}" data-id="{0}" ' \
                          'style="DISPLAY: -webkit-inline-box;"  data-toggle="tooltip"' \
                          ' title="{1}"><i class="fa fa-edit"></i></a>'.format(row.pk, _("Edit"),
                                                                               reverse("TypeDeducationView"))
            action_delete = '<a class="delete_row" data-url="{2}" data-id="{0}" ' \
                            'style="DISPLAY: -webkit-inline-box;"  data-toggle="tooltip"' \
                            ' title="{1}"><i class="fa fa-trash"></i></a>'.format(row.pk, _("Delete"),
                                                                                  reverse("TypeDeducationView"))

            if self.request.user.has_perm('employeesmanagement.change_typededuction'):
                action += action_edit
            if self.request.user.has_perm('employeesmanagement.delete_typeeduction'):
                action += action_delete
            return action
        else:
            return super(TypeDeducationJson, self).render_column(row, column)

    def filter_queryset(self, qs):
        """To Filter data in table using in search
        """
        sSearch = self.request.GET.get("sSearch", None)
        if sSearch:
            qs = qs.filter(
                Q(name__icontains=sSearch)
                | Q(description__icontains=sSearch)
                | Q(id__icontains=sSearch)
            )
        return qs
class EmployeeDataView(LoginRequiredMixin,CreateView):
    """
    كلاس جدول بيانات الموظفين  
    """
    login_url = '/Em/login'
    def delete(self, request, *args, **kwargs):
        """
        هذه الدالة تعمل على حذف  موظف معين  
        Emp_data
        EmployeeFunctionalData
        EmployeePersonalData
        EmployeeContactData
        """
        # request.session["open_menu"] = {"Employee_managment": "menu-open"}
        # request.session["top_menu"] = {"Employee_managment": "active"}
        # request.session["sub_menu"] = {"Employee_data": "active"}
        pk = int(QueryDict(request.body).get('id'))
        print(pk,'*'*44)
        if pk:
            obj = Emp_data.objects.filter(pk=pk)
            msg = message.record_error_delete()
            result = {'status': 1, 'message': {'message':obj[0].delete_emoloyee()}}

        return JsonResponse(result)

    def get(self, request, *args, **kwargs):
        """ 
        هذه الدالة تعمل على عرض فورم فارغ لجدول الموظفين او الاستعلام عن بيانات الموظف المراد تعديلة 
        Emp_data
        EmployeeFunctionalData
        EmployeePersonalData
        EmployeeContactData
        """
        # request.session["open_menu"] = {"Employee_managment": "menu-open"}
        # request.session["top_menu"] = {"Employee_managment": "active"}
        # request.session["sub_menu"] = {"Employee_data": "active"}
        if 'id' in request.GET.keys():
            if request.GET.get('id'):
                try:
                    print('*'*33)
                    data = Emp_data.objects.filter(pk=int(request.GET.get('id')))
                    data1 = EmployeeFunctionalData.objects.filter(employee_id=int(request.GET.get('id')))
                    data2 = EmployeePersonalData.objects.filter(employee_id=int(request.GET.get('id')))
                    data3 = EmployeeContactData.objects.filter(employee_id=int(request.GET.get('id')))

                    result = {'status': 1, 'data': serializers.serialize('json', data),'image':data[0].personal_image.url if data[0].personal_image else '/media/media/employeesmanagement/photes/user.jpg',
                              'data1': serializers.serialize('json', data1),
                              'data2': serializers.serialize('json', data2),
                              'data3': serializers.serialize('json', data3),
                              }

                except Exception as e:
                    print(str(e))
                    result = {'status': 0, 'data': 'ee', 'data1': '', 'data2': '', 'data3': ''}

            else:
                result = {'status': 0, 'data': '', 'data1': '', 'data2': '', 'data3': ''}
            return JsonResponse(result)
        else:
            if not request.user.has_perm(
                    'employeesmanagement.add_employeefunctionaldata') and not request.user.has_perm(
                'employeesmanagement.change_employeefunctionaldata') and not request.user.has_perm(
                'employeesmanagement.delete_employeefunctionaldata') and not request.user.has_perm(
                'employeesmanagement.view_employeefunctionaldata'):
                return render(request, "error/403.html", {})
            context = {
                'empdata': Emp_dataForm(),
                'form': EmployeeFunDataForm(),
                'form2': EmployeePersnlForm(),
                'form3': EmployeeContactForm(),
                'url': reverse('EmployeeDataView'),
                'title_form': _('Add Employee Data'),
                'title_list': _("Employee Data"),
                'urljson': reverse('EmployeeDataJson'),
                'permission': request.user.has_perm('employeesmanagement.add_employeefunctionaldata')  # and

            }
            return render(request, 'employeesmanagement/EmployeeData.html', context)

    def post(self, request, *args, **kwargs):
        """ 
        هذه الدالة تعمل على حفظ بيانات موظف سواء كان جديد او تعديل
        """
        empdata = Emp_dataForm(request.POST)
        form = EmployeeFunDataForm(request.POST)
        form2 = EmployeePersnlForm(request.POST)
        form3 = EmployeeContactForm(request.POST)
        # image = request.FILES.get('personal_image')
        print('image'*33)
        if request.POST.get('id'):
            print('kkkkkkkkkkkkkkk',request.POST.get('id'))
            ins = get_object_or_404(Emp_data, pk=int(request.POST.get('id')))
            print(ins)
            empdata = Emp_dataForm(request.POST or None, request.FILES or None, instance=ins)
            ins1 = get_object_or_404(EmployeeFunctionalData, employee_id=int(request.POST.get('id')))
            print(ins1)
            form = EmployeeFunDataForm(request.POST or None, request.FILES or None, instance=ins1)
            ins2 = get_object_or_404(EmployeePersonalData, employee_id=int(request.POST.get('id')))
            print(ins2)
            form2 = EmployeePersnlForm(request.POST or None, request.FILES or None, instance=ins2)
            ins3 = get_object_or_404(EmployeeContactData, employee_id=int(request.POST.get('id')))
            print(ins3)
            form3 = EmployeeContactForm(request.POST or None, request.FILES or None, instance=ins3)

        if empdata.is_valid() and form.is_valid() and form2.is_valid() and form3.is_valid():
            print('ffffffffffff')
            try:

                with transaction.atomic():
                    obj = empdata.save(commit=False)
                    obj.emp_status = True
                    if request.POST.get('cancel') == 'True':
                        obj.personal_image  = None
                    obj.save()
                    obj1 = form.save(commit=False)
                    obj1.employee_id = obj.id 
                    obj1.save()
                    obj2 = form2.save(commit=False)
                    obj2.employee_id = obj.id
                    obj2.save()
                    obj3 = form3.save(commit=False)
                    obj3.employee_id = obj.id
                    obj3.save()

                if request.POST.get('id'):
                    if obj.id and obj1.id and obj2.id and obj3.id:
                        msg = message.update_successfully()
                        result = {'status': 1, 'message': msg}
                    else:
                        msg = message.edit_error()
                        result = {'status': 2, 'message': msg}
                else:
                    if obj.id and obj1.id and obj2.id and obj3.id:
                        msg = message.add_successfully()
                        result = {'status': 1, 'message': msg}
                    else:
                        msg = message.add_error()
                        result = {'status': 2, 'message': msg}
            except Exception as e:
                print(str(e))
                empdata.add_error('arname',_('الموظف موجود مسبقاً'))              
                result = {'status': 0,
                      'error_empdata': empdata.errors.as_json(),
                      'error_form': form.errors.as_json(),
                      'error_form2': form2.errors.as_json(),
                      'error_form3': form3.errors.as_json(),
                    }
        else:
            print('HHHHHHHHHHHHHHH')
         
            result = {'status': 0,
                      'error_empdata': empdata.errors.as_json(),
                      'error_form': form.errors.as_json(),
                      'error_form2': form2.errors.as_json(),
                      'error_form3': form3.errors.as_json(),
                      }
        print(result)
        return JsonResponse(result)
class EmployeeDataJson(BaseDatatableView):
    """
    كلاس لعرض بيانات الموظفين
    """

    model = Emp_data
    columns = [
        'id',
        'arname',
        'enname',
        'EmployeePersonalData__social_status',
        'EmployeePersonalData__nationality',
        'EmployeePersonalData__religin',
        'EmployeePersonalData__language',
        'EmployeePersonalData__gender',
        'EmployeePersonalData__birthDate',
        'EmployeePersonalData__birthPlace',

        'EmployeeFunctionalDatas__organizational__name_ar',
        'EmployeeFunctionalDatas__qualifications__name',
        "action",
    ]
    order_columns = [
        'id',
        'arname',
        'enname',
        'EmployeePersonalData__social_status',
        'EmployeePersonalData__nationality',
        'EmployeePersonalData__religin',
        'EmployeePersonalData__language',
        'EmployeePersonalData__gender',
        'EmployeePersonalData__birthDate',
        'EmployeePersonalData__birthPlace',

        'EmployeeFunctionalDatas__organizational__name_ar',
        'EmployeeFunctionalDatas__qualifications__name',

        "action",
    ]

    def get_initial_queryset(self):

        return self.model.objects.select_related().filter(emp_status=True).values(
            'pk',
            'arname',
            'enname',
            'EmployeePersonalData__social_status',
            'EmployeePersonalData__nationality',
            'EmployeePersonalData__religin',
            'EmployeePersonalData__language',
            'EmployeePersonalData__gender',
            'EmployeePersonalData__birthDate',
            'EmployeePersonalData__birthPlace',

            'EmployeeFunctionalDatas__organizational__name_ar',
            'EmployeeFunctionalDatas__qualifications__name',
        )

    count = 0

    def render_column(self, row, column):
        """Render Column For Datatable
        """
        if column == "id":
            self.count += 1
            return self.count
        elif column == "action":
            action = ""
            action_edit = '<a class="edit_row" data-url="{2}" data-id="{0}" ' \
                          'style="DISPLAY: -webkit-inline-box;"  data-toggle="tooltip"' \
                          ' title="{1}"><i class="fa fa-edit"></i></a>'.format(row['pk'], _("Edit"),
                                                                               reverse("EmployeeDataView"))
            action_delete = '<a class="delete_row" data-url="{2}" data-id="{0}" ' \
                            'style="DISPLAY: -webkit-inline-box;"  data-toggle="tooltip"' \
                            ' title="{1}"><i class="fa fa-trash"></i></a>'.format(row['pk'], _("Delete"),
                                                                                  reverse("EmployeeDataView"))

            if self.request.user.has_perm('employeesmanagement.change_employeefunctionaldata'):
                action += action_edit
            if self.request.user.has_perm('employeesmanagement.delete_employeefunctionaldata'):
                action += action_delete
            return action
        elif column == 'EmployeePersonalData__gender':
            if row['EmployeePersonalData__gender'] == 'Female':
                return gender_[2][1]
            else:
                return gender_[1][1]
        elif column == 'EmployeePersonalData__social_status':

            return socialstatus_dict[row['EmployeePersonalData__social_status']]

        elif column == 'EmployeePersonalData__nationality':
            return NATIONALITIES_dict[row['EmployeePersonalData__nationality']]
        elif column == 'EmployeePersonalData__religin':
            return RELIGION_dict[row['EmployeePersonalData__religin']]
        elif column == 'EmployeePersonalData__language':
            return LANGUAGE_dict[row['EmployeePersonalData__language']]
        else:
            return super(EmployeeDataJson, self).render_column(row, column)

    def filter_queryset(self, qs):
        """To Filter data in table using in search
        """
        sSearch = self.request.GET.get("sSearch", None)
        if sSearch:
            qs = qs.filter(
                Q(arname__icontains=sSearch)
                | Q(enname__icontains=sSearch)
                | Q(EmployeePersonalData__social_status__icontains=sSearch)
                | Q(EmployeePersonalData__birthDate__icontains=sSearch)
                | Q(EmployeePersonalData__nationality__icontains=sSearch)
                | Q(id__icontains=sSearch)
            )
        return qs

def copy_report(request):
    """ 
    دالة تعمل على نسخ البيانات من الجداول 
    BaseReport
    ReporterField
    ReporterAppearanceParent
    ReporterAppearance
    AdvanceReporter
    HeaderFooter 
    الخاصة بالتقارير الديناميكية الى ملف
    fixtures/report_data.json  
    """
    output_filename = "fixtures/report_data.json"

    output = open(output_filename, "w")  # Point stdout at a file for dumping data to.
    management.call_command(
        "dumpdata",
        "reporters.BaseReport",
        "reporters.ReporterField",
        "reporters.ReporterAppearanceParent",
        "reporters.ReporterAppearance",
        "reporters.AdvanceReporter",
        "reporters.HeaderFooter",
        format="json", 
        indent=1,
        stdout=output,
    )
    output.close()

    return HttpResponse("successfully")

def load_report(request):
    """ 
    دالة تعمل باستعادة البيانات الموجودة في ملف
    fixtures/report_data.json
    الى قاعدة البيانات الجديدة
    """
    management.call_command(
        "loaddata", "fixtures/report_data.json",
    )

    return redirect('logout')
