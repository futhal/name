from django.conf import settings
from django.conf.urls.static import static
from django.urls import path

from employeesmanagement import views

urlpatterns = [
    path(
        '',
        views.index,
        name='index',
    ),
    path("copy_report", views.copy_report, name="copy_report"),
    path("load_report", views.load_report, name="load_report"),
    path(
        'EmployeeDataView/',
        views.EmployeeDataView.as_view(),
        name="EmployeeDataView",
    ),
    # path(
    #   'export_excel_data/',
    #   views.export_excel_data,
    #   name="export_excel_data",
    # ),
    path(
      'export_data/',
      views.export_data,
      name="export_data",
    ),
    

    path(
        'EmployeeDataJson/',
        views.EmployeeDataJson.as_view(),
        name="EmployeeDataJson",
    ),



    path(
        'JobTitleView/',
        views.JobTitleView.as_view(),
        name="JobTitleView",
    ),
    path(
        'JobTitleJson/',
        views.JobTitleJson.as_view(),
        name="JobTitleJson",
    ),
    path(
        'TypeOfDocumentView/',
        views.TypeOfDocumentView.as_view(),
        name="TypeOfDocumentView",
    ),
    path(
        'TypeOfDocumentJson/',
        views.TypeOfDocumentJson.as_view(),
        name="TypeOfDocumentJson",
    ),

    path(
        'TypeOfQualificationsView/',
        views.TypeOfQualificationsView.as_view(),
        name="TypeOfQualificationsView",
    ),
    path(
        'TypeOfQualificationsJson/',
        views.TypeOfQualificationsJson.as_view(),
        name="TypeOfQualificationsJson",
    ),

    path(
        'JobView/',
        views.JobView.as_view(),
        name="JobView",
    ),
    path(
        'JobJson/',
        views.JobJson.as_view(),
        name="JobJson",
    ),
    path(
        'TypeAllwanceView/',
        views.TypeAllwanceView.as_view(),
        name="TypeAllwanceView",
    ),
    path(
        'TypeAllwanceJson/',
        views.TypeAllwanceJson.as_view(),
        name="TypeAllwanceJson",
    ),
    path(
        'TypeDeducationView/',
        views.TypeDeducationView.as_view(),
        name="TypeDeducationView",
    ),
    path(
        'TypeDeducationJson/',
        views.TypeDeducationJson.as_view(),
        name="TypeDeducationJson",
    ),

    path(
        'employementApplication/',
        views.employementApplication,
        name="employementApplication",
    ),
    path(
        'FunctionalRequestTableListJso/',
        views.FunctionalRequestTableListJso,
        name="FunctionalRequestTableListJso",
    ),
    path(
        'edit_employement_application/<int:pk>',
        views.edit_employement_application,
        name="edit_employement_application",
    ),
    path(
        'get_functional_request/',
        views.get_functional_request,
        name="get_functional_request",
    ),

    path('organizational_chart_update_view/<int:nodeId>/',
         views.organizational_chart_update_view,
         name='organizational_chart_update_view',
         ),
    path(
        'MainOrganizationalChartListView/',
        views.MainOrganizationalChartListView.as_view(),
        name='MainOrganizationalChartListView',
    ),
    path(
        'OrganizationalChartCreateView/',
        views.OrganizationalChartCreateView.as_view(),
        name='OrganizationalChartCreateView',
    ),
    path(
        'OrganizationalChartListView/',
        views.OrganizationalChartListView.as_view(),
        name='OrganizationalChartListView',
    ),

    path(
        'OrganizationalChartDeleteView/',
        views.organizational_chart_delete,
        name='OrganizationalChartDeleteView',
    ),
    path(
        'add_data_company/',
        views.add_data_company,
        name="add_data_company",
    ),

    path(
        'TypeOfSpecialtiesView/',
        views.TypeOfSpecialtiesView.as_view(),
        name='TypeOfSpecialtiesView'
    ),
    path(
        'TypeOfSpecialtiesJson/',
        views.TypeOfSpecialtiesJson.as_view(),
        name='TypeOfSpecialtiesJson'
    ),

]
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
