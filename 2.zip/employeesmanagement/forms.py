import datetime

from django import forms
from django.utils.translation import ugettext_lazy as _

from . import models
from .models import Emp_data, CompanyData, OrganizationalChart, JobTitle, Job, TypeOfSpecialties, TypeOfDocument, \
    TypeOfQualifications, EmployeeContactData, EmployeeFunctionalData, EmployeePersonalData


class NewJobTitleForm(forms.ModelForm):
    """ 
    فورم للمسميات الوظيفية
    """
    def __init__(self, *args, **kwargs):
        super(NewJobTitleForm, self).__init__(*args, **kwargs)
        self.fields["name"].widget.attrs.update({
            'class': '  select form-control',
        })
        self.fields["Description"].widget.attrs.update({
            'class': 'select form-control',
        })

    class Meta:
        model = JobTitle
        fields = ['id', 'name', 'Description']


class NewJobForm(forms.ModelForm):
    """ 
    فورم  الوظائف
    """
    def __init__(self, *args, **kwargs):
        super(NewJobForm, self).__init__(*args, **kwargs)
        self.fields["name"].widget.attrs.update({
            'class': 'formset-field items_val select form-control',
        })
        self.fields["jobTitale"].widget.attrs.update({
            'class': 'formset-field items_val select form-control',
        })

    class Meta:
        model = Job
        fields = ['name', 'jobTitale']


class NewTypeSpecialties(forms.ModelForm):
    """ 
    فورم التخصصات
    """
    def __init__(self, *args, **kwargs):
        super(NewTypeSpecialties, self).__init__(*args, **kwargs)
        self.fields["name"].widget.attrs.update({
            'class': 'formset-field items_val select form-control',
        })
        self.fields["Description"].widget.attrs.update({
            'class': 'formset-field items_val select form-control',
        })

    class Meta:
        model = TypeOfSpecialties
        fields = ['name', 'Description']


class NewTypeOfDocument(forms.ModelForm):
    """ 
    فورم الوثائق
    """
    def __init__(self, *args, **kwargs):
        super(NewTypeOfDocument, self).__init__(*args, **kwargs)
        self.fields["name"].widget.attrs.update({
            'class': 'formset-field items_val select form-control',
        })
        self.fields["Description"].widget.attrs.update({
            'class': 'formset-field items_val select form-control',
        })

    class Meta:
        model = TypeOfDocument
        fields = ['name', 'Description']


class NewTypeOfQualification(forms.ModelForm):
    """ 
    فورم لانواع المؤهلات
    """
    def __init__(self, *args, **kwargs):
        super(NewTypeOfQualification, self).__init__(*args, **kwargs)
        self.fields["name"].widget.attrs.update({
            'class': 'formset-field items_val select form-control',
        })
        self.fields["Description"].widget.attrs.update({
            'class': 'formset-field items_val select form-control',
        })

    class Meta:
        model = TypeOfQualifications
        fields = ['name', 'Description']





class TypeAllwoanceform(forms.ModelForm):
    """ 
    فورم لانواع البدلات
    """
    def __init__(self, *args, **kwargs):
        super(TypeAllwoanceform, self).__init__(*args, **kwargs)
        self.fields['name'].widget.attrs.update({
            'class': 'formset-field items_val select form-control',
        })
        self.fields['allwance_type'].widget.attrs.update({
            'class': 'formset-field items_val select form-control',
        })
        self.fields['description'].widget.attrs.update({
            'class': 'formset-field items_val select form-control',
        })
        self.fields['description'].required = False

    class Meta:
        model = models.TypeAllwoance
        fields = ['name','allwance_type','description']


class Type_deducationform(forms.ModelForm):
    """ 
    فورم لانواع الاستقطاعات
    """
    def __init__(self, *args, **kwargs):
        super(Type_deducationform, self).__init__(*args, **kwargs)
        self.fields['name'].widget.attrs.update({
            'class': 'formset-field items_val select form-control',
        })
        self.fields['description'].widget.attrs.update({
            'class': 'formset-field items_val select form-control',
        })
        self.fields['description'].required = False

    class Meta:
        model = models.TypeDeduction
        fields = ['name', 'description']


class Emp_dataForm(forms.ModelForm):
    """ 
    فورم بيانات الموظف
    """
    def __init__(self, *args, **kwargs):
        super(Emp_dataForm, self).__init__(*args, **kwargs)
        # for name in self.fields.keys():
        #     self.fields[name].widget.attrs.update({
        #         'required':True,
        #     })
        self.fields['arname'].widget.attrs.update({
            'class': 'formset-field items_val select form-control',
            'required': True,
        })
        self.fields['enname'].widget.attrs.update({
            'class': 'formset-field items_val select form-control',
            'required': True,
        })
        self.fields['number_employ'].widget.attrs.update({
            'class': 'formset-field items_val select form-control',
        })
        self.fields['personal_image'].widget.attrs.update({
            'class': 'hidden',
        })

    class Meta:
        model = Emp_data
        # fields = ['arname', 'enname']
        fields = ['arname', 'enname', 'number_employ','personal_image']


class EmployeeFunDataForm(forms.ModelForm):
    """ 
    فورم البيانات الوظيفية الموظف
    """
    qualificationIssueDate = forms.DateField(
        widget=forms.DateInput(attrs={"type": 'date', 'value': datetime.date.today()}), label=_("Qualification Date"))
    accept_date = forms.DateField(
        widget=forms.DateInput(attrs={"type": 'date', 'value': datetime.date.today()}), label=_("Accept Date"))

    def __init__(self, *args, **kwargs):
        super(EmployeeFunDataForm, self).__init__(*args, **kwargs)
        for name in self.fields.keys():
            self.fields[name].widget.attrs.update({
                'class': 'formset-field items_val select form-control',
            })

        self.fields['organizational'].widget.attrs.update({
            'required': 'required',
            'class': 'formset-field items_val select form-control',
        })
        self.fields['qualifications'].widget.attrs.update({
            'class': 'formset-field items_val select form-control',
        })
        self.fields['job'].widget.attrs.update({
            'class': 'formset-field items_val select form-control',
        })
        self.fields['specialte'].widget.attrs.update({
            'class': 'formset-field items_val select form-control',
        })

    class Meta:
        model = EmployeeFunctionalData
        fields = ['qualifications', 'job', 'organizational', 'placequalification', 'specialte',
                  'placeIssueQualification', 'accept_date', 'qualificationIssueDate', 'serviceyears', 'ageretire',
                  'salary','supervisor']


class EmployeePersnlForm(forms.ModelForm):
    """ 
    فورم البيانات الشخصية الموظف
    """
    issueDate = forms.DateField(widget=forms.DateInput(attrs={"type": 'date', 'value': datetime.date.today()}),
                                label=_("Issue Date"))
    expireDate = forms.DateField(widget=forms.DateInput(attrs={"type": 'date', 'value': datetime.date.today()}),
                                 label=_("Expiry date"))
    birthDate = forms.DateField(widget=forms.DateInput(attrs={"type": 'date', 'value': datetime.date.today()}),
                                label=_("Birth Date"))

    def __init__(self, *args, **kwargs):
        super(EmployeePersnlForm, self).__init__(*args, **kwargs)

        for name in self.fields.keys():
            self.fields[name].widget.attrs.update({
                'class': 'formset-field items_val select form-control',
                'width': '44px',
            })
        # self.fields['social_status'].widget.attrs.update({
        #     'class': 'formset-field items_val select form-control',
        # })
        # self.fields['gender'].widget.attrs.update({
        #     'class': 'formset-field items_val select form-control',
        # })
        # self.fields['bloodtype'].widget.attrs.update({
        #     'class': 'formset-field items_val select form-control',
        # })
        # self.fields['nationality'].widget.attrs.update({
        #     'class': 'formset-field items_val select form-control',
        # })
        # self.fields['religin'].widget.attrs.update({
        #     'class': 'formset-field items_val select form-control',
        # })
        # self.fields['language'].widget.attrs.update({
        #     'class': 'formset-field items_val select form-control',
        # })

    class Meta:
        model = EmployeePersonalData
        fields = ['social_status', 'nationality', 'religin', 'gender', 'language', 'bloodtype', 'personalityType',
                  'personalityNumber', 'issueDate', 'expireDate', 'issuePlace', 'birthDate', 'birthPlace',
                  'arNamefornearPersonal', 'enNameFornearPersonal', 'telephoneforNearPesonal', 'phoneForNearPersonal',
                  'emailForNearPersonal', 'note']


class EmployeeContactForm(forms.ModelForm):
    """ 
    فورم البيانات اتصال الموظف
    """
    def __init__(self, *args, **kwargs):
        super(EmployeeContactForm, self).__init__(*args, **kwargs)

        for name in self.fields.keys():
            self.fields[name].widget.attrs.update({
                'class': 'formset-field items_val select form-control',
            })

    class Meta:
        model = EmployeeContactData
        fields = ['telephoneNumber', 'phoneNumber', 'faxnumber', 'inboxNumber', 'address', 'webaddress', 'email']


class EmployeeRequestLanguage(forms.ModelForm):
    """ 
    فورم اللغات التحدث الموظف
    """
    def __init__(self, *args, **kwargs):
        super(EmployeeRequestLanguage, self).__init__(*args, **kwargs)
        for name in self.fields.keys():
            self.fields[name].widget.attrs.update({

            })
        self.fields['write_degree'].widget.attrs.update({
            'class': 'formset-field items_val select form-control',
        })
        self.fields['read_degree'].widget.attrs.update({
            'class': 'formset-field items_val select form-control',
        })
        self.fields['speak_degree'].widget.attrs.update({
            'class': 'formset-field items_val select form-control',
        })
        self.fields['language_name'].widget.attrs.update({
            'class': ' select form-control',
        })

    class Meta:
        model = models.Language
        # fields = '__all__'
        fields = ['language_name', 'write_degree', 'read_degree', 'speak_degree']


class EmployeeRequestProgrammingLanguage(forms.ModelForm):
    """ 
    فورم اللغات البرمجية الموظف
    """
    def __init__(self, *args, **kwargs):
        super(EmployeeRequestProgrammingLanguage, self).__init__(*args, **kwargs)
        for name in self.fields.keys():
            self.fields[name].widget.attrs.update({

                'class': 'formset-field items_val select form-control',

            })

    class Meta:
        model = models.ProgrammingLanguage
        # fields = '__all__'
        fields = ['language_programming_name', 'programming_degree']


class EmployeeRequestEducation(forms.ModelForm):
    """ 
    فورم البيانات التعليمية للموظف
    """
    graduation_year = forms.DateField(widget=forms.DateInput(attrs={"type": 'date', 'value': datetime.date.today()}),
                                      label=_('Graduation Year'))

    def __init__(self, *args, **kwargs):
        super(EmployeeRequestEducation, self).__init__(*args, **kwargs)
        for name in self.fields.keys():
            self.fields[name].widget.attrs.update({
                'class': 'formset-field items_val select form-control',

            })
        self.fields['educational_phase'].widget.attrs.update({
            'class': 'formset-field items_val select form-control',
        })

    class Meta:
        model = models.Education
        fields = ['educational_phase', 'institution', 'faculy', 'major', 'appreciation', 'graduation_year']


class EmployeeRequestLastJob(forms.ModelForm):
    """ 
    فورم آخر وظيفة الموظف
    """
    start_date = forms.DateField(widget=forms.DateInput(attrs={"type": 'date', 'value': datetime.date.today()}),
                                 label=_('Start Date'))
    end_date = forms.DateField(widget=forms.DateInput(attrs={"type": 'date', 'value': datetime.date.today()}),
                               label=_('End Date'))

    def __init__(self, *args, **kwargs):
        super(EmployeeRequestLastJob, self).__init__(*args, **kwargs)
        for name in self.fields.keys():
            self.fields[name].widget.attrs.update({

                'class': 'formset-field items_val select form-control',

            })

    class Meta:
        model = models.Job_before
        exclude = ['employee']
        # fields = ['start_date','end_date','job_title_start']


class Employee_general_question(forms.ModelForm):
    """ 
    فورم أسئلة عامة 
    """
    def __init__(self, *args, **kwargs):
        super(Employee_general_question, self).__init__(*args, **kwargs)

        for name in self.fields.keys():
            self.fields[name].widget.attrs.update({

                'class': 'formset-field items_val select form-control',

            })

        self.fields['work_at_night'].widget.attrs.update({
            'rows': '3',
        })
        self.fields['leave_out'].widget.attrs.update({
            'rows': '3',
        })
        self.fields['travel_in'].widget.attrs.update({
            'rows': '3',
        })
        self.fields['Convted_of_crime'].widget.attrs.update({
            'rows': '3',
        })
        self.fields['suffers_health'].widget.attrs.update({
            'rows': '3',
        })
        self.fields['empld_currntly'].widget.attrs.update({
            'rows': '3',
        })
        self.fields['workd_for_ittech'].widget.attrs.update({
            'rows': '3',
        })
        self.fields['have_reltve_intech'].widget.attrs.update({
            'rows': '3',
        })
        self.fields['when_start_worked'].widget.attrs.update({
            'rows': '3',
        })
        self.fields['more_about_you'].widget.attrs.update({
            'rows': '3',
        })

    class Meta:
        model = models.General_question
        exclude = ['employee']


class OrganizationalChartForm(forms.ModelForm):
    """
    فورم الوحدات التنظيمية
    """
    def __init__(self, *args, **kwargs):
        super(OrganizationalChartForm, self).__init__(*args, **kwargs)
        for name in self.fields.keys():
            self.fields[name].widget.attrs.update({'class': 'form-control select'})
        self.fields['parent'].widget.attrs.update({
            'blank': True, 'null': True,
        })

    data = OrganizationalChart.objects.all()

    class Meta:
        model = OrganizationalChart
        exclude = ['id']
        labels = {
            'my_level': _('Number'),
            'phone': _('Responsible Person phone')}

class CompanyDataForm(forms.ModelForm):
    ''' 
    فورم بيانات الشركة 
    '''

    def __init__(self, *args, **kwargs):
        super(CompanyDataForm, self).__init__(*args, **kwargs)
        for name in self.fields.keys():
            self.fields[name].widget.attrs.update({
                'class': 'formset-field items_val select form-control',
            })
        # self.fields['company_logo'].widget.attrs.update(
        #     {
        #         'id': 'company_logo_id',
        #         'class':'hidden'

        #     })

    class Meta:
        model = CompanyData
        fields ="__all__"