from django.apps import AppConfig


class EmployeesmanagementConfig(AppConfig):
    name = 'employeesmanagement'
