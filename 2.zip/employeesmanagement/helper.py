import sys

from django.contrib import messages
from django.shortcuts import render, redirect, get_object_or_404
from django.utils.translation import ugettext_lazy as _

# from logs.log import loggingrecord


"""Function Helper To show and Edit And Add And Delete from Any modle  Model """


def display_view(request, model_name, form_name, templet_name, title):
    """Base Function To Show and  Add New  Record Of Any Model
    Arguments:
        request {request} 
        model_name {model} -- Model for get data
        form_name {Form} -- form to add datt
        templet_name {html} -- to display data
        title {str} -- title for show in Tamplat
    
    Returns:
        [redirect] -- redirect to next page
    """
    if request.method == "POST":
        form = form_name(request.POST, request.FILES)
        if form.is_valid():
            obj = form.save(commit=False)
            obj.created_by = request.user
            #    loggingrecord(request)
            obj.save()
            if obj.pk:
                messages.success(request, _('Added Successfully '))
                return redirect(request.get_full_path())
            else:
                messages.error(request, _('Error adding process'))
    else:
        form = form_name()
    context = {
        'form': form,
        #   'jobtital':reverse(str(model_name.__name__).lower()+'_list'),
        'title': _(title),
    }
    return render(request, templet_name, context)


def edit_view(request, model_name, form_name, templet_name, title, pk):
    """Base Function To Edit Any Record
    Arguments:
        request {request} 
        model_name {model} -- Model for get data
        form_name {Form} -- form to add data
        templet_name {html} -- to display data
        title {str} -- title for show in Templat
    
    Returns:
        [redirect] -- redirect to next page
    """
    if request.method == "POST":
        data = get_object_or_404(model_name, pk=pk)
        form = form_name(request.POST, request.FILES, instance=data)
        if form.is_valid():
            obj = form.save(commit=False)
            obj.modified_by = request.user
            # loggingrecord(request)
            obj.save()

            if obj.pk:
                messages.success(request, _('Edit Successfully '))
                # return redirect(str(model_name.__name__).lower()+'_list')
                return redirect(request.get_full_path())
            else:
                messages.error(request, _('Error Edit Process'))
    else:
        data = get_object_or_404(model_name, pk=pk)
        # data=model_name.objects.get(pk=pk)
        form = form_name(instance=data)
    context = {
        'form': form,
        #  'action':reverse(str(model_name.__name__).lower()+'_edit',args=[pk]),
        'title': _(title),
    }
    return render(request, templet_name, context)


def delete_view(request, model_name, pk, *kwargs):
    """Base Function For Delete From Any Model 
    Arguments:
        request {request} 
        model_name {model} -- Model for get data
        pk {int} -- primary key for delete data
    Returns:
        [redirect] -- redirect to next page
    """
    #  loggingrecord(request)
    for m in kwargs:
        mode = getattr(sys.modules[__name__], m['model'])
        my_filter = {}
        my_filter[m['cloumn']] = pk
        if mode.objects.filter(**my_filter).count() > 0:
            messages.error(request, _('Error Delete Process This Record Assign Width Anther Record In'))
            return redirect(str(model_name.__name__).lower() + '_list')
    data = get_object_or_404(model_name, pk=pk)
    if data.delete():
        messages.success(request, _('Deleted Successfully '))
    else:
        messages.error(request, _('Error Delete Process'))
    return redirect(str(model_name.__name__).lower() + '_list')
