from django.db import models

class RemovedFilter(models.Manager):
    def get_queryset(self):
        try:
            return (
                super().get_queryset().filter(employee__removed=False)
            )
        except:
            try:
                return super().get_queryset().filter(removed=False)
            except:
                pass
        return super().get_queryset()


class RemovedFilterApplicant(models.Manager):
    def get_queryset(self):
        try:
            return (
                super().get_queryset().filter(applicant__removed=False,employee__removed=False)
            )
        except:
            pass
        return super().get_queryset()


class WithoutFilter(models.Manager):
    """
    كلاس يساعد في عملية التحكم بالبيانات التي نستعلم عنها من جدول
    Emp_dsts 
    واي جدول مرتبط به
    [objects] -- [يعيد البيانات الذي الموظفين غير محذوفين ]
    [bobjects] -- [يعيد البيانات كل الموظفين]
    """
    def get_queryset(self):
        return super().get_queryset()


class BaseModelF(models.Model):
    objects = RemovedFilter()
    bobjects = WithoutFilter()
    class Meta:
        abstract = True


class BaseModelA(models.Model):
    objects = RemovedFilterApplicant()
    bobjects = WithoutFilter()
    class Meta:
        abstract = True