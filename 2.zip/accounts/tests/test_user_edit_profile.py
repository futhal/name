from .models import User
from django.test import TestCase
from django.urls import resolve, reverse

from accounts.forms.forms import usersFormEdit
from accounts.views import users_edit


class UserInfoEditTest(TestCase):
    def setUp(self):
        username = 'abdooh'
        password = 'secret123'
        self.user = User.objects.create_user(
            username=username, password=password)
        url = reverse('users_edit', kwargs={
            'pk': self.user.pk,
        })
        # self.client.login(username=username, password=password)
        self.response = self.client.get(url)

    def test_status_code(self):
        self.assertEquals(self.response.status_code, 200)

    def test_url_resolves_correct_view(self):
        view = resolve('/users/edit/1')
        self.assertEquals(view.func, users_edit)

    def test_csrf(self):
        self.assertContains(self.response, 'csrfmiddlewaretoken')

    def test_contains_form(self):
        form = self.response.context.get('form')
        self.assertIsInstance(form, usersFormEdit)

    def test_form_inputs(self):
        '''
        The view must contain four inputs: csrf, Firstname ,Lastname,Superuser ,Staff ,ActiveGroups,
        '''
        self.assertContains(self.response, '<input', 7)
        self.assertContains(self.response, 'type="checkbox"', 3)


class UserInfodChangeTestCase(TestCase):
    '''
    Base test case for form processing
    accepts a `data` dict to POST to the view.
    '''

    def setUp(self, data={}):
        self.user = User.objects.create_user(username='abood2', email='fuad@ittech.com', password='old_password')
        self.url = reverse('users_edit', kwargs={'pk': self.user.pk})
        # self.client.login(username='fuad', password='old_password')
        self.response = self.client.post(self.url, data)


class SuccessfulUserInfoChangeTests(UserInfodChangeTestCase):
    def setUp(self):
        super().setUp({
            'username': 'username',
        })

    def test_redirection(self):
        '''
        A valid form submission should redirect the user
        '''
        self.assertRedirects(self.response, reverse('users'))

    def test_userInfo_changed(self):
        '''
        refresh the user instance from database to get the new username
        hash updated by the change username view.
        '''
        self.user.refresh_from_db()
        self.assertEqual(self.user.username, 'username')


class InvalidUserInfoChangeTests(UserInfodChangeTestCase):

    def test_status_code(self):
        '''
        An invalid form submission should return to the same page
        '''
        self.assertEquals(self.response.status_code, 200)

    def test_form_errors(self):
        form = self.response.context.get('form')
        self.assertFalse(form.is_valid())
