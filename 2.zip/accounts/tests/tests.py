# # Create your tests here.
#  def test_redirect_if_not_logged_in(self):
#         response = self.client.get(reverse('renew-book-librarian', kwargs={'pk': self.test_bookinstance1.pk}))
#         # Manually check redirect (Can't use assertRedirect, because the redirect URL is unpredictable)
#         self.assertEqual(response.status_code, 302)
#         self.assertTrue(response.url.startswith('/accounts/login/'))

#     def test_redirect_if_logged_in_but_not_correct_permission(self):
#         login = self.client.login(username='testuser1', password='1X<ISRUkw+tuK')
#         response = self.client.get(reverse('renew-book-librarian', kwargs={'pk': self.test_bookinstance1.pk}))
#         self.assertEqual(response.status_code, 403)
