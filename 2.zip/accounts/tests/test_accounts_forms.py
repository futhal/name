from django.test import TestCase

from accounts.forms.forms import GroupForm, LoginForm, usersForm, usersFormPassword, usersFormEdit, usersFormGroupEdit


class accountsFormTest(TestCase):

    def test_login_form_has_fields(self):
        form = LoginForm()
        expected = ['username', 'password']
        actual = list(form.fields)
        self.assertSequenceEqual(expected, actual)

    def test_group_form_has_fields(self):
        form = GroupForm()
        expected = ['name']
        actual = list(form.fields)
        self.assertSequenceEqual(expected, actual)

    def test_group_edit_form_has_fields(self):
        form = GroupForm()
        expected = ['name']
        actual = list(form.fields)
        self.assertSequenceEqual(expected, actual)

    def test_users_form_has_fields(self):
        form = usersForm()
        expected = ['username', 'email', 'password', 'confirm_password', 'first_name', 'last_name', 'is_superuser',
                    'is_staff', 'is_active', 'groups']
        actual = list(form.fields)
        self.assertSequenceEqual(expected, actual)

    def test_users_edit_form_has_fields(self):
        form = usersFormEdit()
        expected = ['username', 'first_name', 'last_name', 'is_superuser', 'is_staff', 'is_active', 'groups']
        actual = list(form.fields)
        self.assertSequenceEqual(expected, actual)

    def test_users_edit_password_form_has_fields(self):
        form = usersFormPassword()
        expected = ['password', 'confirm_password']
        actual = list(form.fields)
        self.assertSequenceEqual(expected, actual)

    def test_users_edit_group_form_has_fields(self):
        form = usersFormGroupEdit()
        expected = ['groups']
        actual = list(form.fields)
        self.assertSequenceEqual(expected, actual)
