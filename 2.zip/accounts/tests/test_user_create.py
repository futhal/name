from .models import User
from django.test import TestCase
from django.urls import resolve, reverse

from accounts.forms.forms import usersForm
from accounts.views import users


class usersTests(TestCase):
    def setUp(self):
        url = reverse('users')
        self.response = self.client.get(url)

    def test_users_status_code(self):
        self.assertEquals(self.response.status_code, 200)

    def test_users_url_resolves_users_view(self):
        view = resolve('/users')
        self.assertEquals(view.func, users)

    def test_csrf(self):
        self.assertContains(self.response, 'csrfmiddlewaretoken')

    def test_contains_form(self):
        form = self.response.context.get('form')
        self.assertIsInstance(form, usersForm)


class SuccessfulusersTests(TestCase):
    def setUp(self):
        url = reverse('users')
        data = {
            'username': 'abood',
            'email': 'abood@ittech.com',
            'password': '!@#123ww',
            'confirm_password': '!@#123ww'
        }
        self.response = self.client.post(url, data)
        self.home_url = reverse('users')

    def test_redirection(self):
        '''
        A valid form submission should redirect the user to the home page
        '''
        self.assertRedirects(self.response, self.home_url)

    def test_user_creation(self):
        self.assertTrue(User.objects.exists())


class InvalidusersTests(TestCase):
    def setUp(self):
        url = reverse('users')
        self.response = self.client.post(url, {})  # submit an empty dictionary

    def test_users_status_code(self):
        '''
        An invalid form submission should return to the same page
        '''
        self.assertEquals(self.response.status_code, 200)

    def test_form_errors(self):
        form = self.response.context.get('form')
        self.assertFalse(form.errors)

    def test_dont_create_user(self):
        self.assertFalse(User.objects.exists())
