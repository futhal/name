from django.contrib.auth.models import Group
from django.test import TestCase
from django.urls import resolve, reverse

from accounts.forms.forms import GroupForm
from accounts.views import roles


class GroupTests(TestCase):
    def setUp(self):
        url = reverse('roles')
        self.username = 'username'
        self.password = 'password'
        self.user = User.objects.create(username=self.username)
        self.user.set_password(self.password)
        self.user.save()
        self.client.force_login(self.user)

        self.response = self.client.get(url)

    def test_Group_status_code(self):
        self.assertEquals(self.response.status_code, 200)

    def test_Group_url_resolvesGroup_view(self):
        view = resolve('/roles/')
        self.assertEquals(view.func, roles)

    def test_csrf(self):
        self.assertContains(self.response, 'csrfmiddlewaretoken')

    def test_contains_form(self):
        form = self.response.context.get('form')
        self.assertIsInstance(form, GroupForm)


class SuccessfulGroupTests(TestCase):
    def setUp(self):
        url = reverse('roles')
        data = {
            'name': 'G1',

        }
        self.response = self.client.post(url, data)
        self.home_url = reverse('roles')

    def test_redirection(self):
        '''
        A valid form submission should redirect the user to the home page
        '''
        self.assertRedirects(self.response, self.home_url)

    def test_user_creation(self):
        self.assertTrue(Group.objects.exists())


class InvalidusersTests(TestCase):
    def setUp(self):
        self.url = reverse('roles')
        self.response = self.client.post(self.url, {})  # submit an empty dictionary

    def test_Group_status_code(self):
        '''
        An invalid form submission should return to the same page
        '''
        self.assertEquals(self.response.status_code, 200)

    def test_form_errors(self):
        form = self.response.context.get('form')
        self.assertFalse(form.is_valid())

    def test_dont_create_user(self):
        self.assertFalse(Group.objects.exists())
