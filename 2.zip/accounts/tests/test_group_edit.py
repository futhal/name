from django.contrib.auth.models import Group
from django.test import TestCase
from django.urls import resolve, reverse

from accounts.forms.forms import GroupForm
from accounts.views import roles_edit


class GroupUpdateViewTestCase(TestCase):
    '''
    Base test case to be used in all `gorup_edit` view tests
    '''

    def setUp(self):
        self.group = Group.objects.create(name='ITTech')
        self.url = reverse('rolesEdit', kwargs={
            'pk': self.group.pk
        })
        self.username = 'username'
        self.password = 'password'
        self.user = User.objects.create(username=self.username)
        self.user.set_password(self.password)
        self.user.save()
        self.client.force_login(self.user)


class UnauthorizedGroupUpdateViewTests(GroupUpdateViewTestCase):
    def setUp(self):
        '''
        Create a new user different from the one who Grouped
        '''
        super().setUp()
        # username = 'fuad-ittech'
        # password = '321'
        # user = User.objects.create_user(username=username, email='fuad@ittech.com', password=password)
        # self.client.login(username=username, password=password)
        self.response = self.client.get(self.url)


class GroupUpdateViewTests(GroupUpdateViewTestCase):
    def setUp(self):
        super().setUp()
        # self.client.login(username=self.username, password=self.password)
        self.response = self.client.get(self.url)

    def test_status_code(self):
        self.assertEquals(self.response.status_code, 200)

    def test_view_class(self):
        view = resolve('/roles/edit/1')
        self.assertEquals(view.func, roles_edit)

    def test_csrf(self):
        self.assertContains(self.response, 'csrfmiddlewaretoken')

    def test_contains_form(self):
        form = self.response.context.get('form')
        self.assertIsInstance(form, GroupForm)

    def test_form_inputs(self):
        '''
        The view must contain two inputs: csrf, name 
        '''
        self.assertContains(self.response, '<input', 2)


class SuccessfulGroupUpdateViewTests(GroupUpdateViewTestCase):
    def setUp(self, data={'name': 'GE2'}):
        super().setUp()
        # self.client.login(username=self.username, password=self.password)
        # self.response = self.client.post(self.url, {'message': 'edited message'})

        self.response = self.client.post(self.url, data)

    def test_redirection(self):
        '''
        A valid form submission should redirect the user
        '''
        self.assertRedirects(self.response, reverse('roles'))

    def test_userInfo_changed(self):
        '''
        refresh the user instance from database to get the new username
        hash updated by the change username view.
        '''
        self.group.refresh_from_db()
        self.assertEqual(self.group.name, 'GE2')


class InvalidGroupUpdateViewTests(GroupUpdateViewTestCase):
    def setUp(self):
        '''
        Submit an empty dictionary to the `reply_topic` view
        '''
        super().setUp()
        # self.client.login(username=self.username, password=self.password)
        self.response = self.client.get(self.url, {})

    def test_status_code(self):
        '''
        An invalid form submission should return to the same page
        '''
        self.assertEquals(self.response.status_code, 200)

    def test_form_errors(self):
        form = self.response.context.get('form')
        self.assertFalse(form.is_valid())
