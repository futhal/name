from .models import User
from django.test import TestCase
from django.urls import resolve, reverse

from accounts.forms.forms import usersFormPassword
from accounts.views import users_edit_password


class UserPasswordEditTest(TestCase):
    def setUp(self):
        username = 'abood'
        password = 'secret123'
        self.user = User.objects.create_user(username=username, password=password)
        url = reverse('users_edit_password', kwargs={
            'pk': self.user.pk,
        })

        self.client.login(username=username, password=password)
        self.response = self.client.get(url)

    def test_status_code(self):
        self.assertEquals(self.response.status_code, 200)

    def test_url_resolves_correct_view(self):
        view = resolve('/users_edit_password/1', )
        self.assertEquals(view.func, users_edit_password)

    def test_csrf(self):
        self.assertContains(self.response, 'csrfmiddlewaretoken')

    def test_contains_form(self):
        form = self.response.context.get('form')
        self.assertIsInstance(form, usersFormPassword)

    def test_form_inputs(self):
        '''
        The view must contain four inputs: csrf, old_password, new_password1, new_password2
        '''
        self.assertContains(self.response, '<input', 3)
        self.assertContains(self.response, 'type="password"', 2)


# class LoginRequiredPasswordChangeTests(TestCase):
#     def test_redirection(self):
#         url = reverse('users_edit_password')
#         login_url = reverse('login')
#         response = self.client.get(url)
#         self.assertRedirects(response, f'{login_url}?next={url}')


class PasswordChangeTestCase(TestCase):
    '''
    Base test case for form processing
    accepts a `data` dict to POST to the view.
    '''

    def setUp(self, data={}):
        self.user = User.objects.create_user(username='abood', email='fuad@ittech.com', password='old_password')
        self.url = reverse('users_edit_password', kwargs={'pk': self.user.pk})
        self.client.login(username='abood', password='old_password')
        self.response = self.client.post(self.url, data)


class SuccessfulPasswordChangeTests(PasswordChangeTestCase):
    def setUp(self):
        super().setUp({
            'password': 'new_password',
            'confirm_password': 'new_password',
        })

    def test_redirection(self):
        '''
        A valid form submission should redirect the user
        '''
        self.assertRedirects(self.response, reverse('users'))

    def test_password_changed(self):
        '''
        refresh the user instance from database to get the new password
        hash updated by the change password view.
        '''
        self.user.refresh_from_db()
        self.assertTrue(self.user.check_password('new_password'))


class InvalidPasswordChangeTests(PasswordChangeTestCase):
    def test_status_code(self):
        '''
        An invalid form submission should return to the same page
        '''
        self.assertEquals(self.response.status_code, 200)

    def test_form_errors(self):
        form = self.response.context.get('form')
        self.assertFalse(form.is_valid())

    def test_didnt_change_password(self):
        '''
        refresh the user instance from the database to make
        sure we have the latest data.
        '''
        self.user.refresh_from_db()
        self.assertTrue(self.user.check_password('old_password'))
