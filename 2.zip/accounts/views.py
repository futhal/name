from django.conf import settings
from django.contrib import messages
from django.contrib.auth import authenticate, login as login_user, logout as logout_user
from django.contrib.auth.decorators import login_required, permission_required
from django.contrib.auth.hashers import make_password
from django.contrib.auth.models import Group, ContentType, Permission#  , User
from .models import User
from django.db.models import ProtectedError
from django.http import HttpResponseRedirect
from django.shortcuts import render, reverse, redirect, get_object_or_404
from django.utils.translation import ugettext_lazy as _
from employeesmanagement.models import  Emp_data
from accounts.forms.forms import GroupForm, LoginForm, usersForm, usersFormPassword, usersFormEdit, usersFormGroupEdit

from employeesmanagement.models import CompanyData

def login(request):
    """
    دالة تسجيل الدخول  تستقبل  اسم المستخدم و كلمة       
    وتحول المستخدم الى الصفحة الرئيسية للنظام في حال النجاح
    """

    if request.user.is_authenticated:
        return redirect(settings.LOGIN_REDIRECT_URL)
    if request.method == 'POST':
        form = LoginForm(request.POST or None)
        if form.is_valid():
            username = request.POST['username']
            password = request.POST['password']
            user = authenticate(request, username=username, password=password)
            if user is not None:
                login_user(request, user)
                queryset = CompanyData.objects.all()
                if not queryset:
                    return redirect('add_data_company')
                try:
                    obj = CompanyData.objects.first()
                    from reporters.reporter_query_manger import set_defualt
                    set_defualt(request.user.id, obj.id)
                    # request.session["company_id"] = obj.id
                except:
                    pass
               

                return redirect(settings.LOGIN_REDIRECT_URL)
            else:
                messages.error(request, _('Error in username or password, please try again'))
                return redirect(settings.LOGOUT_REDIRECT_URL)
        else:
            data = {'form': form}
            return render(request, 'login.html', data)
    else:
        form = LoginForm()
        data = {'form': form}
        return render(request, 'login.html', data)


def logout(request):
    """
    دالة تسجيل الخروج
    """
    # loggingrecord(request)
    if request.user.is_authenticated:
        logout_user(request)
        return redirect(settings.LOGIN_REDIRECT_URL)
    else:
        return redirect(settings.LOGOUT_REDIRECT_URL)
@login_required(login_url='login')
def roles(request):
    """
    دالة انشاء مجموعة صلاحيات 
    """
    # request.session["open_menu"] = {"User_management": "menu-open"}
    # request.session["top_menu"] = {"User_management": "active"}
    # request.session["sub_menu"] = {"Role": "active"}
    if not request.user.has_perm('auth.add_group') and not request.user.has_perm(
            'auth.change_group') and not request.user.has_perm(
        'auth.delete_group') and not request.user.has_perm(
        'auth.view_group'):
        return render(request, "error/403.html", {})
    data = Group.objects.all()[:10]
    form = GroupForm()

    if request.method == "POST":
        form = GroupForm(request.POST or None)
        if form.is_valid():
            obj = form.save(commit=False)
            obj.created_by = request.user
            obj.save()
            messages.success(request, _('Added successfully '))
            return redirect(request.get_full_path())

    context = {
        'form': form,
        'data': data,
        'type_title': _('Add New'),
    }


    return render(request, 'accounts/roles.html',context)


@login_required(login_url='login')
@permission_required('auth.change_group', raise_exception=True)
def roles_edit(request, pk):
    """ 
    دالة تعديل مجموعة  صلاحيات 
   تستقبل رقم المجموعة 
    """
    # request.session["open_menu"] = {"User_management": "menu-open"}
    # request.session["top_menu"] = {"User_management": "active"}
    # request.session["sub_menu"] = {"Role": "active"}   
    group = get_object_or_404(Group, pk=pk)
    data = Group.objects.all()
    form = GroupForm(request.POST or None, instance=group)
    if request.method == 'POST':
        if form.is_valid():
            form.save()
            messages.success(request, _("Edited successfully"))
            return HttpResponseRedirect(reverse('roles'))

    context = {'form': form, 'data': data, 'type_title': _('Edit')}
    return render(request, 'accounts/roles.html', context)


@login_required(login_url='login')
@permission_required('auth.delete_group', raise_exception=True)
def delete_role(request, pk):
    """
    دالة حذف مجموعة صلاحيات 
    """
    # request.session["open_menu"] = {"User_management": "menu-open"}
    # request.session["top_menu"] = {"User_management": "active"}
    # request.session["sub_menu"] = {"Role": "active"}
    obj = Group.objects.filter(id=pk)
    if obj[0].delete_group_permissions() != False:
        obj[0].delete()
        messages.success(request, _("Deleted successfully"))
    else:
        messages.error(request, _("you cant delete this role becouse it join with employee successfully"))

    return HttpResponseRedirect(reverse('roles'))


@login_required(login_url='login')
@permission_required('auth.add_permission', raise_exception=True)
def group_premission(request, pk):
    """ 
    دالة اظافة الصلاحيات الى مجموعة الصلاحية
   تستقبل متغير  رقم المجموعة 
    """
    # request.session["open_menu"] = {"User_management": "menu-open"}
    # request.session["top_menu"] = {"User_management": "active"}
    # request.session["sub_menu"] = {"Role": "active"}
    group = get_object_or_404(Group, pk=pk)
    group_premission_ids = group.permissions.all().values_list('id', flat=True)
    data_premission = Permission.objects.all()
    model_premission = ContentType.objects.exclude(model__in=['logentry',
                                                              'manualattendeedetails',
                                                              'job_before',
                                                              'general_question',
                                                              'contenttype', 'session',
                                                              'calculateatendanceandleavedetails',
                                                              'workingpolicydetails',                                                              
                                                              'workperioddetail',
                                                              'education',
                                                              'language',
                                                              'general_vacation',
                                                              'administrativeperiodsdetiles',
                                                              'programminglanguage',
                                                              'attendance',
                                                              'footprintitems',
                                                              'employeecontactdata',
                                                              'languagetranslation',
                                                              'emp_data',
                                                              'discountemployeeadvance',
                                                              'basereport',
                                                              'reporterfield',
                                                              'reporterappearanceparent',
                                                              'reporterappearance',
                                                              'advancereporter',
                                                              'headerfooter',
                                                              'userwithfingerprint',

                                                              ])
    if request.method == 'POST':
        if 'premission' not in request.POST.keys():
            group.permissions.clear()
            messages.success(request, _("Edited successfully"))
            return HttpResponseRedirect(reverse('roles'))
        else:

            group.permissions.set(dict(request.POST)["premission"])
            messages.success(request, _("Edited successfully"))
            return HttpResponseRedirect(reverse('roles'))
    context = {
        'group': group,
        'group_premission_ids': group_premission_ids,
        'data_premission': data_premission,
        'model_premission': model_premission,
        'lst_trans': {'0': _("add"), '1': _('change'), '2': _('delete'), '3': _('view')}
    }
    return render(request, 'accounts/groupPremission.html', context)


@login_required(login_url='login')
@permission_required('auth.add_user', raise_exception=True)
def users(request):
    """
    دالة اظافة مستخدم
    """
   
    data = User.objects.all().order_by('-id')
    print(data.count())
    # user=Emp_data.objects.all().values_list('arname','arname')
    # form = usersForm(user= user)/
    form = usersForm()

    if request.method == "POST":
        # form = usersForm(request.POST,user= user)
        form = usersForm(request.POST)
        if form.is_valid():
            obj = form.save(commit=False)
           
            obj.is_staff = True
            obj.password = make_password(request.POST['password'])
            obj.save()
            if 'groups' in request.POST.keys():
                obj.groups.set(dict(request.POST)['groups'])
            messages.success(request, _("Added successfully"))
            return HttpResponseRedirect(reverse('users'))

    context = {
        'form': form,
        'type_title': _('Add new user'),
        'data': data,
        'title': _('Title'),
    }
    return render(request, 'accounts/users.html', context)


@login_required(login_url='login')
@permission_required('auth.change_user', raise_exception=True)
def users_edit_password(request, pk):
    """ 
    دالة تعديل كلمة المرور تستقبل رقم المستخدم

    """
    # request.session["open_menu"] = {"User_management": "menu-open"}
    # request.session["top_menu"] = {"User_management": "active"}
    # request.session["sub_menu"] = {"Users_list": "active"}
    user_data = get_object_or_404(User, pk=pk)
    data = User.objects.all()
    # user=Emp_data.objects.all().values_list('arname','arname').filter(arname=user_data.username)
    # form = usersFormPassword(request.POST or None,user=user,instance=user_data)
    form = usersFormPassword(request.POST or None,instance=user_data)#,instance=user_data)
    if request.method == 'POST':
        if form.is_valid():
            obj = form.save(commit=False)
            obj.password = make_password(request.POST['password'])
            obj.save()

            messages.success(request, _("Edited successfully"))
            return HttpResponseRedirect(reverse('users'))

    context = {'form': form, 'data': data, 'type_title': _('Change user password'),
               }
    return render(request, 'accounts/users.html', context)


@login_required(login_url='login')
@permission_required('auth.change_user', raise_exception=True)
def users_edit(request, pk):
    """ 
    دالة تعديل بيانات المستخدم
    """
    # request.session["open_menu"] = {"User_management": "menu-open"}
    # request.session["top_menu"] = {"User_management": "active"}
    # request.session["sub_menu"] = {"Users_list": "active"}

    user_data = get_object_or_404(User, pk=pk)
    data = User.objects.all()
    # user=Emp_data.objects.all().values_list('arname','arname').filter(arname=user_data.username)

    # form = usersFormEdit(request.POST or None,user=user,instance=user_data)
    form = usersFormEdit(request.POST or None,instance = user_data)#,instance=user_data)
    if request.method == 'POST':
        if form.is_valid():
            obj = form.save(commit=False)
            obj.save()
            messages.success(request, _("Edited successfully"))
            return HttpResponseRedirect(reverse('users'))

    context = {'form': form, 'data': data, 'type_title': _('Edit user info '),
               }
    return render(request, 'accounts/users.html', context)


@login_required(login_url='login')
@permission_required('auth.change_user', raise_exception=True)
def users_edit_group(request, pk):
    """
    دالة نعديل مجموعة صلاحيات المستخدم
    """
    # request.session["open_menu"] = {"User_management": "menu-open"}
    # request.session["top_menu"] = {"User_management": "active"}
    # request.session["sub_menu"] = {"Users_list": "active"}

   
    user_data = get_object_or_404(User, pk=pk)
    data = User.objects.all()
    # user=Emp_data.objects.all().values_list('arname','arname').filter(arname=user_data.username)
    # form = usersFormGroupEdit(request.POST or None,user=user,instance=user_data)
    form = usersFormGroupEdit(request.POST or None,instance=user_data)

    if request.method == 'POST':
        if form.is_valid():
            obj = form.save(commit=False)
            if 'groups' in request.POST.keys():
                obj.groups.set(dict(request.POST)['groups'])
            else:
                obj.groups.clear()
            obj.save()

            messages.success(request, _("Edited successfully"))
            return HttpResponseRedirect(reverse('users'))

    context = {'form': form, 'data': data, 'type_title': _('Edit user group permissions'),
               }
    return render(request, 'accounts/users.html', context)


@login_required(login_url='login')
@permission_required('auth.delete_user', raise_exception=True)
def delete_user(request, pk):
    """
    دالة حذف المستخدم تستقبل رقم المستخدم
    """
    # request.session["open_menu"] = {"User_management": "menu-open"}
    # request.session["top_menu"] = {"User_management": "active"}
    # request.session["sub_menu"] = {"Users_list": "active"}
    try:
        if User.objects.filter(id=pk).exists():
            User.objects.filter(id=pk).delete()
            messages.success(request, _("Deleted successfully"))

            return HttpResponseRedirect(reverse('users'))
    except ProtectedError:
        messages.success(request, _("Error delete Process"))
        return HttpResponseRedirect(reverse('users'))
