from django import forms
from django.contrib.auth.models import Group
from django.utils.translation import ugettext_lazy as _

# from django.contrib.auth.models import User
# from employeesmanagement.models import Emp_data
from accounts.models import User
# from django.core.validators import validate_username


class MyForm(forms.Form):
    def __init__(self, *args, **kwargs):
        super(MyForm, self).__init__(*args, **kwargs)
        for k, field in self.fields.items():
            if 'required' in field.error_messages:
                field.error_messages['required'] = _('This field is required')

            if 'null' in field.error_messages:
                field.error_messages['null'] = _('This input can\'t be null .')

            if 'blank' in field.error_messages:
                field.error_messages['blank'] = _(' This input can\'t be blank .')

            if 'invalid' in field.error_messages:
                field.error_messages['invalid'] = _(' This value is invalid .')

            if 'invalid_choice' in field.error_messages:
                field.error_messages['invalid_choice'] = _(' This invalid choice .')

            if 'unique' in field.error_messages:
                field.error_messages['unique'] = _('This value must be unique.')

            # if 'unique_for_date' in field.error_messages:
            #     field.error_messages['unique_for_date'] = _('You have to field this.')


class GroupForm(MyForm, forms.ModelForm):
    """
    فورم لمجموعات الصلاحيات
    """
    class Meta:
        model = Group
        fields = ["name"]
        labels = {
            'name': _('Role name'),
        }


class LoginForm(MyForm):
    """
    فورم لتسجيل الدخول
    """
    username = forms.CharField(
        label=_("username"),
        max_length=200,
        widget=forms.TextInput(attrs={"placeholder": _("User Name"), "class": "textinput textInput form-control"}),
    )
    password = forms.CharField(
        label=_("password"),
        max_length=200,
        widget=forms.PasswordInput(attrs={"placeholder": _("Password"), "class": "textinput textInput form-control"}),
    )


class usersForm(MyForm, forms.ModelForm):
    """
    فورم للمستخدمين
    
    """

    def __init__(self, *args, **kwargs):
        super(usersForm, self).__init__(*args, **kwargs)
        if 'employee' in self.fields :           

            self.fields['employee'].widget.attrs.update({
                'required':'True',

            })

    password = forms.CharField(

        label=_("Password"),
        max_length=200,
        widget=forms.PasswordInput(attrs={"placeholder": _("Password")}),
    )

    confirm_password = forms.CharField(
        label=_("Confirm Password1"),
        max_length=200,
        widget=forms.PasswordInput(attrs={"placeholder": _("Confirm Password")}),
    )
    

    class Meta:
        model = User
        labels = {
            "username": _("User name"),
            "email": _("Email"),           
            "is_superuser": _("Is superuser"),
            "is_active": _("Is active"),
            "groups": _("Groups"),
            "employee":_('Employee')

        }
        fields = [          
            "username",
            "email",
            "password",
            "confirm_password",
            "is_superuser",
            "is_active",
            "groups",
            "employee",

        ]

    def clean_password(self):
        if len(self.cleaned_data["password"]) < 1:
            raise forms.ValidationError(_("Password must be more than one number"))
        return self.cleaned_data["password"]

    def clean_confirm_password(self):
        if self.cleaned_data["confirm_password"] != self.cleaned_data.get("password"):
            raise forms.ValidationError(_("Password not match"))
        return self.cleaned_data["confirm_password"]

    def clean_username(self):
        username = self.cleaned_data["username"]
        if User.objects.exclude(pk=self.instance.pk).filter(username=username).exists():
            raise forms.ValidationError(_('Username is already in use.') + ' (' + username + ')')
        elif len(username) < 1:
            raise forms.ValidationError(
                _("Username is short. Must be more than 3 numbers please ")
            )

        return username


class usersFormPassword(usersForm):
    """
    فورم لكلمة المرور
    """
    class Meta:
        model = User
        fields = ["password", "confirm_password"]


class usersFormEdit(usersForm):
    """
    فورم لتعديل مستخدم
    """
    password = None
    confirm_password = None

    class Meta:
        model = User
        fields = [
            # "first_name",
            # "last_name",
            "username",
            "employee",
            "is_superuser",
            # "is_staff",
            "is_active",
            "groups",
        ]


class usersFormGroupEdit(usersForm):
    """
    فورم لتعديل  مجموعة مستخدمين
    """
    password = None
    confirm_password = None

    class Meta:
        model = User
        fields = ["groups"]

class usersFormGroupEmployee(usersForm):

    username = forms.CharField(
        required=False,
        max_length=200,
        widget=forms.TextInput(
            attrs={"placeholder": "Password", "class": "form-control"}
        ),
    )

    password = forms.CharField(
        required=False,
        label="Password",
        max_length=200,
        widget=forms.PasswordInput(
            attrs={"placeholder": "Password", "class": "form-control"}
        ),
    )
    confirm_password = forms.CharField(
        required=False,
        label="Confirm Password",
        max_length=200,
        widget=forms.PasswordInput(
            attrs={"placeholder": "Cinfirm Password", "class": "form-control"}
        ),
    )
    groups = forms.ModelMultipleChoiceField(
        required=False,
        queryset=Group.objects.all(),
        widget=forms.SelectMultiple(attrs={"class": "form-control", }),
    )

    class Meta:
        model = User
        fields = ["username", "password", "confirm_password", "groups","employee"]
