from django.db import models
from django.contrib.auth.models import  AbstractUser
# from employeesmanagement.models import Emp_data
from django.utils.translation import ugettext_lazy as _
from django.contrib.auth.base_user import AbstractBaseUser


class User(AbstractUser):
    employee = models.OneToOneField('employeesmanagement.emp_data', limit_choices_to={'emp_status': True}, on_delete=models.CASCADE,verbose_name =_('Employee'),null=True,blank=True)
    class Meta(AbstractUser.Meta):
        swappable = 'AUTH_USER_MODEL'
        db_table = "emtimeuser"
        verbose_name = _('Emtime User')

        
        

