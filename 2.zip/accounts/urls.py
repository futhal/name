from django.conf.urls.static import static
from django.urls import path

from EmTime import settings
from . import views

# ..
# 
# . the rest of your URLconf here ...

urlpatterns = [
                  path('login', views.login, name='login'),
                  path('logout', views.logout, name='logout'),
                  path('roles/', views.roles, name='roles'),
                  path('roles/edit/<int:pk>', views.roles_edit, name='rolesEdit'),
                  path('premission/<int:pk>', views.group_premission, name='premission'),
                  path('delete/role/<int:pk>', views.delete_role, name='delete_role'),
                  path('users/', views.users, name='users'),
                  path('users/edit/<int:pk>', views.users_edit, name='users_edit'),
                  path('users/edit_group/<int:pk>', views.users_edit_group, name='users_edit_group'),
                  path('users_edit_password/<int:pk>', views.users_edit_password, name='users_edit_password'),
                  path('delete_user/<int:pk>', views.delete_user, name='delete_user'),

              ] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
