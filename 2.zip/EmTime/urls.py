"""EmTime URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.conf import settings
from django.conf.urls import url
# for translate
from django.conf.urls.i18n import set_language
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import path, include
from django.views.static import serve

from employeesmanagement.views import main_page
from reporters.views import side_bare
from salary import views

# HERE
# end translate
# import employeesmanagement.urls, fingerprintdevices.urls, employeeattendance.urls, accounts.urls, salary.urls , backup.urls 
# import debug_toolbar

urlpatterns = [
    path(r'^i18n/', include('django.conf.urls.i18n')),
    path(
        ''
        , main_page,
        name="main_page"
    ),
    path(
        'employeesmanagement/',
        include('employeesmanagement.urls')
    ),
    path(
        'salary/',
        include('salary.urls')
    ),
    path(
        'fingerprintdevices/',
        include('fingerprintdevices.urls')
    ),
    path(
        'backup/',
        include('backup.urls')
    ),
    path(
        'employeeattendance/',
        include('employeeattendance.urls')
    ),
    path(
        'Em/',
        include('accounts.urls')
    ),
    path(
        '', include('reporters.urls')
    ),
    path(
        'setlang/',
        set_language,
        name='set_language'
    ),
    path('setlang2/', side_bare, name='set_language2')
]
if settings.DEBUG:
    import debug_toolbar

    urlpatterns += [
        path(
            'admin/', admin.site.urls
        ),
        path(r'^__debug__/', include(debug_toolbar.urls)),

    ]
    urlpatterns += static(settings.MEDIA_URL,
                          document_root=settings.MEDIA_ROOT)

if not settings.DEBUG:
    urlpatterns += [url(r'^media/(?P<path>.*)$', serve, {'document_root': settings.MEDIA_ROOT})]
    urlpatterns += [url(r'^static/(?P<path>.*)$', serve, {'document_root': settings.STATIC_ROOT})]

handler403 = views.handler403
handler404 = views.handler404

# if settings.DEBUG:
#     urlpatterns +=  static(settings.MEDIA_URL,
#                             document_root=settings.MEDIA_ROOT )
# if settings.DEBUG:

#     urlpatterns = [path("__debug__/", include(debug_toolbar.urls)),] + urlpatterns


# HERE


# HERE (add +)
