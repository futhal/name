''' Class Helper '''
from django.contrib import messages
from django.db import connection, models
from django.shortcuts import render, redirect
from django.urls import reverse
from django.utils.translation import ugettext_lazy as _


class Helper():
    ''' Class Helper '''

    def query(sqlCommand):
        ''' Create New Query '''
        cursor = connection.cursor()
        cursor.execute('delete from accounts_type where id=19')
        result = cursor.fetchall()
        print(result)
        return result


def display_view(request, model_name, form_name, templet_name, title):
    """Base Function To Show and  Add New  Record Of Any Model
    Arguments:
        request {request} 
        model_name {model} -- Model for get data
        form_name {Form} -- form to add datt
        templet_name {html} -- to display data
        title {str} -- title for show in Tamplat
    
    Returns:
        [redirect] -- redirect to next page
    """

    if request.method == "POST":
        form = form_name(request.POST, request.FILES)
        if form.is_valid():
            obj = form.save(commit=False)
            obj.created_by = request.user
            obj.save()
            if obj.pk:
                messages.success(request, _('Added Successfully '))
                return redirect(request.get_full_path())
            else:
                messages.error(request, _('Error adding process'))
    else:
        form = form_name()
    context = {
        'form': form,
        'action': reverse(str(model_name.__name__).lower() + '_list'),
        'title': _(title),
    }
    return render(request, templet_name, context)


def max_id(model_name, col='number'):
    number_max = model_name.objects.aggregate(number_max=models.Max(col))['number_max']
    if number_max == None:
        n = "%03d" % + 1
        return n
    else:
        y = int(number_max) + 1
        n = "%03d" % y
        return n
