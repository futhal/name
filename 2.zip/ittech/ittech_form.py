''' Class Itech Form '''
import re

from django import forms
from django.utils.translation import ugettext_lazy as _


class MainForm(forms.Form):
    ''' Class Itech Form '''

    def __init__(self, *args, **kwargs):
        super(MainForm, self).__init__(*args, **kwargs)
        for k, field in self.fields.items():
            # field.widget.attrs.update({"class": " form-control"})
            # if str(field.__class__.__name__)=='BooleanField':
            # field.widget.attrs.update({"class": " radio-controll"})

            if 'required' in field.error_messages:
                field.error_messages['required'] = _('The {0} Must be Entered.'.format(field.label))

            if 'null' in field.error_messages:
                field.error_messages['null'] = _('The {0} can\'t be Null .'.format(field.label))

            if 'blank' in field.error_messages:
                field.error_messages['blank'] = _(' The {0} can\'t be Blank .'.format(field.label))

            if 'invalid' in field.error_messages:
                field.error_messages['invalid'] = _(' The  value for {0} is invalid .'.format(field.label))

            if 'invalid_choice' in field.error_messages:
                field.error_messages['invalid_choice'] = _(' The invalid choice  for {0}.'.format(field.label))

            if 'unique' in field.error_messages:
                field.error_messages['unique'] = _('The {0} must be unique.'.format(field.label))

            if 'unique' in field.error_messages:
                field.error_messages['unique'] = _('The {0} must be unique.'.format(field.label))

            if 'max_length' in field.error_messages:
                field.error_messages['max_length'] = _(
                    'Ensure this value has at most %(max)d characters (it has %(length)d).')

            if 'min_length' in field.error_messages:
                field.error_messages['min_length'] = _(
                    'Ensure this value has at least %(min)d characters (it has %(length)d).')

    def clean_phone(self):
        regex = r"^\(?([0-9]{3})\)?[-.●]?([0-9]{3})[-.●]?"
        if self.cleaned_data["phone"]:
            if not re.search(regex, self.cleaned_data["phone"]):
                raise forms.ValidationError(_("Phone Number Must be This Format xxx-xxx"))
            return self.cleaned_data["phone"]
        else:
            return True


class MainModelForm(MainForm, forms.ModelForm):
    pass


IttechForm = MainForm
IttechModelForm = MainModelForm
