"""
logging
"""
import datetime
import logging.config
import os
import socket
import webbrowser
from functools import wraps

LOGGING_CONFIG = None
hostname = socket.gethostname()
IPAddr = socket.gethostbyname(hostname)
try:
    os.mkdir('logging\\{0}'.format(datetime.date.today()))
except OSError:
    pass

LOGGING = {
    'version': 1,
    'disable_existing_loggers': True,
    # filters will define when a logger should run
    'filters': {
        'require_debug_false': {
            '()': 'django.utils.log.RequireDebugFalse',

        },
        'require_debug_true': {
            '()': 'django.utils.log.RequireDebugTrue',
        },
    },
    # format in which logs will be written
    'formatters': {
        'simple': {
            'format': '[%(asctime)s] %(levelname)s %(message)s',
            'datefmt': '%Y-%m-%d %H:%M:%S'
        },
        'verbose': {
            'format': '[%(asctime)s] %(levelname)s  %(message)s',
            'datefmt': '%Y-%m-%d %H:%M:%S'
        },
    },
    # handlers define the file to be written, which level to write in that file,
    # which format to use and which filter applies to that logger
    'handlers': {
        'debug_logfile': {
            'level': 'DEBUG',
            'filters': ['require_debug_true'],  # do not run debug logger in production
            'class': 'logging.FileHandler',
            'filename': "logging\\{0}\\logger_debug_{1}.log".format(datetime.date.today(), datetime.date.today()),
            'formatter': 'verbose'
        },
        'info_logfile': {
            'level': 'INFO',
            'filters': ['require_debug_false'],  # run logger in production
            'class': 'logging.FileHandler',
            'filename': "logging\\{0}\\logger_info_{1}.log".format(datetime.date.today(), datetime.date.today()),
            'formatter': 'verbose',
        },
        'warning_logfile': {
            'level': 'WARNING',
            'filters': ['require_debug_false'],  # run logger in production
            'class': 'logging.FileHandler',
            'filename': "logging\\{0}\\logger_warning_{1}.log".format(datetime.date.today(), datetime.date.today()),
            'formatter': 'verbose',
        },
        'error_logfile': {
            'level': 'ERROR',
            'filters': ['require_debug_false'],  # run logger in production
            'class': 'logging.FileHandler',
            'filename': "logging\\{0}\\logger_error_{1}.log".format(datetime.date.today(), datetime.date.today()),
            'formatter': 'verbose',
        },
        'critical_logfile': {
            'level': 'CRITICAL',
            'filters': ['require_debug_false'],  # run logger in production
            'class': 'logging.FileHandler',
            'filename': "logging\\{0}\\logger_critical_{1}.log".format(datetime.date.today(), datetime.date.today()),
            'formatter': 'verbose'
        },
    },
    # here the handlers for the loggers and the level of each logger is defined
    'loggers': {
        'debug_logger': {
            'handlers': ['debug_logfile'],
            'level': 'DEBUG'
        },
        'info_logger': {
            'handlers': ['info_logfile'],
            'level': 'INFO',
            'propagate': True,
        },
        'warning_logger': {
            'handlers': ['warning_logfile'],
            'level': 'WARNING'
        },
        'error_logger': {
            'handlers': ['error_logfile'],
            'level': 'ERROR'
        },
        'critical_logger': {
            'handlers': ['critical_logfile'],
            'level': 'CRITICAL'
        },
    }
}
# logging configer
# logging.config.dictConfig(LOGGING)
# objects from level logging
info_logger = logging.getLogger('info_logger')
error_logger = logging.getLogger('error_logger')
warning_logger = logging.getLogger('warning_logger')
critical_logger = logging.getLogger('critical_logger')
debug_logger = logging.getLogger('debug_logger')


def logging_record(func):
    """
    decorator logging every thing
    """

    @wraps(func)
    def _wrapped_view(request, *args, **kwargs):
        """
        decorator logging every thing
        """
        data = list(request.POST.items())[1:]
        # s = request.headers.get('User-Agent')
        s = 'ittech'
        debug_logger.debug("{0} - {1} {2} ".format(
            s + '/\\' + func.__name__ + '/' + request.user.user_name + '/' + hostname + '/' + IPAddr + ' /',
            webbrowser.get().name, data), exc_info=True)
        info_logger.info("{0} - {1} {2} ".format(
            s + '/\\' + func.__name__ + '/' + request.user.user_name + '/' + hostname + '/' + IPAddr + ' /',
            webbrowser.get().name, data))
        warning_logger.warning("{0} - {1} {2} ".format(
            s + '/\\' + func.__name__ + '/' + request.user.user_name + '/' + hostname + '/' + IPAddr + ' /',
            webbrowser.get().name, data), exc_info=True)
        error_logger.error("{0} - {1} {2} ".format(
            s + '/\\' + func.__name__ + '/' + request.user.user_name + '/' + hostname + '/' + IPAddr + ' /',
            webbrowser.get().name, data), exc_info=True)
        critical_logger.critical("{0} - {1} {2} ".format(
            s + '/\\' + func.__name__ + '/' + request.user.user_name + '/' + hostname + '/' + IPAddr + ' /',
            webbrowser.get().name, data, ), exc_info=True)
        return func(request, *args, **kwargs)

    return _wrapped_view

# logging.basicConfig(
#     filename="ittech\\logs\\logger_{}.log".format(datetime.date.today()), 
#     format='%(asctime)s %(module)s   %(name)s  %(levelname)s: %(message)s',
#     level=logging.INFO)

# def logging_record(func):
#     @wraps(func)
#     def _wrapped_view(request, *args, **kwargs):
#         data = list(request.POST.items())[1:]
#         logging.info("{0} - {1} {2} ".format(func.__name__ +'/'+request.user.user_name +'/'+hostname + '/' + IPAddr +' /' , webbrowser.get().name , data))
#         return func(request, *args, **kwargs)
#     return _wrapped_view
