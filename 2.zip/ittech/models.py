"""Base class from All Another Models
"""
from django.conf import settings
from django.db import models
from django.utils.translation import ugettext_lazy as _
from search.url_mapping import model_detials

try:
    from reporters import defualt_query

    branch_id = defualt_query.branch_id
except:
    branch_id = 1


# my_session = SessionStore()
def get_val():
    pass
    # if 'branch_id' in my_session.keys():
    # print('KALDON')
    # print(Session.objects.all().first().get_decoded().get('branch_id'))
    # print(Session.objects.filter('branch_id'))
    # return Session.objects.filter('branch_id')
    # else:
    #     return 1


class BranchFilter(models.Manager):
    def get_queryset(self):
        global branch_id
        try:
            # print(get_val())
            return super().get_queryset().filter(branch_id__in=branch_id)
        except:
            return super().get_queryset()


class BranchWithoutFilter(models.Manager):
    def get_queryset(self):
        return super().get_queryset()


class BaseModel(models.Model):
    """Class Content   Four Fields Uing As base Class For Anther Model
    """

    created_at = models.DateTimeField(auto_now_add=True, auto_now=False)
    modified_at = models.DateTimeField(auto_now=True, auto_now_add=False)
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name="%(class)s_createdby",
        default=1,
        null=True,
        blank=True,
    )
    modified_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name="%(class)s_modifiedby",
        default=1,
        null=True,
        blank=True,
    )

    objects = BranchFilter()
    bobjects = BranchWithoutFilter()

    class Meta:
        abstract = True

    @classmethod
    def get_keys(cls, key_research, model):
        return_query = []
        for field in cls._meta.get_fields():
            if (
                    field.get_internal_type() != "ForeignKey"
                    and (field.get_internal_type() != "BooleanField")
                    and (field.get_internal_type() != "AutoField")
                    and (field.get_internal_type() != "TreeForeignKey")
            ):
                query = cls.objects.filter(**{field.name + "__icontains": key_research})
                if query:
                    if model in model_detials.keys():
                        try:
                            key = model_detials[model]
                        except:
                            key = "id"
                    else:
                        key = "id"
                    # if len(query)==1:
                    #     return_query=[*return_query,[{'id':a['id']
                    return_query = [
                        *return_query,
                        *[
                            {"id": a[key], "val": a[field.name]}
                            for a in query.values(key, field.name)
                        ],
                    ]
        return return_query

    def is_deletable(self):
        # get all the related object
        for rel in self._meta.get_fields():
            try:
                # check if there is a relationship with at least one related object
                related = rel.related_model.objects.filter(**{rel.field.name: self})
                if related.exists():
                    # if there is return a Tuple of flag = False the related_model object
                    return False, related
            except AttributeError:  # an attribute error for field occurs when checking for AutoField
                pass  # just pass as we dont need to check for AutoField
        return True, None


class Company(BaseModel):
    """Class Content    Fields For Initial Company
    """

    name_ar = models.CharField(verbose_name=_("Name"), max_length=100)
    name_en = models.CharField(verbose_name=_("Foreign Name"), max_length=100)
    abbrivation_name = models.CharField(
        verbose_name=_("Short Name"), max_length=100, null=True, blank=True
    )
    abbrivation_name_en = models.CharField(
        verbose_name=_("Foreign Name"), max_length=100, null=True, blank=True
    )
    note = models.CharField(
        verbose_name=_("Notes"), max_length=100, null=True, blank=True
    )
    image = models.FileField(
        verbose_name=_("image"), upload_to="images/", null=True, blank=True
    )

    def __str__(self):
        return str(self.pk) + "-" + self.name_ar

    class Meta:
        verbose_name = _("Company")


class Country(BaseModel):  # كلاس الدول
    """
    Definition of countries representing the geographical 
    scope of originating activity
    """

    RELIGION = (
        ("Judaism", _("Judaism")),
        ("Christianity", _("Christianity")),
        ("Islam", _("Islam")),
        ("Sikhism", _("Sikhism")),
    )
    CONTINENT = (
        ("Asia", _("Asia")),
        ("Africa", _("Africa")),
        ("Europe", _("Europe")),
        ("NorthAmericanContinent", _("North American Continent")),
        ("SouthAmericanContinent", _("South American Continent")),
    )
    name_ar = models.CharField(verbose_name=_("Arabic Name"), max_length=100)
    name_en = models.CharField(
        verbose_name=_("English Name"), max_length=100, null=True, blank=True
    )
    abbreviation_name = models.CharField(
        verbose_name=_("Abbreviation Name"), max_length=50, null=True
    )
    contient = models.CharField(
        choices=CONTINENT,
        verbose_name=_("Contient"),
        max_length=50,
        null=True,
        blank=True,
    )

    nationality = models.CharField(
        choices=RELIGION,
        verbose_name=_("Religon"),
        max_length=50,
        null=True,
        blank=True,
    )

    def __str__(self):
        return self.name_ar

    class Meta:
        verbose_name = _("Countery")


class Governorates(BaseModel):  # كلاس المحافظات
    """
    
    The governorates that represent the geographical
    starting point of the establishment's activity
    (Jad) (Al-Qaher) (Sana'a) with
    The possibility of linking the province to the countries 
    to which it belongs.
    """

    name_ar = models.CharField(verbose_name=_("Arabic Name"), max_length=100)
    name_en = models.CharField(
        verbose_name=_("English Name"), max_length=100, null=True, blank=True
    )
    abbreviation_name = models.CharField(
        verbose_name=_("Abbreviation Name"), max_length=50, null=True
    )
    country = models.ForeignKey(
        Country, verbose_name=_("Country"), on_delete=models.CASCADE
    )

    def __str__(self):
        return self.name_ar

    class Meta:
        verbose_name = _("Governorates")


class Cities(BaseModel):  # كلاس المدن
    """
    Cities that represent the geographical starting 
    point of the establishment's activity with
    The possibility of linking cities with the governorates 
    and countries to which they belong.
    """

    name_ar = models.CharField(verbose_name=_("Arabic Name"), max_length=100)
    name_en = models.CharField(
        verbose_name=_("English Name"), max_length=100, null=True, blank=True
    )
    abbreviation_name = models.CharField(
        verbose_name=_("Abbreviation Name"), max_length=50, null=True
    )
    governorate = models.ForeignKey(
        Governorates, verbose_name=_("Governorate Name"), on_delete=models.CASCADE
    )

    def __str__(self):
        return self.name_ar

    class Meta:
        verbose_name = _("Cities")


class Area(BaseModel):
    """
    The regions that represent the smallest geographical starting
    point of the activity of the establishment within the cities with
    The possibility of linking the region with 
    the cities to which it belongs.
    """

    name_ar = models.CharField(verbose_name=_("Arabic Name"), max_length=100)
    name_en = models.CharField(
        verbose_name=_("English Name"), max_length=100, null=True, blank=True
    )
    area_cities = models.ForeignKey(
        Cities, verbose_name=_("Cities"), on_delete=models.CASCADE
    )
    abbreviation_name = models.CharField(
        verbose_name=_("Abbreviation Name"), max_length=50, null=True
    )

    def __str__(self):
        return self.name_ar

    class Meta:
        verbose_name = _("Area")


class Branch(BaseModel):
    """Class Content    Fields For Initial Branch
    """

    company = models.ForeignKey(Company, on_delete=models.CASCADE, default=1)
    area = models.ForeignKey(Area, on_delete=models.CASCADE)
    name_ar = models.CharField(verbose_name=_("Name"), max_length=100)
    name_en = models.CharField(
        verbose_name=_("Foreig Nmae"), max_length=100, null=True, blank=True
    )
    address = models.CharField(
        verbose_name=_("Address"), max_length=200, null=True, blank=True
    )
    address_en = models.CharField(
        verbose_name=_("Foreign Address"), max_length=200, null=True, blank=True
    )
    first_line = models.CharField(
        verbose_name=_("First Head"), max_length=100, null=True, blank=True
    )
    second_line = models.CharField(
        verbose_name=_("Second Head"), max_length=100, null=True, blank=True
    )
    third_line = models.CharField(
        verbose_name=_("Third Head"), max_length=100, null=True, blank=True
    )
    first_line_en = models.CharField(
        verbose_name=_("Foreign First Head"), max_length=100, null=True, blank=True
    )
    second_line_en = models.CharField(
        verbose_name=_("Foreign Second Head"), max_length=100, null=True, blank=True
    )
    third_line_en = models.CharField(
        verbose_name=_("Foreign Third Head"), max_length=100, null=True, blank=True
    )
    specifiction = models.CharField(
        verbose_name=_("specifiction"), max_length=100, null=True, blank=True
    )
    website = models.URLField(
        verbose_name=_("website"), max_length=100, null=True, blank=True
    )
    image = models.FileField(
        verbose_name=_("Image"), upload_to="images/", null=True, blank=True
    )
    tax_number = models.PositiveIntegerField(
        verbose_name=_("Tax Number"), null=True, blank=True
    )
    company_register = models.PositiveIntegerField(
        verbose_name=_("Company register"), null=True, blank=True
    )
    phone = models.CharField(
        verbose_name=_("Phone"), max_length=16, null=True, blank=True
    )

    def __str__(self):
        return str(self.pk) + "-" + self.name_ar

    class Meta:
        verbose_name = _("Branch")


class ItTechBaseModel(BaseModel):
    """Class Content   Five Fields Using As base Class For Another Model
    """

    branch = models.ForeignKey(
        Branch, verbose_name=_("Branch"), on_delete=models.CASCADE, default=1
    )

    class Meta:
        abstract = True


ItTechModel = BaseModel
BranchModel = ItTechBaseModel
