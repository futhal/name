from django.apps import AppConfig


class BackupConfig(AppConfig):
    name = 'backup'
