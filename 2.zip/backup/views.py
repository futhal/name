import os

from django.contrib import messages
from django.contrib.auth.decorators import login_required, permission_required
from django.core import management
from django.shortcuts import render, redirect
from django.utils.translation import ugettext_lazy as _

from EmTime.settings import BACKUP_PATH
from dbbackup import default_app_config 

@login_required(login_url='login')
@permission_required('backup.view_backup', raise_exception=True)
def backup(request):
    """ 
    دالة انشاء نسخة من قاعدة البيانات 
    """
    # request.session["open_menu"] = {"backup": "menu-open"}
    # request.session["top_menu"] = {"backup": "active"}
    # request.session["sub_menu"] = {"home": "active"}
    content = {}
    files = os.listdir(BACKUP_PATH)
    if request.method == "POST":
        try:
            management.call_command('dbbackup')
            messages.success(request, _("Create Backup Successfully "))
            return redirect('backup')
        except:
            messages.error(request, _("Error Create Backup "))

    content["files"] = files[::-1]
    if not request.user.has_perm('backup.view_backup') and not request.user.has_perm(
            'backup.add_backup') and not request.user.has_perm('backup.delete_backup') and not request.user.has_perm(
            'backup.change_backup'):
        return render(request, 'error/403.html', content)

    return render(request, 'backup/backup.html', content)

@login_required(login_url='login')
def restore(request, back_name):
    """ 
     دالة استعادة نسخة من قاعدة البيانات
    """
    # request.session["open_menu"] = {"backup": "menu-open"}
    # request.session["top_menu"] = {"backup": "active"}
    # request.session["sub_menu"] = {"home": "active"}
    content = {}

    files = os.listdir(BACKUP_PATH)

    if request.method == "POST":
        try:
            management.call_command('dbrestore', input_filename=back_name, noinput=False)
            # os.system('cmd /k "py manage.py dbrestore -i {} --noinput"'.format(back_name))
            messages.success(request, _("Restore Backup Successfully "))
            return redirect('backup')
        except Exception as e:
            messages.error(request, _("Error Restore Backup "))

        content["files"] = files

    return render(request, 'backup/backup.html', content)

@login_required(login_url='login')
def delete_backup(request, file_name):
    """ 
    دالة حذف نسخة من قاعدة البيانات
    """
    # request.session["open_menu"] = {"backup": "menu-open"}
    # request.session["top_menu"] = {"backup": "active"}
    # request.session["sub_menu"] = {"home": "active"}
    content = {}
    files = os.listdir(BACKUP_PATH)
    if request.method == "POST":

        try:
            os.remove(BACKUP_PATH + '\\' + file_name)
            messages.success(request, _("Delete Backup Successfully "))

            return redirect('backup')
        except:
            messages.error(request, _("Error Delete Backup "))

    content["files"] = files

    return render(request, 'backup/backup.html', content)
