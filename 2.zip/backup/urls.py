from django.urls import path

from . import views

urlpatterns = [

    path('backup/', views.backup, name='backup'),
    path("restore/<back_name>", views.restore, name="restore"),
    path("delete_backup/<file_name>", views.delete_backup, name="delete_backup"),

]
