from django.db import models
from django.utils.translation import ugettext_lazy as _


class Backup(models.Model):
    """النسخ الاحتياطي يستخدم للصلاحيات فقط
    """
    name = models.CharField(max_length=10)

    class Meta:
        db_table = "backup"
        verbose_name = _("Backup")

# Create your models here.
