from django.urls import path

from fingerprintdevices import views

urlpatterns = [

    path(
        'terminal/',
        views.terminal,
        name='terminal'
    ),
    path(
        'terminal/add',
        views.terminal_add,
        name='terminal_add'
    ),
    path(
        'terminal/scan',
        views.terminal_scan,
        name='terminal_scan'
    ),
    path(
        'terminal/<action>/<int:pk>/',
        views.terminal_action,
        name='terminal_action'
    ),

    path(
        'attendance/',
        views.attendance,
        name='attendance'
    ),
    path(
        'attendance/sync/',
        views.attendance_sync,
        name='attendance_sync'
    ),
    path(
        'get_user_data/',
        views.get_user_data.as_view(),
        name='get_user_data'
    ),
    path(
        're_upload_user_finger/',
        views.re_upload_user_finger,
        name='re_upload_user_finger'
    ),
    path(
        'get_user_show/',
        views.get_user_show.as_view(),
        name='get_user_show'
    ),
    path(
        'ShowAttendance/',
        views.ShowAttendance.as_view(),
        name='ShowAttendance'
    ),
    path('import_from_excel/',views.import_from_excel,name='import_from_excel'),
    path('add_user_to_fingerprint/',views.add_user_to_fingerprint.as_view(),name='add_user_to_fingerprint'),
    path('synchronization_fingerprint/',views.synchronization_fingerprint,name='synchronization_fingerprint'),
    path('Export_Data_To_Excel/',views.Export_Data_To_Excel,name='Export_Data_To_Excel'),
    path('add_user/',views.add_user.as_view(),name="add_user"),
    path('show_user/',views.show_user.as_view(),name="show_user"),
    path('attendance_export/',views.attendance_export,name="attendance_export"),
]
