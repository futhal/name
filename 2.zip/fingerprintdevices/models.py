from django.db import models
from django.utils.translation import ugettext_lazy as _

import zk
from employeeattendance.models import ManualAttendeeDetails
from zk.exception import ZKError
from .settings import get_terminal_timeout
from employeesmanagement.base import BaseModelF

class Terminal(models.Model):
    """
    model (Terminal)
    Content:
        name -- [الاسم]
        serialnumber -- [الرقم التسلسلي]
        ip -- [عنوان ip]
        port -- [المنفذ]
    """
    name = models.CharField(_('name'), max_length=200)
    serialnumber = models.CharField(_('serialnumber'), max_length=100, unique=True)
    ip = models.CharField(_('ip'), max_length=15, unique=True)
    port = models.IntegerField(_('port'), default=4370)

    class Meta:
        db_table = 'zk_terminal'
        verbose_name = _('Terminal')
        ordering = ['id']

    def __init__(self, *arg, **kwargs):
        self.zkconn = None
        super(Terminal, self).__init__(*arg, **kwargs)

    def __str__(self):
        return self.name

    def format(self):
        from signals import PauseSignal
        with PauseSignal(signal=pre_delete, receiver=pre_delete_user, sender=User):
            self.zk_connect()
            self.zk_voice()
            self.zk_clear_data()
            self.users.all().delete()

    def zk_connect(self):
        ip = self.ip
        port = self.port
        serialnumber = self.serialnumber
        terminal = zk.ZK(ip, port, get_terminal_timeout(), serialnumber)
        conn = terminal.connect()
        if conn:
            
            terminal.disable_device()
            self.zkconn = terminal
        else:
            self.Zkconn=None

            # print('noooooooooooooooooooooooooo')
            raise ZKError(_('can\'t connect to terminal'))

    def zk_disconnect(self):
        if not self.zkconn:
            raise ZKError(_('terminal connection error'))
        self.zkconn.enable_device()
        self.zkconn.disconnect()

    def zk_restart(self):
        if not self.zkconn:
            raise ZKError(_('terminal connection error'))
        self.zkconn.restart()

    def zk_poweroff(self):
        if not self.zkconn:
            raise ZKError(_('terminal connection error'))
        self.zkconn.poweroff()

    def zk_getserialnumber(self):
        if not self.zkconn:
            raise ZKError(_('terminal connection error'))
        sn = self.zkconn.get_serialnumber()
        return sn

    def zk_voice(self):
        if not self.zkconn:
            raise ZKError(_('terminal connection error'))
        self.zkconn.test_voice()

    def zk_setuser(self,uid=None, name='', privilege=0, password='770428', group_id='', user_id='', card=0): 
       
        return(self.zkconn.set_user(
            uid=uid,
            name=str(name),
            privilege=privilege,
            password=password,
            group_id=group_id,
            user_id=user_id,
            card=card
        ))
     

    def zk_delete_user(self, uid,use):
        if not self.zkconn:
            raise ZKError(_('terminal connection error'))
        self.zkconn.delete_user(uid)

    def zk_clear_data(self):
        if not self.zkconn:
            raise ZKError(_('terminal connection error'))
        self.zkconn.clear_data()

    def zk_get_attendances(self):
        if not self.zkconn:
            raise ZKError(_('terminal connection error'))
        attendances = self.zkconn.get_attendance()
        return attendances

    def zk_clear_attendances(self):
        if not self.zkconn:
            raise ZKError(_('terminal connection error'))
        self.zkconn.clear_attendance()
    
    def zk_get_user(self):
        if not self.zkconn:
            raise ZKError(_('terminal connection error'))
        user=self.zkconn.get_users()
        return user

class UserFinger(models.Model):
    name=models.CharField(max_length = 100, verbose_name = _('User Name'), unique = True)
    class Meta:
        db_table = "user_finger"
        verbose_name = _("User Finger")
    def __str__(self):
        return self.name
    def is_infingerprint(self):
        return self.userwithfingerprint_set.all()

   
    # def set_user(self, uid=None, name='', privilege=0, password='770428', group_id='', user_id='', card=0):
    

class Attendance(BaseModelF):
    """
    model (Attendance  )
    Content:
        [user] -- [UserFinger الموظف مفتاح أجنبي من ]
        [time] -- [الوقت ]
        [terminal] -- [Terminal الموظف مفتاح أجنبي من ]
        [date] -- [التاريخ]
        [manual_attendee_details] -- [ManualAttendeeDetails التحضير اليدوي مفتاح أجنبي من ]
    """
    user = models.ForeignKey(UserFinger, on_delete = models.CASCADE, related_name='attendances',
                                 verbose_name=_('user'))
    time = models.TimeField(verbose_name=_('Time'))
    status = models.IntegerField(null=True, verbose_name=_('Status'))
    terminal = models.ForeignKey(Terminal, blank=True, null=True, on_delete=models.SET_NULL,
                                 related_name='Attendancess', verbose_name=_('Terminal'))
    date = models.DateField(verbose_name=_('Date'))

    class Meta:
        db_table ='zk_attendance'
        verbose_name=_('zk_attendance')

    def __unicode__(self):
        return '{}'.format(self.user.name)

#    print(u.uid,"  ",u.name,"  ",u.user_id)
#                 print(type(u.privilege)," ",u.password,"  ",u.group_id,"  ",u.card)

class UserWithFingerPrint(models.Model):
    chooce_priv=((14,_('ADMIN')),(6,_('MANAGER')),(2,_('ENROLLER')),(0,_('DEFAULT')))
    user_finger=models.ForeignKey(UserFinger,verbose_name=_('User'),on_delete=models.PROTECT)
    user_id=models.CharField(max_length=100,verbose_name=('User id'))
    uid=models.CharField(max_length=100,verbose_name=('Uid'))
    terminal = models.ForeignKey(Terminal,on_delete=models.PROTECT,verbose_name=_('Terminal'))
    privilege=models.IntegerField(verbose_name=_('Privilege'),null=True,blank=True,choices=chooce_priv)
    password=models.CharField(max_length=100,verbose_name=_('Password'),null=True,blank=True)
    group_id=models.CharField(max_length=100,verbose_name=_('Group'),null=True,blank=True)
    card=models.CharField(max_length=100,verbose_name=_('Card'),null=True,blank=True)
    class Meta:
        db_table = "user_with_finger_print"
        verbose_name = _("user with fingerprint")
        unique_together=('terminal','user_finger')
  
