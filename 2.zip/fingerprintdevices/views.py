from django.contrib import messages
from django.contrib.auth.decorators import login_required, permission_required
from django.http import Http404
from django.http import (
    JsonResponse,
    QueryDict
)
from django.db import transaction
from ittech.ittech_message import message
from django.core import serializers
import json
from django.db.models import Q
from django.http import HttpResponseRedirect 
from django.shortcuts import render, redirect, get_object_or_404,reverse
from django.utils.translation import ugettext_lazy as _
from django_datatables_view.base_datatable_view import BaseDatatableView
from employeesmanagement.models import Emp_data
from zk.exception import ZKError
from .forms import ScanTerminal, SaveTerminal, EditTerminal,UserFingerForm,UserWithFingerPrintForm
from .models import Terminal, Attendance,UserFinger,UserWithFingerPrint
import datetime
from django.forms import forms 
import xlwt
import django_excel as excel
from django.views.generic import CreateView
from .forms import ExportForm
from django.utils.dateparse import parse_time, parse_date
from django.core.exceptions import ValidationError

class Exption_Exis(Exception):
    pass

# class MyExcept(Exception):
#     pass

class UploadFileForm(forms.Form):
    file = forms.FileField()

def import_from_excel(request):   
    if request.method == "POST":
        form = UploadFileForm(request.POST, request.FILES)
        # def choice_func(row):
        #     q = request.user
        #     row[0] = q
        #     return row
        if form.is_valid():
            try:         
                UserFinger.objects.all().delete()    
                request.FILES["file"].save_to_database(
                    model=UserFinger,
            
                    mapdicts=['card','group_id','id','password','privilege','terminal_id','uid','user_id','user_name'],         
                )
            except Exception as e:
                pass               
        return HttpResponseRedirect(reverse('get_user_data'))       
    else:
        form = UploadFileForm()
    return render(request,'zkcluster/import_from_excel.html', {'form': form})



# from logs.log import loggingrecor
@login_required(login_url='login')
@permission_required('fingerprintdevices.view_terminal', raise_exception=True)
def terminal(request):
    """
    دالة لعرض كل اجهزة البصمة
    """
    # request.session["open_menu"] = {"Finger_devices": "menu-open"}
    # request.session["top_menu"] = {"Finger_devices": "active"}
    # request.session["sub_menu"] = {"terminal": "active"}
    terminals = Terminal.objects.all()
    data = {'terminals': terminals}
    return render(request, 'zkcluster/terminal.html', data)


@login_required(login_url='login')
@permission_required('fingerprintdevices.add_terminal', raise_exception=True)
def terminal_add(request):
    """
    دالة لاضافة جهاز بصمة
    """
    # request.session["open_menu"] = {"Finger_devices": "menu-open"}
    # request.session["top_menu"] = {"Finger_devices": "active"}
    # request.session["sub_menu"] = {"terminal": "active"}
    connected = request.GET.get('connected')
    messages.success(request, _('Connect Successfully'))
    if connected:
        form = SaveTerminal(request.POST or None, {'validate_name': True})
        if form.is_valid():
            try:
                # loggingrecord(request)
                form.save()
                return redirect('terminal')
            except ZKError:
                messages.error(request, _("Error adding process"))
    else:
        form = SaveTerminal(request.POST or None)

    data = {
        'form': form
    }
    return render(request, 'zkcluster/terminal_add.html', data)


@login_required(login_url='login')
@permission_required('fingerprintdevices.add_terminal', raise_exception=True)
def terminal_scan(request):
    """
    دالة للاتصال بجهاز البصمة قبل اضافتة
     """
    # request.session["open_menu"] = {"Finger_devices": "menu-open"}
    # request.session["top_menu"] = {"Finger_devices": "active"}
    # request.session["sub_menu"] = {"terminal": "active"}
    form = ScanTerminal(request.POST or None)
    if request.POST and form.is_valid():
        ip = form.cleaned_data['ip']
        port = form.cleaned_data['port']
        serialnumber = form.cleaned_data['serialnumber']
        terminal = Terminal(
            ip=ip,
            port=port,
            serialnumber=serialnumber
        )
        try:
            terminal.zk_connect()
            mutable = request.POST._mutable
            request.POST._mutable = True
            request.POST._mutable = mutable
            terminal.zk_disconnect()
            return terminal_add(request)
        except ZKError:
            messages.success(request, _("Connect Faild"))

    data = {
        'form': form
    }
    return render(request, 'zkcluster/terminal_scan.html', data)


@login_required(login_url='login')
@permission_required('fingerprintdevices.change_terminal', raise_exception=True)
def terminal_edit(request, terminal_id):
    """
    دالة لتعديل بيانات جهاز البصمة 
    """
    # request.session["open_menu"] = {"Finger_devices": "menu-open"}
    # request.session["top_menu"] = {"Finger_devices": "active"}
    # request.session["sub_menu"] = {"terminal": "active"}
    terminal = get_object_or_404(Terminal, pk=terminal_id)
    form = EditTerminal(request.POST or None, instance=terminal)
    if request.POST and form.is_valid():
        try:
            # loggingrecord(request)
            form.save()

        except ZKError:
            messages.success(request, _("Error edit process "))
        return redirect('terminal')
    data = {
        'terminal': terminal,
        'form': form
    }
    return render(request, 'zkcluster/terminal_edit.html', data)


@login_required(login_url='login')
def terminal_restart(request, terminal_id):
    """
    دالة لاعادة تشغيل جهاز البصمة
    """
    # request.session["open_menu"] = {"Finger_devices": "menu-open"}
    # request.session["top_menu"] = {"Finger_devices": "active"}
    # request.session["sub_menu"] = {"terminal": "active"}
    terminal = get_object_or_404(Terminal, pk=terminal_id)
    try:
        # loggingrecord(request)
        terminal.zk_connect()
        terminal.zk_restart()
    except ZKError:
        messages.add_message(request, messages.ERROR, _("Error restert process"))

    return redirect('terminal')


@login_required(login_url='login')
def terminal_action(request, action, pk):
    """
    دالة يتم استدعائها من صفحة عرض الاجهزة عند النقر على تعديل او اعادة تشغيل 
    """
    # request.session["open_menu"] = {"Finger_devices": "menu-open"}
    # request.session["top_menu"] = {"Finger_devices": "active"}
    # request.session["sub_menu"] = {"terminal": "active"}
    if action == 'edit':
        return terminal_edit(request, pk)
    elif action == 'restart':
        return terminal_restart(request, pk)
    else:
        raise Http404(_("Action doest not allowed"))


@login_required(login_url='login')
def attendance(request):
    """
    دالة لعرض الحضور لجميع الموظفين
    """

    # request.session["open_menu"] = {"Finger_devices": "menu-open"}
    # request.session["top_menu"] = {"Finger_devices": "active"}
    # request.session["sub_menu"] = {"attendance": "active"}
    # attendances = Attendance.objects.all().order_by('date','time')
    # print(attendances)
    # data = {'attendances': attendances}
    return render(request, 'zkcluster/attendance.html', {})


@login_required(login_url='login')
def attendance_sync(request):
    """
    دالة يتم استدعائها من أجل سحب البيانات من البصمة
    """
    # request.session["open_menu"] = {"Finger_devices": "menu-open"}
    # request.session["top_menu"] = {"Finger_devices": "active"}
    # request.session["sub_menu"] = {"attendance": "active"}    
    if  request.method == 'POST':      
        msg, state = pull_fingerprints()        
        return JsonResponse({'message': msg, 'state': state})    

    return render(request, 'zkcluster/attendance.html',{})


def pull_fingerprints():
    """
    دالة لسحب بصمات الموظفين من جهاز البصمة 
    """
    terminals = Terminal.objects.all()
    msg = ""
    for terminal in terminals:
        try:
            terminal.zk_connect()
            # Attendance.objects.filter(terminal=terminal).delete()
            attendances = []
            for attendance in terminal.zk_get_attendances():
                if int(attendance.user_id) != 0:
                    time_and_date = attendance.timestamp
                    time = time_and_date.time()
                    date = time_and_date.date()
                    user = UserWithFingerPrint.objects.filter(user_id=attendance.user_id,terminal=terminal).first()
                    if user:
                        Attendance.objects.update_or_create(
                            user=user.user_finger,
                            time=time,
                            status=attendance.status,
                            date=date,
                            terminal=terminal,
                        )
                else:
                    pass
            msg = msg + str(_('Synchronization SuccessFully')) + ' ' + terminal.name +'\n'
            terminal.zk_disconnect()               
        except Exception as e:
            # terminal.zk_disconnect()
            msg = msg + str(_('Failed To Connect To')) + ' '+ terminal.name +'\n' 

        
    return msg, 0
class add_user(CreateView):
    """
    هذه الكلاس لاظافة مستخدم للجهاز البصمة
    """
    def post(self, request, *args, **kwargs):
        form=UserFingerForm(request.POST)
    
        if request.POST.get('id2'):
            pk=int(request.POST.get('id2'))
            data=get_object_or_404(UserFinger,pk=pk)
            form=UserFingerForm(request.POST,instance=data)
        if form.is_valid():                
                
            obj=form.save(commit=False)
            if request.POST.get('id2') and obj.is_infingerprint():
                try:
                    with transaction.atomic():
                        obj.save()
                        for p in obj.is_infingerprint():                  
                        
                            p.terminal.zk_connect()
                            uid,user_id = p.terminal.zk_setuser( uid =int(p.uid),
                                                user_id=p.user_id,
                                                name=p.user_finger.name,
                                                password=p.password,
                                                privilege=p.privilege,
                                                group_id=p.group_id if p.group_id else '',
                                                card=p.card if p.card else 0
                                                )
                            p.terminal.zk_disconnect()
                        status=1
                        msg=_('Add Successfully') if not request.POST.get('id2') else _('Update Successfully')
                        name=obj.name
                        pk=obj.pk
                        result={'status':status,'msg':msg,'name':name,'pk':pk} 
                        print('ok'*40)
                except Exception as e:
                    msg=str(_('Failed To Connect To')) + p.terminal.name
                    status=0
                    result={'status':status,'msg':msg} 

            else:
               
                obj.save()               
                status=1
                msg=_('Add Successfully') if not request.POST.get('id2') else _('Update Successfully'),
                name=obj.name
                pk=obj.pk
                result={'status':status,'msg':msg,'name':name,'pk':pk}                        

        else:            
            result={'status':0,'msg':form.errors['name'][0]}
    
        return JsonResponse(result)
    def delete(self, request, *args, **kwargs):
        """
            هذه الدالة تعمل على حذف     
        """
        pk = int(QueryDict(request.body).get('id'))
        if pk:
            try:                
                data = get_object_or_404(UserFinger,pk=pk)               
                data.delete()                
                msg = message.delete_successfully()
                result = {'status': 1, 'message': msg}
            except Exception as e:
                msg = message.record_error_delete()
                result = {'status': 0, 'message': msg}
        else:
            msg = message.record_error_delete()
            result = {'status': 0, 'message': msg}

        return JsonResponse(result)

    
    def get(self, request, *args, **kwargs):           
        if request.GET.get('id'):
            pk=int(request.GET.get('id'))            
            try:

                data = UserFinger.objects.filter(pk=pk)
                print(data,pk)
                print(serializers.serialize('json', data),'S'*20)
                result = {'status': 1, 'data': serializers.serialize('json', data)}
            except:
                result = {'status': 0, 'data': 'Erorr'}

            return JsonResponse(result)
        context = {
            'urljson': reverse('show_user'),            
            'UserFingerForm':UserFingerForm(),
            }
        if request.user.has_perm('fingerprintdevices.view_UserFinger'):
            return render(request,'zkcluster/show_user.html',context)
        else:
            return render(request, 'error/403.html', {})
                   

class  get_user_data(CreateView):  
   
    def post(self, request, *args, **kwargs):
        '''
        دالة استيرد اسماء المستخدمين للبصمة من ملف اكسل 
        '''

        form = UploadFileForm(request.POST, request.FILES)  
       
        if form.is_valid():           
            UserWithFingerPrint.objects.all().delete()  
            UserFinger.objects.all().delete()
            try:           
                request.FILES["file"].save_to_database(                                      
                    model=UserFinger,
                    mapdicts=['id','name'],           
                )
               
                data={'msg':'Import Successfuly','status':1}
            except Exception as e:
                data={'msg':'Import Erorr','status': 0}                    
        else:           
            data={'msg':'Import Erorr','status':0}
    
        return JsonResponse(data)              

    def get(self, request, *args, **kwargs):
        # request.session["open_menu"] = {"Finger_devices": "menu-open"}
        # request.session["top_menu"] = {"Finger_devices": "active"}
        # request.session["sub_menu"] = {"get_user_data": "active"}
        context = {
            'urljson': reverse('get_user_show'),
            'form':UploadFileForm(),
            'UserFingerForm':UserFingerForm(),
            'UserWithFingerPrintForm':UserWithFingerPrintForm(),
         }
        if request.user.has_perm('fingerprintdevices.view_userfinger'):
            return render(request,'zkcluster/get_user_data.html',context)
        else:
            return render(request, 'error/403.html', {})
       

                
class get_user_show(BaseDatatableView):
    """
    كلاس لعرض البينات من جدول المستخدمين  للبصمات 
    """

    model = UserWithFingerPrint
    columns = [
        'id',
        'user_finger',       
        'user_id',
        # 'uid',
        "terminal",
        'privilege',
        'password',
        'group_id',
        'card',
        'action',
    ]
    order_columns = [
        'id', 
        'user_finger',
        'user_id',
        # 'uid',
        "terminal",
        'privilege',
        'password',
        'group_id',
        'card',
        'action',
    ]
    count = 0

    def render_column(self, row, column):
        """Render Column For Datatable
        """
        if column == "id":
            self.count += 1
            return self.count
        elif column == "action":
            action = ""
            action_edit = '<a class="edit_row" data-url="{2}" data-id="{0}" ' \
                          'style="DISPLAY: -webkit-inline-box;"  data-toggle="tooltip"' \
                          ' title="{1}"><i class="fa fa-edit"></i></a>'.format(
                row.pk, _("Edit"), reverse("add_user_to_fingerprint"))

            action_delete = '<a class="delete_row" data-url="{2}" data-id="{0}" ' \
                            'style="DISPLAY: -webkit-inline-box;"  data-toggle="tooltip"' \
                            ' title="{1}"><i class="fa fa-trash"></i></a>'.format(
                row.pk, _("Delete"), reverse("add_user_to_fingerprint"))
            if self.request.user.has_perm("fingerprintdevices.change_user_with_finger_print"):
                action += action_edit

            if self.request.user.has_perm("fingerprintdevices.delete_user_with_finger_print"):
                action += action_delete

            return action
        else:
            return super(get_user_show, self).render_column(row, column)

    def filter_queryset(self, qs):
        """To Filter data in table using in search
        """
        sSearch = self.request.GET.get("sSearch", None)
        if sSearch:
            qs = qs.filter(
                Q(user_finger__name__icontains=sSearch)
                | Q(uid__icontains=sSearch)
               
            )
        return qs

def re_upload_user_finger(request):
    return JsonResponse({'data':serializers.serialize('json',UserFinger.objects.all())})
class add_user_to_fingerprint(CreateView):
    '''
    يعمل هذا الكلاس على اظافة المستخدمين الى جهاز البصمة 
    '''
    def get(self, request, *args, **kwargs):     
        if request.GET.get('id'):
            pk=int(request.GET.get('id'))
            
            try:

                data = UserWithFingerPrint.objects.filter(pk=pk)
                
                result = {
                    'status': 1, 
                    'data': serializers.serialize('json', data)
                    }
            except:
                result = {
                    'status': 0,
                    'data': 'Erorr'
                    }

        else:
            result = {'status': 0, 'data': 'Erorr'}
        return JsonResponse(result)
    
    

    def post(self, request, *args, **kwargs):
        form=UserWithFingerPrintForm(request.POST)
        user_id = ''
        uid=None
        msg=''
        if request.POST.get('id'):                     
            pk=int(request.POST.get('id'))
            data=get_object_or_404(UserWithFingerPrint,pk=pk)
            form=UserWithFingerPrintForm(request.POST,instance=data)
            user_id=str(data.user_id)
            uid=int(data.uid)            
            msg='Update SuccessFully'
        if form.is_valid():
            obj=form.save(commit=False)
            try:                
                obj.terminal.zk_connect()                
                uid,user_id = obj.terminal.zk_setuser( uid = uid,
                                                   user_id=user_id,
                                                   name=obj.user_finger.name,
                                                   password=obj.password,
                                                   privilege=obj.privilege,
                                                   group_id=obj.group_id if obj.group_id else '',
                                                   card=obj.card if obj.card else 0
                                                   )
                
                # if request.POST.get('id'):               
                obj.uid=uid
                obj.user_id=user_id
                obj.save()                       

                msg='Add SuccessFully' if not msg else msg 
                data={'status':1,'msg':msg }
                obj.terminal.zk_disconnect() 

            except Exception as e:
                print('F'*20)

                data={
                    'status':0,
                    'msg':str(_('Failed To Connect To')) + ' ' +\
                    obj.terminal.name
                    }
        else:       
            print('h'*20)
            
            data={'status':0,
            'msg':'\n'.join([ v[0] for k,v in form.errors.items()])
            }       

        return JsonResponse(data)

    def delete(self, request, *args, **kwargs):
        """
            هذه الدالة تعمل على حذف     
        """
        pk = int(QueryDict(request.body).get('id'))
        if pk:
            try:                
                data = get_object_or_404(UserWithFingerPrint,pk=pk)
                data.terminal.zk_connect()
                data.terminal.zk_delete_user(int(data.uid),str(data.user_id))
                data.delete()
                data.terminal.zk_disconnect()
                msg = message.delete_successfully()
                result = {'status': 1, 'message': msg}
            except Exception as e:
                msg = message.record_error_delete()
                result = {'status': 0, 'message': msg}
        else:
            msg = message.record_error_delete()
            result = {'status': 0, 'message': msg}

        return JsonResponse(result)

def synchronization_fingerprint(request):
    '''
    دالة تعمل على سحب بيانات المستخدحين من جهاز البصة الى قاعدة البيانات
    '''

    terminals = Terminal.objects.all()
    msg=""
    if terminals:
             
        for terminal in terminals:
            try:                
                terminal.zk_connect()                
                users=terminal.zk_get_user()                   
                for u in users:
                    try:
                        print(u.name)
                        obj = UserWithFingerPrint.objects.filter(user_id = u.user_id, terminal = terminal).first()
                        if obj :
                            obj = obj.user_finger
                            if obj.name != u.name :
                                obj.name = u.name
                                obj.save()
                        else :
                            obj = UserFinger.objects.create(name = u.name)                          
                       
                        UserWithFingerPrint.objects.update_or_create(
                            user_finger = obj,                        
                            user_id = u.user_id,
                            uid = u.uid,
                            terminal = terminal,
                            privilege = u.privilege,
                            password = u.password,
                            group_id = u.group_id,
                            card = u.card,
                        )
                    except Exception as e:
                        print(str(e))
                        # pass
                msg = msg + str(_('Synchronization SuccessFully')) + ' ' + terminal.name + '\n'
                terminal.zk_disconnect()

            except Exception as e:               
                msg = msg + str(_('Failed To Connect To')) + ' '+ terminal.name + '\n'
     
        
        result={'status':0,'msg':msg}

       
        return  JsonResponse(result)
               
                    
               
    else:
        result={'status':1,'msg':_('Fingerprint Devices Must Be Added')}
        return  JsonResponse(result)

def Export_Data_To_Excel(request):
    '''
    دالة التصدير الى الاكسيل للمستخدمين لجهاز البصمة
    '''        
    try:
        return excel.make_response_from_tables([UserFinger],"xls", file_name="finger Data")
        
    except Exception as e:
        print(str(e))
    


  
    
               
class show_user(BaseDatatableView):
    """
    كلاس لعرض البينات من جدول المستخدمين   
    """

    model = UserFinger
    columns = [
        'id',
        'name',
        'action',     
      
    ]
    order_columns = [
        'id', 
        'name',
        'action',       
    ]
    count = 0

    def render_column(self, row, column):
        """Render Column For Datatable
        """
        if column == "id":
            self.count += 1
            return self.count
        elif column == "action":
            action = ""
            action_edit = '<a class="edit_row" data-url="{2}" data-id="{0}" ' \
                          'style="DISPLAY: -webkit-inline-box;"  data-toggle="tooltip"' \
                          ' title="{1}"><i class="fa fa-edit"></i></a>'.format(
                row.pk, _("Edit"), reverse("add_user"))

            action_delete = '<a class="delete_row" data-url="{2}" data-id="{0}" ' \
                            'style="DISPLAY: -webkit-inline-box;"  data-toggle="tooltip"' \
                            ' title="{1}"><i class="fa fa-trash"></i></a>'.format(
                row.pk, _("Delete"), reverse("add_user"))
            if self.request.user.has_perm("fingerprintdevices.change_user_with_finger_print"):
                action += action_edit

            if self.request.user.has_perm("fingerprintdevices.delete_user_with_finger_print"):
                action += action_delete

            return action
        else:
            return super(show_user, self).render_column(row, column)

    def filter_queryset(self, qs):
        """To Filter data in table using in search
        """
        sSearch = self.request.GET.get("sSearch", None)
        if sSearch:
            qs = qs.filter(
                Q(name__icontains=sSearch)
              
               
            )
        return qs




class ShowAttendance(BaseDatatableView):
    """
    كلاس لعرض البينات من جدول المستخدمين   
    """

    model = Attendance 

    columns = [
        'id',
        'user',
        'terminal',     
        'date',     
        'time',         
    ]
    order_columns = [
       'user',
        'terminal',     
        'date',     
        'time',        
    ]
    count = 0
   
    def render_column(self, row, column):
        """Render Column For Datatable
        """
        if column == "id":
            self.count += 1
            return self.count       
        else:
            return super(ShowAttendance, self).render_column(row, column)
    def get_initial_queryset(self):
        return self.model.objects.all().order_by('user','date','time')
    def filter_queryset(self, qs):
        """To Filter data in table using in search
        """
        sSearch = self.request.GET.get("sSearch", None)
        if sSearch:
            qs = qs.filter(
                Q(user__name__icontains=sSearch)|
                Q(terminal__name__icontains=sSearch)|
                Q(date__icontains=sSearch)|
                Q(time__icontains=sSearch)   
              
               
            )
        return qs

def attendance_export(request):
    dict_errors={}   

    if request.method == 'POST':
        form=ExportForm(request.POST)
        f_d = parse_date(request.POST.get('from_date'))
        t_d = parse_date(request.POST.get('to_date'))
        s_in = parse_time(request.POST.get('start_in'))
        e_in = parse_time(request.POST.get('end_in'))
        s_out = parse_time(request.POST.get('start_out'))
        e_out = parse_time(request.POST.get('end_out'))
        if t_d < f_d :
            dict_errors['to_date'] = _("To date must be larger than From date")                      
        if e_in < s_in :
            dict_errors['end_in'] = _("Attendance ending must be larger than beginning")
        if e_out < s_out :
            dict_errors['e_out'] = _("Leaving endinge musr be larger than beginning")                      
        if e_out < s_in :
            dict_errors['e_out1'] = _("Leaving time must be  larger than Attendance")
        if dict_errors :
            return render(request,'zkcluster/attendance_export.html',{'ExportForm':ExportForm(request.POST),'dict_errors':dict_errors} )
            
        emps = UserFinger.objects.all()
        list_att=[]
        for emp in emps:
            i = 0
            date_emp=emp.attendances.filter(date__range=[f_d,t_d]).dates('date','day',order='ASC')
            att_emp= emp.attendances.filter(date__range=[f_d,t_d]).values_list('date','time')
            for d in date_emp:
                time_in = att_emp.filter(date=d,time__gte=s_in,
                time__lt=e_in).values_list('time',flat=True).order_by('time')
                time_out=att_emp.filter(date=d,time__gte=s_out,
                time__lt=e_out).values_list('time',flat=True).order_by('time')
                time_in = time_in[0] if time_in else ""
                time_out = time_out[0] if time_out else ""

                if (time_in or time_out) and i == 0 :
                    i = 1
                    list_att.append({'Name':emp.name,'Date':d,'Day':d.strftime("%A"),'Time in':time_in,'Time out':time_out})
                elif time_in or time_out :
                    list_att.append({'Name':'','Date':d,'Day':d.strftime("%A"),'Time in':time_in,'Time out':time_out})

        return excel.make_response_from_records(list_att, "xls", file_name="Employee Attenced")
            

    return render(request,'zkcluster/attendance_export.html',{'ExportForm':ExportForm()} )