from django.apps import AppConfig


class FingerprintdevicesConfig(AppConfig):
    name = 'fingerprintdevices'
